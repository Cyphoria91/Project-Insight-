import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Capacitor configuration for iOS + Android wrappers.
 *
 * Linux is NOT supported by Capacitor. Linux users install the PWA from
 * the browser ("Install app") — same codebase, no extra build.
 *
 * Build flow (run on your own machine, not in Lovable):
 *   1. bun run build              # produces the web bundle
 *   2. npx cap add android        # creates android/ with gradlew + app/build.gradle
 *   3. npx cap add ios            # creates ios/ Xcode project
 *   4. npx cap sync               # copies web assets into native projects
 *   5. npx cap open android       # build APK in Android Studio
 *   6. npx cap open ios           # build IPA in Xcode (macOS only)
 */
const config: CapacitorConfig = {
  appId: "app.insighteditor",
  appName: "Project Insight",
  // TanStack Start SSR build outputs the client bundle to dist/client/.
  // Capacitor copies this directory into the native app at `cap sync`.
  webDir: "dist/client",
  bundledWebRuntime: false,
  android: {
    allowMixedContent: false,
    backgroundColor: "#0b0b0f",
  },
  ios: {
    contentInset: "always",
    backgroundColor: "#0b0b0f",
  },
  server: {
    androidScheme: "https",
    iosScheme: "https",
  },
};

export default config;

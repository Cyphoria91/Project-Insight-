package app.insighteditor.ui.panels

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.insighteditor.domain.model.TextOverlay
import app.insighteditor.domain.model.TextOverlayType
import app.insighteditor.ui.components.SectionHeader
import app.insighteditor.ui.theme.*
import java.util.UUID

@Composable
fun TextOverlayPanel(
    clipId: String?,
    currentOverlay: TextOverlay?,
    onSetOverlay: (TextOverlay?) -> Unit,
    modifier: Modifier = Modifier
) {
    val editorColors = LocalEditorColors.current
    var selectedType by remember { mutableStateOf(currentOverlay?.type ?: TextOverlayType.TITLE) }
    var mainText     by remember { mutableStateOf(currentOverlay?.text ?: "") }
    var subText      by remember { mutableStateOf(currentOverlay?.subText ?: "") }
    var fontSize     by remember { mutableFloatStateOf(currentOverlay?.fontSizeSp ?: 32f) }
    var bold         by remember { mutableStateOf(currentOverlay?.bold ?: false) }
    var italic       by remember { mutableStateOf(currentOverlay?.italic ?: false) }
    var posX         by remember { mutableFloatStateOf(currentOverlay?.positionX ?: 0.5f) }
    var posY         by remember { mutableFloatStateOf(currentOverlay?.positionY ?: 0.8f) }
    var animateIn    by remember { mutableStateOf(currentOverlay?.animateIn ?: true) }
    var animateOut   by remember { mutableStateOf(currentOverlay?.animateOut ?: true) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(editorColors.surface2)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Text & Titles",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold
        )

        if (clipId == null) {
            Text("Select a clip to add text overlays",
                 style = MaterialTheme.typography.bodyMedium, color = editorColors.labelText)
            return@Column
        }

        // Type selector
        SectionHeader("Type")
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            enumValues<TextOverlayType>().forEach { type ->
                FilterChip(
                    selected = selectedType == type,
                    onClick  = { selectedType = type },
                    label    = { Text(type.name.replace("_", " "), style = MaterialTheme.typography.labelSmall) },
                    colors   = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                        selectedLabelColor     = MaterialTheme.colorScheme.primary,
                        containerColor         = editorColors.surface3,
                        labelColor             = editorColors.labelText
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true, selected = selectedType == type,
                        selectedBorderColor = MaterialTheme.colorScheme.primary,
                        borderColor = editorColors.divider
                    )
                )
            }
        }

        // Text input
        SectionHeader("Content")
        OutlinedTextField(
            value = mainText,
            onValueChange = { if (it.length <= 200) mainText = it },
            label = { Text("Main Text") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 3,
            isError = mainText.isEmpty(),
            supportingText = if (mainText.isEmpty()) {
                { Text("Text cannot be empty") }
            } else null,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = editorColors.divider,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
            )
        )
        if (selectedType == TextOverlayType.LOWER_THIRD) {
            OutlinedTextField(
                value = subText,
                onValueChange = { if (it.length <= 100) subText = it },
                label = { Text("Sub Text (role/title)") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 1,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = editorColors.divider,
                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }

        // Font size
        SectionHeader("Font Size")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Slider(
                value = fontSize,
                onValueChange = { fontSize = it },
                valueRange = 12f..120f,
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(
                    thumbColor = MaterialTheme.colorScheme.primary,
                    activeTrackColor = MaterialTheme.colorScheme.primary,
                    inactiveTrackColor = editorColors.divider
                )
            )
            Spacer(Modifier.width(8.dp))
            Text("${fontSize.toInt()}sp", style = MaterialTheme.typography.labelLarge,
                 color = editorColors.monoText, modifier = Modifier.width(40.dp))
        }

        // Style toggles
        SectionHeader("Style")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = bold, onClick = { bold = !bold },
                label = { Text("Bold", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                    selectedLabelColor = MaterialTheme.colorScheme.primary,
                    containerColor = editorColors.surface3, labelColor = editorColors.labelText
                ),
                border = FilterChipDefaults.filterChipBorder(enabled = true, selected = bold,
                    selectedBorderColor = MaterialTheme.colorScheme.primary, borderColor = editorColors.divider)
            )
            FilterChip(
                selected = italic, onClick = { italic = !italic },
                label = { Text("Italic", style = MaterialTheme.typography.labelMedium.copy(
                    fontStyle = FontStyle.Italic)) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                    selectedLabelColor = MaterialTheme.colorScheme.primary,
                    containerColor = editorColors.surface3, labelColor = editorColors.labelText
                ),
                border = FilterChipDefaults.filterChipBorder(enabled = true, selected = italic,
                    selectedBorderColor = MaterialTheme.colorScheme.primary, borderColor = editorColors.divider)
            )
        }

        // Position
        SectionHeader("Position")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("X", style = MaterialTheme.typography.labelSmall, color = editorColors.labelText,
                 modifier = Modifier.width(16.dp))
            Slider(value = posX, onValueChange = { posX = it }, valueRange = 0f..1f,
                   modifier = Modifier.weight(1f),
                   colors = SliderDefaults.colors(thumbColor = MaterialTheme.colorScheme.primary,
                       activeTrackColor = MaterialTheme.colorScheme.primary, inactiveTrackColor = editorColors.divider))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Y", style = MaterialTheme.typography.labelSmall, color = editorColors.labelText,
                 modifier = Modifier.width(16.dp))
            Slider(value = posY, onValueChange = { posY = it }, valueRange = 0f..1f,
                   modifier = Modifier.weight(1f),
                   colors = SliderDefaults.colors(thumbColor = MaterialTheme.colorScheme.primary,
                       activeTrackColor = MaterialTheme.colorScheme.primary, inactiveTrackColor = editorColors.divider))
        }

        // Animation
        SectionHeader("Animation")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = animateIn, onClick = { animateIn = !animateIn },
                label = { Text("Animate In", style = MaterialTheme.typography.labelSmall) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                    selectedLabelColor = MaterialTheme.colorScheme.primary,
                    containerColor = editorColors.surface3, labelColor = editorColors.labelText),
                border = FilterChipDefaults.filterChipBorder(enabled = true, selected = animateIn,
                    selectedBorderColor = MaterialTheme.colorScheme.primary, borderColor = editorColors.divider))
            FilterChip(selected = animateOut, onClick = { animateOut = !animateOut },
                label = { Text("Animate Out", style = MaterialTheme.typography.labelSmall) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                    selectedLabelColor = MaterialTheme.colorScheme.primary,
                    containerColor = editorColors.surface3, labelColor = editorColors.labelText),
                border = FilterChipDefaults.filterChipBorder(enabled = true, selected = animateOut,
                    selectedBorderColor = MaterialTheme.colorScheme.primary, borderColor = editorColors.divider))
        }

        // Preview
        if (mainText.isNotBlank()) {
            TextPreview(text = mainText, subText = subText, type = selectedType,
                        fontSize = fontSize, bold = bold, italic = italic, posX = posX, posY = posY)
        }

        HorizontalDivider(color = editorColors.divider)

        // Apply / Remove
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    onSetOverlay(TextOverlay(
                        id = UUID.randomUUID().toString(),
                        type = selectedType,
                        text = mainText,
                        subText = subText,
                        fontSizeSp = fontSize,
                        bold = bold,
                        italic = italic,
                        positionX = posX,
                        positionY = posY,
                        animateIn = animateIn,
                        animateOut = animateOut
                    ))
                },
                modifier = Modifier.weight(1f),
                enabled = mainText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Apply", style = MaterialTheme.typography.labelMedium)
            }
            if (currentOverlay != null) {
                OutlinedButton(
                    onClick = { onSetOverlay(null) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Remove", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun TextPreview(
    text: String, subText: String, type: TextOverlayType,
    fontSize: Float, bold: Boolean, italic: Boolean, posX: Float, posY: Float
) {
    val editorColors = LocalEditorColors.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(8.dp))
            .background(Color.Black)
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(
                    x = ((posX - 0.5f) * 200).dp,
                    y = ((posY - 0.5f) * 100).dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text,
                fontSize = (fontSize * 0.4f).sp,
                fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
                fontStyle = if (italic) FontStyle.Italic
                            else FontStyle.Normal,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            if (subText.isNotBlank() && type == TextOverlayType.LOWER_THIRD) {
                Text(
                    subText,
                    fontSize = (fontSize * 0.25f).sp,
                    color = Color.White.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
            }
        }
        // Type label
        Text(
            type.name.replace("_", " "),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.align(Alignment.TopStart).padding(6.dp)
        )
    }
}

package app.insighteditor.ui.theme

import androidx.compose.ui.graphics.Color

// ── Deep space backgrounds ────────────────────────────────────────────────────
// True void black with a subtle blue-violet undertone
val Void100  = Color(0xFF02020A)   // deepest background
val Void200  = Color(0xFF05050F)   // app background
val Void300  = Color(0xFF080814)   // surface base
val Void400  = Color(0xFF0C0C1A)   // surface raised
val Void500  = Color(0xFF111122)   // surface elevated
val Void600  = Color(0xFF181830)   // surface panel
val Void700  = Color(0xFF1E1E3A)   // surface card
val Void800  = Color(0xFF252545)   // surface highlight

// ── Neon cyan — primary accent ────────────────────────────────────────────────
val NeonCyan900  = Color(0xFF001A1F)
val NeonCyan800  = Color(0xFF003040)
val NeonCyan700  = Color(0xFF004D66)
val NeonCyan600  = Color(0xFF006B8A)
val NeonCyan500  = Color(0xFF00B4D8)   // primary neon cyan
val NeonCyan400  = Color(0xFF00D4FF)   // bright cyan
val NeonCyan300  = Color(0xFF48E8FF)   // electric cyan
val NeonCyan200  = Color(0xFF90F4FF)   // pale cyan
val NeonCyan100  = Color(0xFFCCFBFF)   // near-white cyan

// ── Neon magenta / purple — secondary accent ──────────────────────────────────
val NeonMagenta500 = Color(0xFFBF00FF)  // deep magenta
val NeonMagenta400 = Color(0xFFD400FF)  // vivid magenta
val NeonMagenta300 = Color(0xFFE040FB)  // electric purple-magenta
val NeonMagenta200 = Color(0xFFEA80FC)  // soft magenta
val NeonPurple500  = Color(0xFF7B2FBE)  // deep purple
val NeonPurple400  = Color(0xFF9C27B0)  // purple
val NeonPurple300  = Color(0xFFCE93D8)  // light purple

// ── Hot orange — tertiary / warning accent ────────────────────────────────────
val NeonOrange500 = Color(0xFFFF6B00)   // hot orange
val NeonOrange400 = Color(0xFFFF8C00)   // amber-orange
val NeonOrange300 = Color(0xFFFFAB40)   // warm orange
val NeonOrange200 = Color(0xFFFFCC80)   // pale orange

// ── Teal — success / audio accent ────────────────────────────────────────────
val NeonTeal500 = Color(0xFF00E5CC)     // electric teal
val NeonTeal400 = Color(0xFF1DE9B6)     // bright teal
val NeonTeal300 = Color(0xFF64FFDA)     // pale teal

// ── Neutral text ─────────────────────────────────────────────────────────────
val TextPrimary   = Color(0xFFE8E8F8)   // near-white with blue tint
val TextSecondary = Color(0xFF9898B8)   // muted blue-gray
val TextTertiary  = Color(0xFF5A5A7A)   // dim label text
val TextDisabled  = Color(0xFF3A3A55)   // disabled state

// ── Dividers / borders ────────────────────────────────────────────────────────
val DividerSubtle  = Color(0xFF1A1A30)  // barely visible
val DividerNormal  = Color(0xFF252545)  // standard divider
val DividerBright  = Color(0xFF353560)  // prominent divider

// ── Semantic ─────────────────────────────────────────────────────────────────
val ErrorRed     = Color(0xFFFF3D5A)    // neon red
val SuccessGreen = Color(0xFF00E676)    // neon green
val WarningAmber = Color(0xFFFFAB00)    // amber warning

// ── Track colors (timeline) ───────────────────────────────────────────────────
val VideoTrackColor = NeonCyan500       // electric cyan for video
val AudioTrackColor = NeonTeal400       // teal for audio
val FxTrackColor    = NeonMagenta300    // magenta for FX
val SelectedClip    = NeonCyan300       // bright cyan when selected
val PlayheadColor   = NeonOrange400     // hot orange playhead

// ── Waveform ──────────────────────────────────────────────────────────────────
val WaveformColor = NeonTeal300

// ── Color grading wheels ──────────────────────────────────────────────────────
val LiftColor  = NeonMagenta300         // magenta for lift
val GammaColor = NeonTeal400            // teal for gamma
val GainColor  = NeonOrange300          // orange for gain

// ── Glow / bloom helpers (used as shadow/blur tints) ─────────────────────────
val GlowCyan    = NeonCyan400.copy(alpha = 0.35f)
val GlowMagenta = NeonMagenta400.copy(alpha = 0.30f)
val GlowOrange  = NeonOrange500.copy(alpha = 0.40f)
val GlowTeal    = NeonTeal500.copy(alpha = 0.30f)

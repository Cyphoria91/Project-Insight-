package app.insighteditor.data.db.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import app.insighteditor.domain.model.TrackType

@Entity(
    tableName = "tracks",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("project_id")]
)
data class TrackEntity(
    @PrimaryKey val id: String,
    @ColumnInfo(name = "project_id") val projectId: String,
    val type: TrackType,
    val name: String,
    @ColumnInfo(name = "is_muted")  val isMuted: Boolean,
    @ColumnInfo(name = "is_solo")   val isSolo: Boolean,
    @ColumnInfo(name = "is_locked") val isLocked: Boolean,
    val volume: Float,
    /** Ordering within the project — lower index = higher track in the timeline. */
    @ColumnInfo(name = "sort_order") val sortOrder: Int
)

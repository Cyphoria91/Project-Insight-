package app.insighteditor.export

import android.content.ContentValues
import android.content.Context
import android.content.pm.ServiceInfo
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Log
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequest
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import app.insighteditor.R
import app.insighteditor.domain.model.ExportConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer

private const val TAG = "ExportWorker"

class ExportWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        const val KEY_OUTPUT_PATH   = "output_path"
        const val KEY_WIDTH         = "width"
        const val KEY_HEIGHT        = "height"
        const val KEY_BITRATE       = "bitrate_mbps"
        const val KEY_CODEC         = "codec"
        const val KEY_FRAMERATE     = "framerate"
        const val KEY_DURATION_MS   = "duration_ms"
        /** JSON array of AudioMixer.AudioTrackInput serialised as pipe-delimited strings. */
        const val KEY_AUDIO_TRACKS  = "audio_tracks"
        const val CHANNEL_ID        = "export_channel"
        const val NOTIF_ID          = 1001

        /**
         * Serialises one [AudioMixer.AudioTrackInput] to a pipe-delimited string so it
         * can be stored in WorkManager's flat key-value data bundle.
         *
         * Format: uri|timelineStartMs|timelineEndMs|sourceStartMs|volume|pan|isMuted|isSolo
         */
        fun serializeAudioTrack(t: AudioMixer.AudioTrackInput): String =
            "${t.uri}|${t.timelineStartMs}|${t.timelineEndMs}|${t.sourceStartMs}" +
            "|${t.volume}|${t.pan}|${t.isMuted}|${t.isSolo}"

        fun deserializeAudioTrack(s: String): AudioMixer.AudioTrackInput? = try {
            val p = s.split("|")
            AudioMixer.AudioTrackInput(
                uri            = p[0],
                timelineStartMs = p[1].toLong(),
                timelineEndMs   = p[2].toLong(),
                sourceStartMs   = p[3].toLong(),
                volume          = p[4].toFloat(),
                pan             = p[5].toFloat(),
                isMuted         = p[6].toBoolean(),
                isSolo          = p[7].toBoolean()
            )
        } catch (e: Exception) {
            Log.w(TAG, "Cannot deserialize audio track: $s", e)
            null
        }

        fun buildRequest(
            config: ExportConfig,
            outputPath: String,
            audioTracks: List<AudioMixer.AudioTrackInput> = emptyList(),
            durationMs: Long = 0L
        ): OneTimeWorkRequest {
            val serialized = audioTracks.map { serializeAudioTrack(it) }.toTypedArray()
            val data = workDataOf(
                KEY_OUTPUT_PATH  to outputPath,
                KEY_WIDTH        to config.resolution.width,
                KEY_HEIGHT       to config.resolution.height,
                KEY_BITRATE      to config.bitrateMbps,
                KEY_CODEC        to config.codec.name,
                KEY_FRAMERATE    to config.frameRate,
                KEY_DURATION_MS  to durationMs,
                KEY_AUDIO_TRACKS to serialized
            )
            return OneTimeWorkRequestBuilder<ExportWorker>()
                .setInputData(data)
                .build()
        }
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val outputFilename = inputData.getString(KEY_OUTPUT_PATH)
            ?: "export_${System.currentTimeMillis()}.mp4"
        val width       = inputData.getInt(KEY_WIDTH,   1920).coerceAtLeast(1)
        val height      = inputData.getInt(KEY_HEIGHT,  1080).coerceAtLeast(1)
        val bitrateMbps = inputData.getInt(KEY_BITRATE, 20).coerceIn(1, 200)
        val codecName   = inputData.getString(KEY_CODEC) ?: "H265_HEVC"
        val frameRate   = inputData.getFloat(KEY_FRAMERATE, 23.976f).coerceIn(1f, 120f)
        val durationMs  = inputData.getLong(KEY_DURATION_MS, 10_000L).coerceAtLeast(1L)
        val audioTracks = inputData.getStringArray(KEY_AUDIO_TRACKS)
            ?.mapNotNull { deserializeAudioTrack(it) }
            ?: emptyList()

        createNotificationChannel()
        setForeground(createForegroundInfo(0))

        val target = try {
            resolveOutputTarget(outputFilename)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to resolve output target", e)
            return@withContext Result.failure(
                workDataOf("error" to "Cannot create output file: ${e.message}")
            )
        }

        return@withContext try {
            if (target.pfd != null) {
                // API 29+: construct MediaMuxer from the file descriptor directly.
                // The PFD is closed in the finally block after muxer.release().
                encodeVideoToFd(target.pfd, width, height, bitrateMbps, codecName, frameRate,
                    audioTracks, durationMs)
            } else {
                encodeVideo(target.path!!, width, height, bitrateMbps, codecName, frameRate,
                    audioTracks, durationMs)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && target.mediaStoreUri != null) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.IS_PENDING, 0)
                }
                applicationContext.contentResolver.update(target.mediaStoreUri, values, null, null)
            }

            setProgress(workDataOf("progress" to 1f, "stage" to "Complete"))
            Result.success(workDataOf(KEY_OUTPUT_PATH to (target.path ?: target.mediaStoreUri?.toString() ?: "")))
        } catch (e: Exception) {
            Log.e(TAG, "Export failed", e)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && target.mediaStoreUri != null) {
                try {
                    applicationContext.contentResolver.delete(target.mediaStoreUri, null, null)
                } catch (deleteEx: Exception) {
                    Log.e(TAG, "Failed to clean up pending MediaStore entry", deleteEx)
                }
            }
            Result.failure(workDataOf("error" to (e.message ?: "Unknown error")))
        } finally {
            // Always close the PFD after the muxer has been released inside encodeVideoToFd.
            try { target.pfd?.close() } catch (e: Exception) {
                Log.e(TAG, "Failed to close output PFD", e)
            }
        }
    }

    /**
     * Resolves the output target for the muxer.
     *
     * On API 29+ we insert a pending MediaStore entry and return an open
     * [ParcelFileDescriptor] alongside the URI so the caller can construct
     * a [MediaMuxer] from the file descriptor directly — avoiding the
     * `/proc/self/fd/<n>` path trick which leaks the PFD and is not
     * guaranteed to work across all OEM kernels.
     *
     * On API < 29 we fall back to a plain file path in the public Movies dir.
     *
     * The returned [ParcelFileDescriptor] (if non-null) must be closed by the
     * caller after [MediaMuxer.release] completes.
     */
    private data class OutputTarget(
        val path: String?,
        val pfd: ParcelFileDescriptor?,
        val mediaStoreUri: android.net.Uri?
    )

    private fun resolveOutputTarget(filename: String): OutputTarget {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, filename)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH,
                    "${Environment.DIRECTORY_MOVIES}/InsightEditor")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = applicationContext.contentResolver.insert(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values
            ) ?: throw IllegalStateException("MediaStore insert returned null URI")

            val pfd = applicationContext.contentResolver.openFileDescriptor(uri, "rw")
                ?: throw IllegalStateException("Cannot open file descriptor for $uri")
            return OutputTarget(path = null, pfd = pfd, mediaStoreUri = uri)
        } else {
            @Suppress("DEPRECATION")
            val dir = java.io.File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "InsightEditor"
            ).also { it.mkdirs() }
            return OutputTarget(
                path = java.io.File(dir, filename).absolutePath,
                pfd = null,
                mediaStoreUri = null
            )
        }
    }

    /** Encodes using a [ParcelFileDescriptor] (API 29+). */
    private suspend fun encodeVideoToFd(
        pfd: ParcelFileDescriptor,
        width: Int, height: Int, bitrateMbps: Int, codecName: String, frameRate: Float,
        audioTracks: List<AudioMixer.AudioTrackInput>, durationMs: Long
    ) = encodeVideoCore(
        muxerFactory = { MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4) },
        width = width, height = height, bitrateMbps = bitrateMbps,
        codecName = codecName, frameRate = frameRate,
        audioTracks = audioTracks, durationMs = durationMs
    )

    /** Encodes to a file path (API < 29 fallback). */
    private suspend fun encodeVideo(
        outputPath: String,
        width: Int, height: Int, bitrateMbps: Int, codecName: String, frameRate: Float,
        audioTracks: List<AudioMixer.AudioTrackInput>, durationMs: Long
    ) = encodeVideoCore(
        muxerFactory = { MediaMuxer(outputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4) },
        width = width, height = height, bitrateMbps = bitrateMbps,
        codecName = codecName, frameRate = frameRate,
        audioTracks = audioTracks, durationMs = durationMs
    )

    /**
     * Encodes a video+audio stream and muxes them into an MP4 container.
     *
     * Key invariants:
     *  1. The muxer is started only after BOTH video and audio tracks have
     *     reported INFO_OUTPUT_FORMAT_CHANGED.  Starting before both tracks
     *     are added produces a container with a missing track header — the
     *     root cause of the v1.0.3 silent-audio regression.
     *  2. EOS is signalled on the encoder input before draining the final
     *     output.  Draining without signalling EOS first causes the encoder
     *     to stall indefinitely on some Qualcomm and MediaTek hardware.
     *  3. BUFFER_FLAG_CODEC_CONFIG buffers (SPS/PPS, DSC) are never written
     *     to the muxer — the muxer extracts codec config from the MediaFormat
     *     returned by INFO_OUTPUT_FORMAT_CHANGED.  Writing them again produces
     *     a malformed container.
     *  4. All MediaCodec and MediaMuxer resources are released in a finally
     *     block so they are never leaked on exception paths.
     *  5. muxer.stop() is only called when muxerStarted is true.  Calling
     *     stop() on an unstarted muxer throws IllegalStateException, which was
     *     swallowed silently in v1.0.3 and produced a zero-byte output file.
     */
    private suspend fun encodeVideoCore(
        muxerFactory: () -> MediaMuxer,
        width: Int,
        height: Int,
        bitrateMbps: Int,
        codecName: String,
        frameRate: Float,
        audioTracks: List<AudioMixer.AudioTrackInput> = emptyList(),
        durationMs: Long = 10_000L
    ) {
        val videoMimeType = when (codecName) {
            "H265_HEVC" -> MediaFormat.MIMETYPE_VIDEO_HEVC
            "AV1"       -> "video/av01"
            else        -> MediaFormat.MIMETYPE_VIDEO_AVC
        }

        val videoFormat = MediaFormat.createVideoFormat(videoMimeType, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrateMbps * 1_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, frameRate.toInt())
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val videoEncoder = MediaCodec.createEncoderByType(videoMimeType)
        val muxer = muxerFactory()

        var videoTrackIndex     = -1
        var audioTrackIndex     = -1
        var muxerStarted        = false
        var videoFormatReceived = false
        var audioFormatReceived = false

        // AudioMixer runs on the IO dispatcher and writes directly to the muxer.
        // It calls onTrackAdded once the AAC encoder reports INFO_OUTPUT_FORMAT_CHANGED,
        // which lets us start the muxer as soon as both tracks are registered.
        //
        // The mixer is launched as a coroutine so it interleaves with the video
        // encode loop; both must complete before the muxer is stopped.
        val mixer = AudioMixer(
            context     = applicationContext,
            sampleRate  = 48_000,
            channelCount = 2,
            bitrate     = 320_000,
            totalDurationMs = durationMs
        )

        // Run AudioMixer in a separate coroutine so video and audio encode concurrently.
        val audioJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                mixer.mix(
                    inputs       = audioTracks,
                    muxer        = muxer,
                    onTrackAdded = { idx ->
                        audioTrackIndex     = idx
                        audioFormatReceived = true
                        // Start muxer only after both tracks are registered.
                        // This block may race with the video format callback below;
                        // both are guarded by the same muxerStarted flag.
                        synchronized(muxer) {
                            if (videoFormatReceived && !muxerStarted) {
                                muxer.start()
                                muxerStarted = true
                            }
                        }
                    }
                )
            } catch (e: Exception) {
                Log.e(TAG, "AudioMixer failed", e)
            }
        }

        try {
            videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            videoEncoder.start()

            val totalFrames = (frameRate * (durationMs / 1000f)).toInt().coerceAtLeast(1)
            val bufferInfo  = MediaCodec.BufferInfo()

            for (frameIdx in 0 until totalFrames) {
                val progress = frameIdx.toFloat() / totalFrames
                setProgress(workDataOf(
                    "progress" to progress,
                    "stage"    to "Encoding frame $frameIdx/$totalFrames"
                ))
                setForeground(createForegroundInfo((progress * 100).toInt()))

                // Drain video encoder output (non-blocking pass)
                drainEncoder(
                    encoder    = videoEncoder,
                    bufferInfo = bufferInfo,
                    muxer      = muxer,
                    trackIndex = { videoTrackIndex },
                    onFormatChanged = { format ->
                        videoTrackIndex = muxer.addTrack(format)
                        videoFormatReceived = true
                        synchronized(muxer) {
                            if (audioFormatReceived && !muxerStarted) {
                                muxer.start()
                                muxerStarted = true
                            }
                        }
                    },
                    muxerStarted = { muxerStarted }
                )
            }

            // Signal video EOS and drain remaining output
            val videoEosIdx = videoEncoder.dequeueInputBuffer(10_000L)
            if (videoEosIdx >= 0) {
                videoEncoder.queueInputBuffer(
                    videoEosIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                )
            }
            drainToEos(videoEncoder, bufferInfo, muxer, { videoTrackIndex },
                onFormatChanged = { format ->
                    if (!videoFormatReceived) {
                        videoTrackIndex = muxer.addTrack(format)
                        videoFormatReceived = true
                        synchronized(muxer) {
                            if (audioFormatReceived && !muxerStarted) {
                                muxer.start(); muxerStarted = true
                            }
                        }
                    }
                },
                muxerStarted = { muxerStarted }
            )

            // Wait for AudioMixer to finish before stopping the muxer
            audioJob.join()

        } finally {
            try { videoEncoder.stop()    } catch (e: Exception) { Log.e(TAG, "videoEncoder.stop",    e) }
            try { videoEncoder.release() } catch (e: Exception) { Log.e(TAG, "videoEncoder.release", e) }
            audioJob.cancel()
            if (muxerStarted) {
                try { muxer.stop()    } catch (e: Exception) { Log.e(TAG, "muxer.stop",    e) }
            }
            try { muxer.release() } catch (e: Exception) { Log.e(TAG, "muxer.release", e) }
        }
    }

    /**
     * Non-blocking drain: dequeues all currently available output buffers
     * without waiting for EOS.  Used during the encoding loop.
     */
    private fun drainEncoder(
        encoder: MediaCodec,
        bufferInfo: MediaCodec.BufferInfo,
        muxer: MediaMuxer,
        trackIndex: () -> Int,
        onFormatChanged: (MediaFormat) -> Unit,
        muxerStarted: () -> Boolean
    ) {
        while (true) {
            val outIdx = encoder.dequeueOutputBuffer(bufferInfo, 0L)
            when {
                outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormatChanged(encoder.outputFormat)
                outIdx == MediaCodec.INFO_TRY_AGAIN_LATER       -> return
                outIdx >= 0 -> {
                    val buf = encoder.getOutputBuffer(outIdx)
                    val isCodecConfig = bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                    if (buf != null && muxerStarted() && trackIndex() >= 0 &&
                        bufferInfo.size > 0 && !isCodecConfig) {
                        muxer.writeSampleData(trackIndex(), buf, bufferInfo)
                    }
                    encoder.releaseOutputBuffer(outIdx, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
                else -> return
            }
        }
    }

    /**
     * Blocking drain: dequeues output buffers until EOS is received.
     * Used after signalling EOS on the input side.
     */
    private fun drainToEos(
        encoder: MediaCodec,
        bufferInfo: MediaCodec.BufferInfo,
        muxer: MediaMuxer,
        trackIndex: () -> Int,
        onFormatChanged: (MediaFormat) -> Unit,
        muxerStarted: () -> Boolean
    ) {
        while (true) {
            val outIdx = encoder.dequeueOutputBuffer(bufferInfo, 10_000L)
            when {
                outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormatChanged(encoder.outputFormat)
                outIdx == MediaCodec.INFO_TRY_AGAIN_LATER       -> return
                outIdx >= 0 -> {
                    val buf = encoder.getOutputBuffer(outIdx)
                    val isCodecConfig = bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                    if (buf != null && muxerStarted() && trackIndex() >= 0 &&
                        bufferInfo.size > 0 && !isCodecConfig) {
                        muxer.writeSampleData(trackIndex(), buf, bufferInfo)
                    }
                    encoder.releaseOutputBuffer(outIdx, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
                else -> return
            }
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannelCompat.Builder(
            CHANNEL_ID, NotificationManagerCompat.IMPORTANCE_LOW
        )
            .setName(applicationContext.getString(R.string.export_notification_channel))
            .setDescription(applicationContext.getString(R.string.export_notification_channel_description))
            .build()
        NotificationManagerCompat.from(applicationContext).createNotificationChannel(channel)
    }

    private fun createForegroundInfo(progress: Int): ForegroundInfo {
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setContentTitle(applicationContext.getString(R.string.export_notification_title))
            .setContentText("$progress%")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setProgress(100, progress, progress == 0)
            .setOngoing(true)
            .build()
        return if (Build.VERSION.SDK_INT >= 34) {
            ForegroundInfo(NOTIF_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING)
        } else {
            ForegroundInfo(NOTIF_ID, notification)
        }
    }
}

package app.insighteditor.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.insighteditor.haptic.LocalHaptic
import app.insighteditor.ui.theme.*

/**
 * Cyberpunk horizontal tool strip.
 *
 * Each tool has a unique neon accent color when selected, giving the dock
 * a holographic multi-color feel. Unselected tools are dim/muted.
 */

private data class DockTool(
    val id: String,
    val label: String,
    val icon: ImageVector,
    val accentColor: androidx.compose.ui.graphics.Color
)

private val DOCK_TOOLS = listOf(
    DockTool("pool",      "Media",     Icons.Default.VideoLibrary, NeonCyan400),
    DockTool("inspector", "Inspector", Icons.Default.Tune,         NeonOrange300),
    DockTool("fx",        "Effects",   Icons.Default.AutoAwesome,  NeonMagenta300),
    DockTool("color",     "Color",     Icons.Default.Palette,      NeonTeal400),
    DockTool("key",       "Keyframe",  Icons.Default.Diamond,      NeonOrange300),
    DockTool("text",      "Text",      Icons.Default.TextFields,   NeonCyan300),
    DockTool("audio",     "Audio",     Icons.Default.MusicNote,    NeonTeal300),
    DockTool("ai",        "AI / 8K",   Icons.Default.Psychology,   NeonMagenta200)
)

@Composable
fun ToolDock(
    activePanel: String?,
    onPanelSelected: (String?) -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Void400)
    ) {
        // Neon top separator
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color.Transparent,
                            NeonMagenta300.copy(alpha = 0.4f),
                            NeonCyan400.copy(alpha = 0.3f),
                            Color.Transparent
                        )
                    )
                )
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            DOCK_TOOLS.forEach { tool ->
                val selected = activePanel == tool.id
                val accent = tool.accentColor

                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (selected)
                                Brush.verticalGradient(
                                    listOf(
                                        accent.copy(alpha = 0.15f),
                                        accent.copy(alpha = 0.05f)
                                    )
                                )
                            else
                                Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
                        )
                        .then(
                            if (selected) Modifier.border(
                                1.dp,
                                Brush.verticalGradient(
                                    listOf(accent.copy(alpha = 0.7f), accent.copy(alpha = 0.2f))
                                ),
                                RoundedCornerShape(8.dp)
                            ) else Modifier
                        )
                        .drawBehind {
                            if (selected) {
                                // Bottom glow bar
                                drawRect(
                                    color = accent.copy(alpha = 0.5f),
                                    topLeft = androidx.compose.ui.geometry.Offset(0f, size.height - 2.dp.toPx()),
                                    size = androidx.compose.ui.geometry.Size(size.width, 2.dp.toPx())
                                )
                            }
                        }
                        .clickable {

                            onPanelSelected(if (selected) null else tool.id)
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(
                        tool.icon,
                        contentDescription = tool.label,
                        tint = if (selected) accent else TextTertiary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        tool.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) accent else TextTertiary,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

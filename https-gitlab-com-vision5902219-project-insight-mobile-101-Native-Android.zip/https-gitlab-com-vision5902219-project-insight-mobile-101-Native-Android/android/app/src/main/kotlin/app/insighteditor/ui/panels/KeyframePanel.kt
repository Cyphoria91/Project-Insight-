package app.insighteditor.ui.panels

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.insighteditor.domain.model.EasingType
import app.insighteditor.domain.model.Keyframe
import app.insighteditor.domain.model.KeyframeProperty
import app.insighteditor.ui.theme.*

/**
 * Full keyframe editor panel.
 *
 * - Property selector chips (Opacity, Scale, Position, Rotation, Volume, etc.)
 * - Curve editor canvas with cubic bezier interpolation and diamond markers
 * - Add-at-playhead button
 * - Per-keyframe list with easing dropdown and remove button
 */
@Composable
fun KeyframePanel(
    clipId: String,
    clipDurationMs: Long,
    playheadMs: Long,
    keyframes: List<Keyframe>,
    onAddKeyframe: (clipId: String, property: KeyframeProperty, value: Float) -> Unit,
    onRemoveKeyframe: (clipId: String, keyframeId: String) -> Unit,
    onEasingChange: (clipId: String, keyframeId: String, easing: EasingType) -> Unit,
    onClearAll: (clipId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedProperty by remember { mutableStateOf(KeyframeProperty.OPACITY) }

    val propertyKeyframes = remember(keyframes, selectedProperty) {
        keyframes.filter { it.property == selectedProperty }.sortedBy { it.timeMs }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Void200)
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "KEYFRAMES",
                color = TextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 2.sp
            )
            if (keyframes.isNotEmpty()) {
                IconButton(onClick = { onClearAll(clipId) }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Clear all keyframes",
                        tint = Color(0xFFFF3D5A), modifier = Modifier.size(16.dp))
                }
            }
        }

        // Property chips
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(KeyframeProperty.entries) { prop ->
                val active = prop == selectedProperty
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (active) NeonCyan400.copy(alpha = 0.15f) else Void300)
                        .border(
                            width = if (active) 1.dp else 0.5.dp,
                            color = if (active) NeonCyan400 else DividerSubtle,
                            shape = RoundedCornerShape(4.dp)
                        )
                        .clickable { selectedProperty = prop }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        prop.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() },
                        color = if (active) NeonCyan400 else TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        // Curve editor
        CurveEditorCanvas(
            keyframes  = propertyKeyframes,
            durationMs = clipDurationMs,
            playheadMs = playheadMs,
            modifier   = Modifier.fillMaxWidth().height(120.dp)
        )

        // Add keyframe button
        OutlinedButton(
            onClick = {
                val defaultValue = when (selectedProperty) {
                    KeyframeProperty.OPACITY,
                    KeyframeProperty.SCALE_X,
                    KeyframeProperty.SCALE_Y,
                    KeyframeProperty.VOLUME  -> 1f
                    else                     -> 0f
                }
                onAddKeyframe(clipId, selectedProperty, defaultValue)
            },
            modifier = Modifier.fillMaxWidth(),
            border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan400),
            shape = RoundedCornerShape(6.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null,
                tint = NeonCyan400, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            Text("Add keyframe at playhead", color = NeonCyan400, fontSize = 12.sp)
        }

        // Keyframe list
        if (propertyKeyframes.isNotEmpty()) {
            Text(
                "${selectedProperty.name.replace('_', ' ')} — ${propertyKeyframes.size} keyframe(s)",
                color = TextSecondary, fontSize = 11.sp
            )
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                propertyKeyframes.forEach { kf ->
                    KeyframeRow(
                        kf             = kf,
                        clipId         = clipId,
                        onRemove       = onRemoveKeyframe,
                        onEasingChange = onEasingChange
                    )
                }
            }
        }
    }
}

@Composable
private fun CurveEditorCanvas(
    keyframes: List<Keyframe>,
    durationMs: Long,
    playheadMs: Long,
    modifier: Modifier = Modifier
) {
    val cyan = NeonCyan400
    val grid = DividerSubtle
    val ph   = Color(0xFFFF6B35)

    Canvas(modifier = modifier.background(Void300).border(0.5.dp, DividerSubtle)) {
        val w = size.width; val h = size.height; val pad = 12f

        // Grid
        for (i in 0..4) {
            val y = pad + (h - 2 * pad) * i / 4f
            drawLine(grid, Offset(pad, y), Offset(w - pad, y), strokeWidth = 0.5f)
        }

        // Playhead
        if (durationMs > 0) {
            val px = pad + (w - 2 * pad) * (playheadMs.toFloat() / durationMs)
            drawLine(ph, Offset(px, 0f), Offset(px, h), strokeWidth = 1.5f)
        }

        if (keyframes.isEmpty() || durationMs <= 0) return@Canvas

        val values = keyframes.map { it.value }
        val minV = values.minOrNull() ?: 0f
        val maxV = (values.maxOrNull() ?: 1f).let { if (it == minV) minV + 1f else it }

        fun xOf(ms: Long) = pad + (w - 2 * pad) * (ms.toFloat() / durationMs)
        fun yOf(v: Float) = h - pad - (h - 2 * pad) * ((v - minV) / (maxV - minV))

        // Cubic bezier curve
        if (keyframes.size >= 2) {
            val path = Path()
            path.moveTo(xOf(keyframes[0].timeMs), yOf(keyframes[0].value))
            for (i in 1 until keyframes.size) {
                val prev = keyframes[i - 1]; val curr = keyframes[i]
                val cpX = (xOf(prev.timeMs) + xOf(curr.timeMs)) / 2f
                path.cubicTo(cpX, yOf(prev.value), cpX, yOf(curr.value),
                    xOf(curr.timeMs), yOf(curr.value))
            }
            drawPath(path, cyan.copy(alpha = 0.7f), style = Stroke(width = 1.5f))
        }

        // Diamond markers
        keyframes.forEach { kf ->
            val cx = xOf(kf.timeMs); val cy = yOf(kf.value); val r = 5f
            val diamond = Path().apply {
                moveTo(cx, cy - r); lineTo(cx + r, cy)
                lineTo(cx, cy + r); lineTo(cx - r, cy); close()
            }
            drawPath(diamond, cyan)
        }
    }
}

@Composable
private fun KeyframeRow(
    kf: Keyframe,
    clipId: String,
    onRemove: (String, String) -> Unit,
    onEasingChange: (String, String, EasingType) -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Void300, RoundedCornerShape(6.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Diamond icon
        Canvas(Modifier.size(10.dp)) {
            val r = size.minDimension / 2f
            drawPath(Path().apply {
                moveTo(r, 0f); lineTo(r * 2, r); lineTo(r, r * 2); lineTo(0f, r); close()
            }, NeonCyan400)
        }
        Text("${kf.timeMs}ms", color = TextPrimary, fontSize = 11.sp, modifier = Modifier.width(60.dp))
        Text("%.2f".format(kf.value), color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Box {
            Text(
                kf.easing.name.lowercase().replace('_', ' '),
                color = NeonCyan400, fontSize = 10.sp,
                modifier = Modifier
                    .border(0.5.dp, NeonCyan400, RoundedCornerShape(3.dp))
                    .clickable { showMenu = true }
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
            DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false },
                modifier = Modifier.background(Void300)) {
                EasingType.entries.forEach { easing ->
                    DropdownMenuItem(
                        text = {
                            Text(easing.name.lowercase().replace('_', ' '),
                                color = if (easing == kf.easing) NeonCyan400 else TextPrimary,
                                fontSize = 12.sp)
                        },
                        onClick = { onEasingChange(clipId, kf.id, easing); showMenu = false }
                    )
                }
            }
        }
        IconButton(onClick = { onRemove(clipId, kf.id) }, modifier = Modifier.size(20.dp)) {
            Icon(Icons.Default.Close, contentDescription = "Remove keyframe",
                tint = TextSecondary, modifier = Modifier.size(12.dp))
        }
    }
}

package app.insighteditor.di

import android.content.Context
import app.insighteditor.data.db.dao.ClipDao
import app.insighteditor.data.db.dao.ProjectDao
import app.insighteditor.data.db.dao.TrackDao
import app.insighteditor.data.media.MediaRepository
import app.insighteditor.data.repository.CacheManager
import app.insighteditor.data.repository.ProjectRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideProjectRepository(
        projectDao: ProjectDao,
        trackDao: TrackDao,
        clipDao: ClipDao
    ): ProjectRepository = ProjectRepository(projectDao, trackDao, clipDao)

    @Provides
    @Singleton
    fun provideMediaRepository(@ApplicationContext context: Context): MediaRepository =
        MediaRepository(context)

    @Provides
    @Singleton
    fun provideCacheManager(@ApplicationContext context: Context): CacheManager =
        CacheManager(context)

    // LutRepository and WaveformRepository both require NativeEngine, which is
    // owned by EditorViewModel (created per-ViewModel, not singleton). They are
    // instantiated directly inside EditorViewModel rather than injected here.
}

package app.insighteditor.ui.panels

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.insighteditor.domain.model.AppliedEffect
import app.insighteditor.domain.model.EffectType
import app.insighteditor.ui.theme.*
import java.util.UUID

private data class EffectEntry(val type: EffectType, val label: String, val category: String)

private val ALL_EFFECTS = listOf(
    // Transitions
    EffectEntry(EffectType.CROSS_DISSOLVE,       "Cross Dissolve",        "Transitions"),
    EffectEntry(EffectType.FILM_BURN,             "Film Burn",             "Transitions"),
    EffectEntry(EffectType.GLITCH_CUT,            "Glitch Cut",            "Transitions"),
    EffectEntry(EffectType.LIGHT_LEAK,            "Light Leak",            "Transitions"),
    EffectEntry(EffectType.WHIP_PAN,              "Whip Pan",              "Transitions"),
    EffectEntry(EffectType.DIP_TO_BLACK,          "Dip to Black",          "Transitions"),
    // Visual FX
    EffectEntry(EffectType.ANAMORPHIC_FLARE,      "Anamorphic Flare",      "Visual FX"),
    EffectEntry(EffectType.FILM_GRAIN,            "Film Grain",            "Visual FX"),
    EffectEntry(EffectType.CHROMATIC_ABERRATION,  "Chromatic Aberration",  "Visual FX"),
    EffectEntry(EffectType.HALATION,              "Halation",              "Visual FX"),
    EffectEntry(EffectType.VIGNETTE,              "Vignette",              "Visual FX"),
    EffectEntry(EffectType.GLOW,                  "Glow",                  "Visual FX"),
    // LUTs
    EffectEntry(EffectType.LUT_KODAK_2383,        "Kodak 2383",            "Color LUTs"),
    EffectEntry(EffectType.LUT_FUJI_3510,         "Fuji 3510",             "Color LUTs"),
    EffectEntry(EffectType.LUT_ARRI_K1S1,         "ARRI K1S1",             "Color LUTs"),
    EffectEntry(EffectType.LUT_CYBERPUNK,         "Cyberpunk Teal",        "Color LUTs"),
    EffectEntry(EffectType.LUT_BLEACH_BYPASS,     "Bleach Bypass",         "Color LUTs"),
    EffectEntry(EffectType.LUT_PRINT_FILM,        "Print Film",            "Color LUTs"),
)

@Composable
fun EffectsPanel(
    selectedClipId: String?,
    onApplyEffect: (String, AppliedEffect) -> Unit,
    modifier: Modifier = Modifier
) {
    val editorColors = LocalEditorColors.current
    var selectedCategory by remember { mutableStateOf("Transitions") }
    val categories = ALL_EFFECTS.map { it.category }.distinct()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(editorColors.surface2)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            "Effects & Transitions",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold
        )

        // Category tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            categories.forEach { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick  = { selectedCategory = cat },
                    label    = { Text(cat, style = MaterialTheme.typography.labelSmall) },
                    colors   = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                        selectedLabelColor     = MaterialTheme.colorScheme.primary,
                        containerColor         = editorColors.surface3,
                        labelColor             = editorColors.labelText
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true, selected = selectedCategory == cat,
                        selectedBorderColor = MaterialTheme.colorScheme.primary,
                        borderColor = editorColors.divider
                    )
                )
            }
        }

        // Effect grid — LazyColumn avoids unbounded nested scroll
        val filtered = ALL_EFFECTS.filter { it.category == selectedCategory }
        val rows = filtered.chunked(2)
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(rows) { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    row.forEach { effect ->
                        EffectCard(
                            entry = effect,
                            enabled = selectedClipId != null,
                            onClick = {
                                selectedClipId?.let { clipId ->
                                    onApplyEffect(clipId, AppliedEffect(
                                        id = UUID.randomUUID().toString(),
                                        type = effect.type,
                                        intensity = 0.8f
                                    ))
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        if (selectedClipId == null) {
            Text(
                "Select a clip on the timeline to apply effects",
                style = MaterialTheme.typography.bodySmall,
                color = editorColors.labelText
            )
        }
    }
}

@Composable
private fun EffectCard(
    entry: EffectEntry,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val editorColors = LocalEditorColors.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(editorColors.surface3)
            .border(width = 1.dp, color = editorColors.divider, shape = RoundedCornerShape(8.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Thumbnail placeholder
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(editorColors.surface2),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = null,
                    tint = if (enabled) MaterialTheme.colorScheme.primary else editorColors.labelText,
                    modifier = Modifier.size(16.dp)
                )
            }
            Text(
                entry.label,
                style = MaterialTheme.typography.labelSmall,
                color = if (enabled) MaterialTheme.colorScheme.onSurface else editorColors.labelText,
                maxLines = 2,
                textAlign = TextAlign.Center
            )
        }
    }
}

package app.insighteditor

import android.app.Application
import android.util.Log
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import app.insighteditor.shortcuts.ShortcutHelper
import com.google.firebase.FirebaseApp
import com.google.firebase.crashlytics.FirebaseCrashlytics
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

private const val TAG = "InsightEditorApp"

/**
 * Application entry point.
 *
 * Responsibilities:
 *  - Hilt component host (@HiltAndroidApp)
 *  - WorkManager Configuration.Provider — required so that @HiltWorker
 *    workers (TransformerExportWorker) are instantiated via HiltWorkerFactory
 *    instead of the default reflection-based factory. The default
 *    WorkManagerInitializer is removed from the manifest; WorkManager is
 *    initialised on-demand by the first WorkManager.getInstance() call.
 *  - Firebase initialisation (Crashlytics always on; Analytics gated by consent)
 *  - Dynamic app shortcuts registration
 */
@HiltAndroidApp
class InsightEditorApplication : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()
        initFirebase()
        ShortcutHelper.registerDynamicShortcuts(this)
    }

    private fun initFirebase() {
        try {
            FirebaseApp.initializeApp(this)

            // Crashlytics is always active — crash data is legitimate interest
            // under most privacy frameworks. Non-fatal logging and custom keys
            // are added by CrashReporter.
            FirebaseCrashlytics.getInstance().apply {
                setCrashlyticsCollectionEnabled(true)
                setCustomKey("app_build_type", if (BuildConfig.DEBUG) "debug" else "release")
                setCustomKey("min_sdk", android.os.Build.VERSION.SDK_INT)
            }

            // Analytics starts DISABLED. AnalyticsManager.enableCollection()
            // is called only after the user opts in via ConsentScreen.
            Log.i(TAG, "Firebase initialised (Analytics disabled until consent)")
        } catch (e: Exception) {
            Log.e(TAG, "Firebase init failed", e)
        }
    }
}

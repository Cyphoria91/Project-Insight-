package app.insighteditor.data.repository

import android.os.Environment
import android.util.Log
import app.insighteditor.data.db.dao.ClipDao
import app.insighteditor.data.db.dao.ProjectDao
import app.insighteditor.data.db.dao.TrackDao
import app.insighteditor.data.db.entity.ClipEntity
import app.insighteditor.data.db.entity.ProjectEntity
import app.insighteditor.data.db.entity.TrackEntity
import app.insighteditor.domain.model.AppliedEffect
import app.insighteditor.domain.model.Clip
import app.insighteditor.domain.model.ColorGrade
import app.insighteditor.domain.model.Keyframe
import app.insighteditor.domain.model.Project
import app.insighteditor.domain.model.TextOverlay
import app.insighteditor.domain.model.Track
import app.insighteditor.domain.model.Transition
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

private const val TAG = "ProjectRepository"

/**
 * Room-backed project repository.
 *
 * All public functions are safe to call from any coroutine context — IO
 * dispatching is handled internally. The [observeAll] Flow is backed by
 * Room's SQLite invalidation tracker and emits on every write.
 *
 * Domain <-> entity mapping is done here so the rest of the app never
 * imports Room entity types directly.
 */
@Singleton
class ProjectRepository @Inject constructor(
    private val projectDao: ProjectDao,
    private val trackDao: TrackDao,
    private val clipDao: ClipDao
) {
    private val gson = Gson()

    // ── Reactive queries ──────────────────────────────────────────────────────

    /** Emits the full project list (header only, no tracks/clips) on every change. */
    fun observeAll(): Flow<List<Project>> =
        projectDao.observeAll().map { entities ->
            entities.map { it.toDomain() }
        }

    // ── Suspend queries ───────────────────────────────────────────────────────

    suspend fun loadProject(id: String): Project? = withContext(Dispatchers.IO) {
        val entity = projectDao.getById(id) ?: return@withContext null
        val tracks = loadTracksForProject(id)
        entity.toDomain(tracks)
    }

    suspend fun getMostRecentProject(): Project? = withContext(Dispatchers.IO) {
        val entity = projectDao.getMostRecent() ?: return@withContext null
        val tracks = loadTracksForProject(entity.id)
        entity.toDomain(tracks)
    }

    suspend fun saveProject(project: Project) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val updated = project.copy(modifiedAt = now)

        // Upsert project header
        projectDao.insert(updated.toEntity())

        // Replace tracks and clips atomically
        trackDao.deleteByProject(project.id)
        updated.tracks.forEachIndexed { index, track ->
            trackDao.insert(track.toEntity(project.id, sortOrder = index))
            clipDao.deleteByTrack(track.id)
            clipDao.insertAll(track.clips.map { it.toEntity(track.id) })
        }
    }

    suspend fun deleteProject(id: String) = withContext(Dispatchers.IO) {
        // CASCADE foreign keys handle tracks and clips automatically.
        projectDao.deleteById(id)
    }

    // ── Output path helpers ───────────────────────────────────────────────────

    fun getExportOutputPath(filename: String): String {
        @Suppress("DEPRECATION")
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
            "InsightEditor"
        ).also { it.mkdirs() }
        return File(dir, filename).absolutePath
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private suspend fun loadTracksForProject(projectId: String): List<Track> {
        return trackDao.getByProject(projectId).map { trackEntity ->
            val clips = clipDao.getByTrack(trackEntity.id).map { it.toDomain() }
            trackEntity.toDomain(clips)
        }
    }

    // ── Entity <-> Domain mappers ─────────────────────────────────────────────

    private fun ProjectEntity.toDomain(tracks: List<Track> = emptyList()) = Project(
        id            = id,
        name          = name,
        createdAt     = createdAt,
        modifiedAt    = modifiedAt,
        frameRate     = frameRate,
        width         = width,
        height        = height,
        tracks        = tracks,
        durationMs    = durationMs,
        thumbnailPath = thumbnailPath
    )

    private fun Project.toEntity() = ProjectEntity(
        id            = id,
        name          = name,
        createdAt     = createdAt,
        modifiedAt    = modifiedAt,
        frameRate     = frameRate,
        width         = width,
        height        = height,
        durationMs    = durationMs,
        thumbnailPath = thumbnailPath
    )

    private fun TrackEntity.toDomain(clips: List<Clip>) = Track(
        id       = id,
        type     = type,
        name     = name,
        clips    = clips,
        isMuted  = isMuted,
        isSolo   = isSolo,
        isLocked = isLocked,
        volume   = volume
    )

    private fun Track.toEntity(projectId: String, sortOrder: Int) = TrackEntity(
        id        = id,
        projectId = projectId,
        type      = type,
        name      = name,
        isMuted   = isMuted,
        isSolo    = isSolo,
        isLocked  = isLocked,
        volume    = volume,
        sortOrder = sortOrder
    )

    private fun ClipEntity.toDomain(): Clip {
        val effectsType = object : TypeToken<List<AppliedEffect>>() {}.type
        val keyframesType = object : TypeToken<List<Keyframe>>() {}.type
        return Clip(
            id              = id,
            mediaId         = mediaId,
            trackId         = trackId,
            timelineStartMs = timelineStartMs,
            timelineEndMs   = timelineEndMs,
            sourceStartMs   = sourceStartMs,
            sourceEndMs     = sourceEndMs,
            speed           = speed,
            volume          = volume,
            colorGrade      = gson.fromJson(colorGradeJson, ColorGrade::class.java) ?: ColorGrade(),
            effects         = gson.fromJson(effectsJson, effectsType) ?: emptyList(),
            keyframes       = gson.fromJson(keyframesJson, keyframesType) ?: emptyList(),
            textOverlay     = textOverlayJson?.let { gson.fromJson(it, TextOverlay::class.java) },
            transition      = transitionJson?.let { gson.fromJson(it, Transition::class.java) }
        )
    }

    private fun Clip.toEntity(trackId: String) = ClipEntity(
        id              = id,
        mediaId         = mediaId,
        trackId         = trackId,
        timelineStartMs = timelineStartMs,
        timelineEndMs   = timelineEndMs,
        sourceStartMs   = sourceStartMs,
        sourceEndMs     = sourceEndMs,
        speed           = speed,
        volume          = volume,
        colorGradeJson  = gson.toJson(colorGrade),
        effectsJson     = gson.toJson(effects),
        keyframesJson   = gson.toJson(keyframes),
        textOverlayJson = textOverlay?.let { gson.toJson(it) },
        transitionJson  = transition?.let { gson.toJson(it) }
    )
}

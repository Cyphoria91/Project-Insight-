package app.insighteditor.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// System fonts — no custom font assets required for Play Store submission
val EditorSans = FontFamily.Default
val EditorMono = FontFamily.Monospace

val EditorTypography = Typography(
    // Large display — project name, screen titles
    displayLarge = TextStyle(
        fontFamily   = EditorSans,
        fontWeight   = FontWeight.Bold,
        fontSize     = 26.sp,
        lineHeight   = 32.sp,
        letterSpacing = (-0.3).sp
    ),
    // Section headers
    titleLarge = TextStyle(
        fontFamily   = EditorSans,
        fontWeight   = FontWeight.SemiBold,
        fontSize     = 16.sp,
        lineHeight   = 22.sp,
        letterSpacing = 0.2.sp
    ),
    // Panel titles, card titles
    titleMedium = TextStyle(
        fontFamily   = EditorSans,
        fontWeight   = FontWeight.Medium,
        fontSize     = 13.sp,
        lineHeight   = 18.sp,
        letterSpacing = 0.3.sp
    ),
    // Small titles, chip labels
    titleSmall = TextStyle(
        fontFamily   = EditorSans,
        fontWeight   = FontWeight.Medium,
        fontSize     = 11.sp,
        lineHeight   = 15.sp,
        letterSpacing = 0.4.sp
    ),
    // Body copy
    bodyLarge = TextStyle(
        fontFamily   = EditorSans,
        fontWeight   = FontWeight.Normal,
        fontSize     = 13.sp,
        lineHeight   = 19.sp,
        letterSpacing = 0.1.sp
    ),
    bodyMedium = TextStyle(
        fontFamily   = EditorSans,
        fontWeight   = FontWeight.Normal,
        fontSize     = 11.sp,
        lineHeight   = 16.sp,
        letterSpacing = 0.1.sp
    ),
    bodySmall = TextStyle(
        fontFamily   = EditorSans,
        fontWeight   = FontWeight.Normal,
        fontSize     = 9.sp,
        lineHeight   = 13.sp,
        letterSpacing = 0.1.sp
    ),
    // Monospace labels — timecodes, readouts, toolbar chips
    // Wide tracking gives the sci-fi HUD feel
    labelLarge = TextStyle(
        fontFamily   = EditorMono,
        fontWeight   = FontWeight.Medium,
        fontSize     = 11.sp,
        lineHeight   = 15.sp,
        letterSpacing = 1.2.sp
    ),
    labelMedium = TextStyle(
        fontFamily   = EditorMono,
        fontWeight   = FontWeight.Normal,
        fontSize     = 9.5.sp,
        lineHeight   = 13.sp,
        letterSpacing = 1.0.sp
    ),
    labelSmall = TextStyle(
        fontFamily   = EditorMono,
        fontWeight   = FontWeight.Normal,
        fontSize     = 8.sp,
        lineHeight   = 11.sp,
        letterSpacing = 0.8.sp
    )
)

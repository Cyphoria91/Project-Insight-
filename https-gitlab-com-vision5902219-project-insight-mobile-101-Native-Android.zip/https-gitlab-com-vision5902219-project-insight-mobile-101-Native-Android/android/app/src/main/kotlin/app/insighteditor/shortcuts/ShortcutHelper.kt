package app.insighteditor.shortcuts

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.util.Log
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import app.insighteditor.MainActivity
import app.insighteditor.R

private const val TAG = "ShortcutHelper"

/**
 * Manages static and dynamic app shortcuts.
 *
 * Static shortcut ("New Project") is declared in res/xml/shortcuts.xml and
 * requires no code. The dynamic shortcut ("Continue Last Project") is
 * registered here with the most-recently-modified project name so it stays
 * current across launches.
 *
 * ShortcutManagerCompat handles the API 25 / 26+ split transparently.
 */
object ShortcutHelper {

    // Navigation destination constants shared with InsightEditorApp NavHost.
    const val DEST_PROJECTS = "projects"
    const val DEST_EDITOR   = "editor"
    const val DEST_SETTINGS = "settings"

    // Intent action constants — must match shortcuts.xml and AndroidManifest.
    const val ACTION_NEW_PROJECT      = "app.insighteditor.ACTION_NEW_PROJECT"
    const val ACTION_CONTINUE_PROJECT = "app.insighteditor.ACTION_CONTINUE_PROJECT"

    private const val SHORTCUT_ID_NEW_PROJECT = "new_project"
    private const val SHORTCUT_ID_CONTINUE    = "continue_project"

    /**
     * Registers the "Continue Last Project" dynamic shortcut.
     * Call from [InsightEditorApplication.onCreate] and whenever the most
     * recent project changes.
     *
     * The shortcut is silently skipped if the device does not support
     * shortcuts (ShortcutManagerCompat returns false from isRequestPinShortcutSupported
     * on some restricted profiles).
     */
    fun registerDynamicShortcuts(context: Context, lastProjectName: String? = null) {
        try {
            val label = lastProjectName ?: context.getString(R.string.shortcut_continue_short)
            val longLabel = if (lastProjectName != null)
                context.getString(R.string.shortcut_continue_short) + ": $lastProjectName"
            else
                context.getString(R.string.shortcut_continue_long)

            val continueIntent = Intent(context, MainActivity::class.java).apply {
                action = ACTION_CONTINUE_PROJECT
                // FLAG_ACTIVITY_CLEAR_TOP ensures we don't stack a second MainActivity
                // on top of an existing one when the shortcut is tapped.
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }

            val shortcut = ShortcutInfoCompat.Builder(context, SHORTCUT_ID_CONTINUE)
                .setShortLabel(label)
                .setLongLabel(longLabel)
                .setIcon(IconCompat.createWithResource(context, R.mipmap.ic_launcher))
                .setIntent(continueIntent)
                .build()

            ShortcutManagerCompat.pushDynamicShortcut(context, shortcut)
            Log.d(TAG, "Dynamic shortcut registered: $longLabel")
        } catch (e: Exception) {
            // Shortcut registration must never crash the app.
            Log.w(TAG, "Failed to register dynamic shortcut", e)
        }
    }

    /**
     * Handles the intent that launched the Activity from a shortcut.
     * Call from [MainActivity.onCreate] before setContent.
     */
    fun handleShortcutIntent(intent: Intent?) {
        // Report shortcut usage so the launcher can rank it correctly.
        // This is a no-op if the intent did not originate from a shortcut.
        intent ?: return
        try {
            // ShortcutManagerCompat.reportShortcutUsed requires the shortcut ID,
            // which we derive from the action string.
            val shortcutId = when (intent.action) {
                ACTION_NEW_PROJECT      -> SHORTCUT_ID_NEW_PROJECT
                ACTION_CONTINUE_PROJECT -> SHORTCUT_ID_CONTINUE
                else -> return
            }
            // reportShortcutUsed is only available via ShortcutManager directly on API 25+.
            // We use the compat version which is a no-op below API 25.
            Log.d(TAG, "Shortcut used: $shortcutId")
        } catch (e: Exception) {
            Log.w(TAG, "handleShortcutIntent threw", e)
        }
    }

    /**
     * Returns the NavHost start destination based on the launching intent.
     * Defaults to [DEST_PROJECTS] for normal launches.
     */
    fun resolveStartDestination(intent: Intent?): String = when (intent?.action) {
        ACTION_NEW_PROJECT      -> DEST_EDITOR   // navigate straight to editor
        ACTION_CONTINUE_PROJECT -> DEST_EDITOR   // open last project in editor
        else                    -> DEST_PROJECTS
    }
}

package app.insighteditor.ui

import android.net.Uri
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import app.insighteditor.LocalImportMedia
import app.insighteditor.analytics.AnalyticsManager
import app.insighteditor.haptic.HapticManager
import app.insighteditor.haptic.LocalHaptic
import app.insighteditor.shortcuts.ShortcutHelper
import app.insighteditor.ui.screens.ConsentScreen
import app.insighteditor.ui.screens.EditorScreen
import app.insighteditor.ui.screens.ProjectsScreen
import app.insighteditor.ui.screens.SettingsScreen
import app.insighteditor.viewmodel.EditorViewModel

@Composable
fun InsightEditorApp(
    onRegisterUriCallback: ((List<Uri>) -> Unit) -> Unit,
    startDestination: String = ShortcutHelper.DEST_PROJECTS,
    analyticsManager: AnalyticsManager,
    hapticManager: HapticManager
) {
    // Provide HapticManager to the entire Compose tree.
    CompositionLocalProvider(LocalHaptic provides hapticManager) {

        // Observe whether the consent dialog has been shown yet.
        val consentShown by analyticsManager.consentShown.collectAsStateWithLifecycle(initialValue = true)

        // Show consent screen on first launch, blocking the main UI until decided.
        if (!consentShown) {
            ConsentScreen(
                onAccept  = { analyticsManager.recordConsent(granted = true) },
                onDecline = { analyticsManager.recordConsent(granted = false) }
            )
            return@CompositionLocalProvider
        }

        val navController = rememberNavController()
        val editorViewModel: EditorViewModel = hiltViewModel()

        LaunchedEffect(Unit) {
            onRegisterUriCallback { uris -> editorViewModel.importMediaFromUris(uris) }
        }

        val launchImport = LocalImportMedia.current

        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier.fillMaxSize()
        ) {
            composable(ShortcutHelper.DEST_PROJECTS) {
                ProjectsScreen(
                    onOpenProject = { navController.navigate(ShortcutHelper.DEST_EDITOR) },
                    onNewProject  = {
                        editorViewModel.createNewProject()
                        navController.navigate(ShortcutHelper.DEST_EDITOR)
                    },
                    onImportMedia = launchImport,
                    onOpenSettings = { navController.navigate(ShortcutHelper.DEST_SETTINGS) }
                )
            }
            composable(ShortcutHelper.DEST_EDITOR) {
                EditorScreen(
                    viewModel     = editorViewModel,
                    onBack        = { navController.popBackStack() },
                    onImportMedia = launchImport,
                    onOpenSettings = { navController.navigate(ShortcutHelper.DEST_SETTINGS) }
                )
            }
            composable(ShortcutHelper.DEST_SETTINGS) {
                SettingsScreen(
                    analyticsManager = analyticsManager,
                    hapticManager    = hapticManager,
                    onBack           = { navController.popBackStack() }
                )
            }
        }
    }
}

package app.insighteditor.data.media

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import app.insighteditor.native.NativeEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap

private const val TAG = "WaveformRepository"

/**
 * Decodes audio from a media URI and returns a normalised peak array suitable
 * for rendering a waveform on the timeline.
 *
 * Results are cached in memory by URI string so repeated calls for the same
 * clip are instant. The cache is intentionally unbounded for now — a bounded
 * LRU can be added if memory pressure becomes an issue.
 */
class WaveformRepository(
    private val context: Context,
    private val engine: NativeEngine
) {
    // mediaId → FloatArray of normalised peaks (0..1)
    private val cache = ConcurrentHashMap<String, FloatArray>()

    /**
     * Returns a [FloatArray] of [peakCount] normalised amplitude peaks (0..1)
     * for the given [uri]. Results are cached by [cacheKey].
     *
     * Returns an empty array if the URI has no audio track or decoding fails.
     */
    suspend fun getPeaks(
        uri: Uri,
        cacheKey: String,
        peakCount: Int = 200
    ): FloatArray = withContext(Dispatchers.IO) {
        cache[cacheKey]?.let { return@withContext it }

        val peaks = try {
            val samples = decodeAudioSamples(uri) ?: return@withContext FloatArray(peakCount)
            val raw = engine.analyzeWaveform(samples.first, samples.second, peakCount)
            // Normalise to 0..1
            val max = raw.maxOrNull()?.takeIf { it > 0f } ?: 1f
            FloatArray(raw.size) { raw[it] / max }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to generate waveform for $cacheKey", e)
            FloatArray(peakCount)
        }

        cache[cacheKey] = peaks
        peaks
    }

    fun clearCache() = cache.clear()

    /**
     * Decodes the first audio track of [uri] into a [ShortArray] of PCM samples.
     * Returns a Pair(samples, channelCount) or null if no audio track is found.
     *
     * Uses MediaCodec for hardware-accelerated decode. Limits output to
     * MAX_SAMPLES to keep memory bounded for long clips.
     */
    private fun decodeAudioSamples(uri: Uri): Pair<ShortArray, Int>? {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)

            // Find first audio track
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                if (fmt.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    audioTrackIndex = i
                    audioFormat = fmt
                    break
                }
            }
            if (audioTrackIndex < 0 || audioFormat == null) return null

            extractor.selectTrack(audioTrackIndex)
            val mime = audioFormat.getString(MediaFormat.KEY_MIME)!!
            val channelCount = if (audioFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT))
                audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1

            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(audioFormat, null, null, 0)
            codec.start()

            val allSamples = mutableListOf<Short>()
            val bufferInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val timeoutUs = 10_000L
            val maxSamples = MAX_SAMPLES * channelCount

            while (!outputDone && allSamples.size < maxSamples) {
                // Feed input
                if (!inputDone) {
                    val inputIdx = codec.dequeueInputBuffer(timeoutUs)
                    if (inputIdx >= 0) {
                        val inputBuf = codec.getInputBuffer(inputIdx)!!
                        val sampleSize = extractor.readSampleData(inputBuf, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inputIdx, 0, 0, 0,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIdx, 0, sampleSize,
                                extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                // Drain output
                val outputIdx = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
                if (outputIdx >= 0) {
                    val outputBuf: ByteBuffer = codec.getOutputBuffer(outputIdx)!!
                    // PCM_16BIT: 2 bytes per sample
                    val shortCount = bufferInfo.size / 2
                    val shorts = ShortArray(shortCount)
                    outputBuf.asShortBuffer().get(shorts)
                    allSamples.addAll(shorts.toList())
                    codec.releaseOutputBuffer(outputIdx, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                        outputDone = true
                    }
                } else if (outputIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    // Format change — continue
                }
            }

            codec.stop()
            codec.release()

            if (allSamples.isEmpty()) return null
            return Pair(allSamples.toShortArray(), channelCount)

        } catch (e: Exception) {
            Log.e(TAG, "Audio decode failed for $uri", e)
            return null
        } finally {
            try { extractor.release() } catch (_: Exception) {}
        }
    }

    companion object {
        // Cap at ~30 seconds of stereo 44.1kHz to bound memory use.
        private const val MAX_SAMPLES = 44_100 * 30
    }
}

package app.insighteditor.data.media

import android.content.Context
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Choreographer
import android.view.Display
import androidx.core.content.getSystemService
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

private const val TAG = "PlaybackEngine"

data class PlaybackState(
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val bufferedPercent: Int = 0,
    val error: String? = null,
    val isBuffering: Boolean = false
)

/**
 * Wraps ExoPlayer with a StateFlow-based state surface and adaptive-refresh-rate
 * position polling via [Choreographer].
 *
 * ## Adaptive refresh rate
 * The position tick loop uses [Choreographer.postFrameCallback] instead of a
 * fixed `delay(16L)`. This means:
 *  - On 60 Hz devices: ~16.7 ms per frame (same as before)
 *  - On 90 Hz devices: ~11.1 ms per frame (smoother scrubber)
 *  - On 120 Hz devices: ~8.3 ms per frame (buttery smooth)
 *
 * [DisplayManager.DisplayListener] is registered to react to runtime refresh-rate
 * changes (e.g. LPDDR5 adaptive sync, Game Mode on Samsung/Pixel).
 *
 * ## Battery saving
 * The Choreographer callback is only posted while [isPlaying] is true. When
 * paused, no callbacks are scheduled — zero CPU overhead from the tick loop.
 *
 * ## Thread safety
 * All ExoPlayer calls are dispatched to the main thread. StateFlow updates
 * are thread-safe. [Choreographer] callbacks always fire on the main thread.
 *
 * Lifecycle: call [destroy] from ViewModel.onCleared().
 */
class PlaybackEngine(private val context: Context) {

    private var player: ExoPlayer? = null

    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state.asStateFlow()

    private val mainHandler = Handler(Looper.getMainLooper())
    private val choreographer: Choreographer = Choreographer.getInstance()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Current display refresh rate in Hz — updated by DisplayListener.
    @Volatile private var displayRefreshRateHz: Float = 60f

    // Whether the frame callback is currently scheduled.
    @Volatile private var frameCallbackActive = false

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayChanged(displayId: Int) {
            if (displayId == Display.DEFAULT_DISPLAY) {
                updateRefreshRate()
            }
        }
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
    }

    init {
        updateRefreshRate()
        context.getSystemService<DisplayManager>()
            ?.registerDisplayListener(displayListener, mainHandler)
    }

    // ── Frame callback ────────────────────────────────────────────────────────

    /**
     * Choreographer frame callback — fires once per display vsync while playing.
     * Reads ExoPlayer position and re-posts itself for the next frame.
     *
     * The callback is intentionally not a lambda field to avoid allocation on
     * every frame. It is a named inner object so the JVM can reuse the instance.
     */
    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            val exo = player
            if (exo == null || !exo.isPlaying) {
                frameCallbackActive = false
                return
            }
            try {
                _state.value = _state.value.copy(
                    positionMs      = exo.currentPosition.coerceAtLeast(0L),
                    bufferedPercent = exo.bufferedPercentage
                )
            } catch (e: Exception) {
                Log.w(TAG, "Frame callback position read threw", e)
            }
            // Re-post for the next vsync — adaptive to whatever Hz the display is at.
            choreographer.postFrameCallback(this)
        }
    }

    private fun startFrameCallback() {
        if (frameCallbackActive) return
        frameCallbackActive = true
        choreographer.postFrameCallback(frameCallback)
    }

    private fun stopFrameCallback() {
        frameCallbackActive = false
        choreographer.removeFrameCallback(frameCallback)
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Prepares a new media item for playback. Any previously prepared item
     * is released first. Must be called from the main thread.
     */
    fun prepare(uri: Uri) {
        release()
        _state.value = PlaybackState(isBuffering = true)
        try {
            player = ExoPlayer.Builder(context).build().also { exo ->
                exo.setMediaItem(MediaItem.fromUri(uri))
                exo.prepare()
                exo.addListener(object : Player.Listener {

                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        _state.value = _state.value.copy(isPlaying = isPlaying)
                        if (isPlaying) startFrameCallback() else stopFrameCallback()
                    }

                    override fun onPlaybackStateChanged(state: Int) {
                        when (state) {
                            Player.STATE_READY -> _state.value = _state.value.copy(
                                durationMs  = exo.duration.coerceAtLeast(0L),
                                isBuffering = false,
                                error       = null
                            )
                            Player.STATE_BUFFERING -> _state.value = _state.value.copy(isBuffering = true)
                            Player.STATE_ENDED -> {
                                stopFrameCallback()
                                _state.value = _state.value.copy(isPlaying = false, isBuffering = false)
                            }
                            Player.STATE_IDLE -> _state.value = _state.value.copy(isBuffering = false)
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        Log.e(TAG, "ExoPlayer error: ${error.errorCodeName}", error)
                        stopFrameCallback()
                        _state.value = _state.value.copy(
                            isPlaying   = false,
                            isBuffering = false,
                            error       = buildUserFacingError(error)
                        )
                    }
                })
            }
        } catch (e: Exception) {
            Log.e(TAG, "ExoPlayer.Builder failed", e)
            _state.value = PlaybackState(error = "Failed to initialise player: ${e.message}")
        }
    }

    fun play() {
        try { player?.play() } catch (e: Exception) { Log.e(TAG, "play() threw", e) }
    }

    fun pause() {
        try { player?.pause() } catch (e: Exception) { Log.e(TAG, "pause() threw", e) }
    }

    fun seekTo(ms: Long) {
        try { player?.seekTo(ms.coerceAtLeast(0L)) } catch (e: Exception) { Log.e(TAG, "seekTo threw", e) }
    }

    fun setVolume(v: Float) {
        try { player?.volume = v.coerceIn(0f, 1f) } catch (e: Exception) { Log.e(TAG, "setVolume threw", e) }
    }

    fun setPlaybackSpeed(speed: Float) {
        try { player?.setPlaybackSpeed(speed.coerceIn(0.1f, 8f)) } catch (e: Exception) { Log.e(TAG, "setPlaybackSpeed threw", e) }
    }

    fun getCurrentPosition(): Long = try { player?.currentPosition ?: 0L } catch (e: Exception) { 0L }
    fun getDuration(): Long = try { player?.duration?.coerceAtLeast(0L) ?: 0L } catch (e: Exception) { 0L }
    fun getPlayer(): ExoPlayer? = player

    /** Releases the current player instance. Safe to call multiple times. */
    fun release() {
        stopFrameCallback()
        try { player?.release() } catch (e: Exception) { Log.e(TAG, "player.release() threw", e) }
        player = null
        _state.value = PlaybackState()
    }

    /**
     * Permanently shuts down the engine. Call from ViewModel.onCleared().
     * After this call the engine cannot be reused.
     */
    fun destroy() {
        release()
        context.getSystemService<DisplayManager>()?.unregisterDisplayListener(displayListener)
        scope.cancel()
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private fun updateRefreshRate() {
        try {
            val dm = context.getSystemService<DisplayManager>() ?: return
            val display = dm.getDisplay(Display.DEFAULT_DISPLAY) ?: return
            displayRefreshRateHz = display.refreshRate.coerceIn(30f, 240f)
            Log.d(TAG, "Display refresh rate: ${displayRefreshRateHz}Hz")
        } catch (e: Exception) {
            Log.w(TAG, "Could not read display refresh rate", e)
        }
    }

    private fun buildUserFacingError(error: PlaybackException): String = when (error.errorCode) {
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
            "Network error — check your connection and try again"
        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
            "Media file not found"
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ->
            "No compatible decoder found for this format"
        PlaybackException.ERROR_CODE_DECODING_FAILED ->
            "Decoding error — the file may be corrupted"
        PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED,
        PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED ->
            "Audio output error"
        else -> "Playback error (${error.errorCodeName})"
    }
}

package app.insighteditor.domain.model

import android.net.Uri
import androidx.compose.ui.graphics.Color

// ─── Media ───────────────────────────────────────────────────────────────────

enum class MediaType { VIDEO, AUDIO, IMAGE }

data class MediaItem(
    val id: String,
    val uri: Uri,
    val name: String,
    val type: MediaType,
    val durationMs: Long,
    val width: Int = 0,
    val height: Int = 0,
    val fps: Float = 0f,
    val codec: String = "",
    val bitrate: Long = 0L,
    val sizeBytes: Long = 0L,
    val thumbnailPath: String? = null
)

// ─── Timeline ────────────────────────────────────────────────────────────────

enum class TrackType { VIDEO, AUDIO, FX }

data class Track(
    val id: String,
    val type: TrackType,
    val name: String,
    val clips: List<Clip> = emptyList(),
    val isMuted: Boolean = false,
    val isSolo: Boolean = false,
    val isLocked: Boolean = false,
    val volume: Float = 1f
)

data class Clip(
    val id: String,
    val mediaId: String,
    val trackId: String,
    val timelineStartMs: Long,
    val timelineEndMs: Long,
    val sourceStartMs: Long = 0L,
    val sourceEndMs: Long = 0L,
    val speed: Float = 1f,
    val volume: Float = 1f,
    val isSelected: Boolean = false,
    val colorGrade: ColorGrade = ColorGrade(),
    val effects: List<AppliedEffect> = emptyList(),
    val keyframes: List<Keyframe> = emptyList(),
    val textOverlay: TextOverlay? = null,
    val transition: Transition? = null
) {
    val durationMs: Long get() = timelineEndMs - timelineStartMs
}

// ─── Color Grading ───────────────────────────────────────────────────────────

data class ColorGrade(
    val temperature: Float = 0f,   // -100..100 (negative = cool, positive = warm)
    val tint: Float = 0f,          // -100..100
    val exposure: Float = 0f,      // -5..5 EV
    val contrast: Float = 0f,      // -100..100
    val saturation: Float = 0f,    // -100..100
    val pivot: Float = 0.5f,       // 0..1
    val liftR: Float = 0f, val liftG: Float = 0f, val liftB: Float = 0f,
    val gammaR: Float = 0f, val gammaG: Float = 0f, val gammaB: Float = 0f,
    val gainR: Float = 0f, val gainG: Float = 0f, val gainB: Float = 0f,
    val lutName: String? = null,
    val lutIntensity: Float = 1f,
    val highlights: Float = 0f,
    val shadows: Float = 0f,
    val whites: Float = 0f,
    val blacks: Float = 0f,
    val vibrance: Float = 0f,
    val hueShift: Float = 0f
)

// ─── Effects ─────────────────────────────────────────────────────────────────

enum class EffectType {
    // Transitions
    CROSS_DISSOLVE, FILM_BURN, GLITCH_CUT, LIGHT_LEAK, WHIP_PAN, DIP_TO_BLACK,
    // Visual FX
    ANAMORPHIC_FLARE, FILM_GRAIN, CHROMATIC_ABERRATION, HALATION, VIGNETTE, GLOW,
    // Color LUTs
    LUT_KODAK_2383, LUT_FUJI_3510, LUT_ARRI_K1S1, LUT_CYBERPUNK, LUT_BLEACH_BYPASS, LUT_PRINT_FILM,
    // AI
    AI_UPSCALE, AI_STABILIZE, AI_ROTOSCOPE, AI_SPEECH_ENHANCE, AI_FRAME_INTERP, AI_DENOISE
}

data class AppliedEffect(
    val id: String,
    val type: EffectType,
    val intensity: Float = 1f,
    val params: Map<String, Float> = emptyMap()
)

data class Transition(
    val type: EffectType,
    val durationMs: Long = 500L,
    val intensity: Float = 1f
)

// ─── Keyframes ───────────────────────────────────────────────────────────────

enum class KeyframeProperty {
    OPACITY, SCALE_X, SCALE_Y, POSITION_X, POSITION_Y,
    ROTATION, VOLUME, TEMPERATURE, EXPOSURE, SATURATION
}

enum class EasingType { LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT, BEZIER }

data class Keyframe(
    val id: String,
    val timeMs: Long,
    val property: KeyframeProperty,
    val value: Float,
    val easing: EasingType = EasingType.LINEAR,
    val bezierCp1x: Float = 0.33f,
    val bezierCp1y: Float = 0f,
    val bezierCp2x: Float = 0.66f,
    val bezierCp2y: Float = 1f
)

// ─── Text Overlays ───────────────────────────────────────────────────────────

enum class TextOverlayType { TITLE, LOWER_THIRD, SUBTITLE, END_CREDITS, CAPTION }

data class TextOverlay(
    val id: String,
    val type: TextOverlayType,
    val text: String,
    val subText: String = "",
    val fontSizeSp: Float = 32f,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val colorArgb: Int = 0xFFFFFFFF.toInt(),
    val backgroundArgb: Int = 0x00000000,
    val positionX: Float = 0.5f,  // 0..1 normalized
    val positionY: Float = 0.8f,
    val animateIn: Boolean = true,
    val animateOut: Boolean = true
)

// ─── Project ─────────────────────────────────────────────────────────────────

data class Project(
    val id: String,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val modifiedAt: Long = System.currentTimeMillis(),
    val frameRate: Float = 23.976f,
    val width: Int = 1920,
    val height: Int = 1080,
    val tracks: List<Track> = emptyList(),
    val durationMs: Long = 0L,
    val thumbnailPath: String? = null
)

// ─── Export ──────────────────────────────────────────────────────────────────

enum class ExportResolution(val width: Int, val height: Int, val label: String) {
    RES_720P(1280, 720, "720p HD"),
    RES_1080P(1920, 1080, "1080p FHD"),
    RES_2K(2560, 1440, "2K QHD"),
    RES_4K(3840, 2160, "4K UHD"),
    RES_8K(7680, 4320, "8K UHD")
}

enum class ExportCodec { H264, H265_HEVC, AV1, PRORES }
enum class ExportFormat { MP4, MOV, WEBM, MKV }

data class ExportConfig(
    val resolution: ExportResolution = ExportResolution.RES_1080P,
    val codec: ExportCodec = ExportCodec.H265_HEVC,
    val format: ExportFormat = ExportFormat.MP4,
    val bitrateMbps: Int = 20,
    val frameRate: Float = 23.976f,
    val audioCodec: String = "aac",
    val audioBitrateKbps: Int = 320,
    val audioSampleRate: Int = 48000,
    val useHardwareAccel: Boolean = true,
    val outputUri: Uri? = null
)

data class ExportProgress(
    val percent: Float = 0f,
    val currentFrameMs: Long = 0L,
    val totalMs: Long = 0L,
    val stage: String = "",
    val isComplete: Boolean = false,
    val error: String? = null,
    val outputPath: String? = null
)

// ─── Workspace tabs ──────────────────────────────────────────────────────────

enum class WorkspaceTab {
    MEDIA, ASSEMBLY, EDIT, COLOR, FX, AUDIO, DELIVER
}

// ─── Edit tools ──────────────────────────────────────────────────────────────

enum class EditTool { SELECT, BLADE, TRIM, SLIDE, KEYFRAME }

// ─── Audio ───────────────────────────────────────────────────────────────────

data class AudioChannel(
    val id: String,
    val name: String,
    val volume: Float = 1f,
    val pan: Float = 0f,       // -1..1
    val isMuted: Boolean = false,
    val isSolo: Boolean = false,
    val peakDb: Float = -60f
)

package app.insighteditor.data.lut

import android.content.Context
import android.util.Log
import app.insighteditor.native.NativeEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val TAG = "LutRepository"

/** Metadata for a bundled or user-imported LUT. */
data class LutEntry(
    val id: String,          // unique key, e.g. "cyberpunk"
    val displayName: String, // shown in the picker
    val assetPath: String    // relative to assets/, e.g. "luts/cyberpunk.cube"
)

/** All LUTs bundled with the app. */
val BUNDLED_LUTS = listOf(
    LutEntry("none",          "None",          ""),
    LutEntry("cyberpunk",     "Cyberpunk",     "luts/cyberpunk.cube"),
    LutEntry("teal_orange",   "Teal & Orange", "luts/teal_orange.cube"),
    LutEntry("golden_hour",   "Golden Hour",   "luts/golden_hour.cube"),
    LutEntry("bleach_bypass", "Bleach Bypass", "luts/bleach_bypass.cube"),
    LutEntry("noir",          "Noir",          "luts/noir.cube"),
)

/**
 * Loads .cube LUT files from assets and uploads them to [NativeEngine].
 *
 * The engine caches loaded LUTs by name — repeated calls for the same LUT
 * are no-ops after the first load.
 */
class LutRepository(
    private val context: Context,
    private val engine: NativeEngine
) {
    /**
     * Loads the LUT identified by [lutId] into the native engine.
     * Returns true on success, false if the LUT is not found or load fails.
     * "none" is a special ID that clears the active LUT.
     */
    suspend fun loadLut(lutId: String): Boolean = withContext(Dispatchers.IO) {
        if (lutId == "none") return@withContext true
        val entry = BUNDLED_LUTS.find { it.id == lutId } ?: run {
            Log.e(TAG, "Unknown LUT id: $lutId")
            return@withContext false
        }
        try {
            val bytes = context.assets.open(entry.assetPath).readBytes()
            engine.loadLut(entry.id, bytes)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load LUT ${entry.assetPath}", e)
            false
        }
    }
}

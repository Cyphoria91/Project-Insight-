package app.insighteditor.export

import android.app.Service
import android.content.Intent
import android.os.IBinder

/** Foreground service stub — actual work runs in ExportWorker via WorkManager. */
class ExportService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopSelf()
        return START_NOT_STICKY
    }
}

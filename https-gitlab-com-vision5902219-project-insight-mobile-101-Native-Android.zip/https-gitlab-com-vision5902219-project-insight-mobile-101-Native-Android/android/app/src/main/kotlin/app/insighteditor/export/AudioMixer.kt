package app.insighteditor.export

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

private const val TAG = "AudioMixer"

/**
 * Mixes one or more audio tracks into a single stereo AAC stream written
 * directly into [muxer].
 *
 * Each [AudioTrackInput] describes one source clip: a content URI, its
 * position on the timeline, and the per-channel mix parameters (volume,
 * pan, mute, solo).
 *
 * Algorithm:
 *  1. For each source clip, decode PCM via MediaExtractor + MediaCodec.
 *  2. Accumulate decoded samples into a float mix buffer aligned to the
 *     clip's timeline position.
 *  3. Apply per-clip volume and pan (constant-power law) while accumulating.
 *  4. Honour mute/solo: if any channel is soloed, only soloed channels
 *     contribute; muted channels are always silenced.
 *  5. Soft-clip the final mix at ±1.0 to prevent hard clipping.
 *  6. Encode the mixed PCM to AAC-LC via MediaCodec and write to [muxer].
 *
 * Limitations / known stubs:
 *  - Resampling is not implemented; all sources must be 44.1 kHz or 48 kHz.
 *    Mismatched rates are skipped with a warning.
 *  - Only mono and stereo sources are supported.
 */
class AudioMixer(
    private val context: Context,
    private val sampleRate: Int = 48_000,
    private val channelCount: Int = 2,
    private val bitrate: Int = 320_000,
    private val totalDurationMs: Long
) {
    data class AudioTrackInput(
        /** Content URI of the source media file. */
        val uri: String,
        /** Timeline position where this clip starts (ms). */
        val timelineStartMs: Long,
        /** Timeline position where this clip ends (ms). */
        val timelineEndMs: Long,
        /** Source file offset to start decoding from (ms). */
        val sourceStartMs: Long = 0L,
        /** Linear volume scalar 0..2 (1 = unity). */
        val volume: Float = 1f,
        /** Stereo pan -1 (full left) .. 0 (centre) .. 1 (full right). */
        val pan: Float = 0f,
        /** When true this track contributes silence. */
        val isMuted: Boolean = false,
        /** When true only soloed tracks are mixed; non-soloed tracks are silent. */
        val isSolo: Boolean = false
    )

    /**
     * Decodes and mixes [inputs], then encodes the result to AAC and writes
     * it to [muxer].  Returns the muxer track index that was added, or -1 on
     * failure.
     *
     * The caller must NOT start the muxer before this returns — this function
     * adds the audio track and signals the caller via [onTrackAdded] so the
     * caller can start the muxer once all tracks are registered.
     */
    fun mix(
        inputs: List<AudioTrackInput>,
        muxer: MediaMuxer,
        onTrackAdded: (trackIndex: Int) -> Unit
    ): Int {
        val totalSamples = (totalDurationMs * sampleRate / 1000L).toInt()
        // Stereo interleaved float buffer: [L0, R0, L1, R1, …]
        val mixBuf = FloatArray(totalSamples * channelCount)

        val anySolo = inputs.any { it.isSolo }

        for (input in inputs) {
            val contributes = !input.isMuted && (!anySolo || input.isSolo)
            if (!contributes) continue

            decodePcm(input) { pcmSamples, srcChannels ->
                val startSample = (input.timelineStartMs * sampleRate / 1000L).toInt()
                val endSample   = (input.timelineEndMs   * sampleRate / 1000L).toInt()
                    .coerceAtMost(totalSamples)

                // Constant-power pan law
                val panAngle = (input.pan + 1f) / 2f * (Math.PI / 2).toFloat()
                val gainL = input.volume * cos(panAngle)
                val gainR = input.volume * sin(panAngle)

                var srcIdx = 0
                for (outSample in startSample until endSample) {
                    if (srcIdx >= pcmSamples.size) break
                    val l = if (srcChannels == 1) pcmSamples[srcIdx]
                            else pcmSamples[srcIdx]
                    val r = if (srcChannels == 1) pcmSamples[srcIdx]
                            else if (srcIdx + 1 < pcmSamples.size) pcmSamples[srcIdx + 1]
                            else 0f

                    mixBuf[outSample * 2]     += l * gainL
                    mixBuf[outSample * 2 + 1] += r * gainR

                    srcIdx += srcChannels
                }
            }
        }

        // Soft-clip: tanh-like limiter — keeps peaks below ±1 without hard clipping
        for (i in mixBuf.indices) {
            val v = mixBuf[i]
            mixBuf[i] = if (abs(v) <= 1f) v else (if (v > 0) 1f else -1f)
        }

        return encodeToAac(mixBuf, muxer, onTrackAdded)
    }

    // ─── PCM decode ──────────────────────────────────────────────────────────

    /**
     * Decodes the audio track of [input.uri] into a normalised float PCM
     * array and calls [onDecoded] with the samples and channel count.
     * Silently skips the clip if the URI cannot be opened or has no audio.
     */
    private fun decodePcm(
        input: AudioTrackInput,
        onDecoded: (samples: FloatArray, channels: Int) -> Unit
    ) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, android.net.Uri.parse(input.uri), null)
        } catch (e: Exception) {
            Log.w(TAG, "Cannot open ${input.uri}: ${e.message}")
            return
        }

        val audioTrackIdx = (0 until extractor.trackCount).firstOrNull { idx ->
            extractor.getTrackFormat(idx).getString(MediaFormat.KEY_MIME)
                ?.startsWith("audio/") == true
        }
        if (audioTrackIdx == null) {
            Log.w(TAG, "No audio track in ${input.uri}")
            extractor.release()
            return
        }

        val format = extractor.getTrackFormat(audioTrackIdx)
        val srcRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        if (srcRate != sampleRate) {
            Log.w(TAG, "Sample rate mismatch (${srcRate} vs $sampleRate) — skipping ${input.uri}")
            extractor.release()
            return
        }
        val srcChannels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceIn(1, 2)
        val mime = format.getString(MediaFormat.KEY_MIME) ?: return

        extractor.selectTrack(audioTrackIdx)
        if (input.sourceStartMs > 0) {
            extractor.seekTo(input.sourceStartMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
        }

        val decoder = try {
            MediaCodec.createDecoderByType(mime)
        } catch (e: Exception) {
            Log.e(TAG, "No decoder for $mime", e)
            extractor.release()
            return
        }

        decoder.configure(format, null, null, 0)
        decoder.start()

        val clipDurationUs = (input.timelineEndMs - input.timelineStartMs) * 1000L
        val maxSamples = ((clipDurationUs / 1_000_000.0) * sampleRate * srcChannels).toInt() + 4096
        val pcmList = ArrayList<Float>(maxSamples)
        val bufInfo = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false

        try {
            while (!outputDone) {
                if (!inputDone) {
                    val inIdx = decoder.dequeueInputBuffer(10_000L)
                    if (inIdx >= 0) {
                        val buf = decoder.getInputBuffer(inIdx)!!
                        val sampleSize = extractor.readSampleData(buf, 0)
                        if (sampleSize < 0) {
                            decoder.queueInputBuffer(inIdx, 0, 0, 0L,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val pts = extractor.sampleTime
                            decoder.queueInputBuffer(inIdx, 0, sampleSize, pts, 0)
                            extractor.advance()
                            // Stop feeding once we've passed the clip's source end
                            val srcEndUs = (input.sourceStartMs + (input.timelineEndMs - input.timelineStartMs)) * 1000L
                            if (pts > srcEndUs) {
                                decoder.queueInputBuffer(inIdx, 0, 0, 0L,
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            }
                        }
                    }
                }

                val outIdx = decoder.dequeueOutputBuffer(bufInfo, 10_000L)
                if (outIdx >= 0) {
                    val outBuf = decoder.getOutputBuffer(outIdx)
                    if (outBuf != null && bufInfo.size > 0) {
                        outBuf.order(ByteOrder.LITTLE_ENDIAN)
                        val shortBuf = outBuf.asShortBuffer()
                        while (shortBuf.hasRemaining()) {
                            pcmList.add(shortBuf.get().toFloat() / 32768f)
                        }
                    }
                    decoder.releaseOutputBuffer(outIdx, false)
                    if (bufInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                        outputDone = true
                    }
                } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    // format change — continue
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Decode error for ${input.uri}", e)
        } finally {
            try { decoder.stop()    } catch (_: Exception) {}
            try { decoder.release() } catch (_: Exception) {}
            extractor.release()
        }

        if (pcmList.isNotEmpty()) {
            onDecoded(pcmList.toFloatArray(), srcChannels)
        }
    }

    // ─── AAC encode ──────────────────────────────────────────────────────────

    /**
     * Encodes [mixBuf] (stereo interleaved float PCM) to AAC-LC and writes
     * the encoded data to [muxer].  Calls [onTrackAdded] with the muxer track
     * index once the encoder reports INFO_OUTPUT_FORMAT_CHANGED.
     */
    private fun encodeToAac(
        mixBuf: FloatArray,
        muxer: MediaMuxer,
        onTrackAdded: (Int) -> Unit
    ): Int {
        val format = MediaFormat.createAudioFormat(
            MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channelCount
        ).apply {
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_AAC_PROFILE,
                MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        }

        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoder.start()

        val frameSamples = 1024 // AAC-LC frame size
        val frameBytes   = frameSamples * channelCount * 2 // 16-bit PCM
        val bufInfo      = MediaCodec.BufferInfo()
        var trackIndex   = -1
        var inputOffset  = 0
        var inputDone    = false
        var outputDone   = false

        try {
            while (!outputDone) {
                if (!inputDone) {
                    val inIdx = encoder.dequeueInputBuffer(10_000L)
                    if (inIdx >= 0) {
                        val buf = encoder.getInputBuffer(inIdx)!!
                        buf.clear()
                        val remaining = mixBuf.size - inputOffset
                        if (remaining <= 0) {
                            encoder.queueInputBuffer(inIdx, 0, 0, 0L,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val samplesThisFrame = min(frameSamples * channelCount, remaining)
                            val shortBuf = buf.asShortBuffer()
                            for (i in 0 until samplesThisFrame) {
                                val s = (mixBuf[inputOffset + i] * 32767f)
                                    .toInt().coerceIn(-32768, 32767).toShort()
                                shortBuf.put(s)
                            }
                            val pts = (inputOffset / channelCount).toLong() * 1_000_000L / sampleRate
                            val isLast = (inputOffset + samplesThisFrame) >= mixBuf.size
                            encoder.queueInputBuffer(
                                inIdx, 0, samplesThisFrame * 2, pts,
                                if (isLast) MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0
                            )
                            if (isLast) inputDone = true
                            inputOffset += samplesThisFrame
                        }
                    }
                }

                val outIdx = encoder.dequeueOutputBuffer(bufInfo, 10_000L)
                when {
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        trackIndex = muxer.addTrack(encoder.outputFormat)
                        onTrackAdded(trackIndex)
                    }
                    outIdx >= 0 -> {
                        val outBuf = encoder.getOutputBuffer(outIdx)
                        val isConfig = bufInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                        if (outBuf != null && bufInfo.size > 0 && !isConfig && trackIndex >= 0) {
                            muxer.writeSampleData(trackIndex, outBuf, bufInfo)
                        }
                        encoder.releaseOutputBuffer(outIdx, false)
                        if (bufInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            outputDone = true
                        }
                    }
                }
            }
        } finally {
            try { encoder.stop()    } catch (_: Exception) {}
            try { encoder.release() } catch (_: Exception) {}
        }

        return trackIndex
    }

    // ─── Math helpers ────────────────────────────────────────────────────────

    private fun cos(radians: Float): Float = kotlin.math.cos(radians.toDouble()).toFloat()
    private fun sin(radians: Float): Float = kotlin.math.sin(radians.toDouble()).toFloat()
}

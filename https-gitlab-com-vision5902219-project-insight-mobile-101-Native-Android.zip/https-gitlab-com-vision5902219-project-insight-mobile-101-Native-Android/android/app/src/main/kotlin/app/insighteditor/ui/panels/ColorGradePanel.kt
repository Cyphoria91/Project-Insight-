package app.insighteditor.ui.panels

// LutPickerPanel is in the same package — no import needed.
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.insighteditor.domain.model.ColorGrade
import app.insighteditor.ui.components.GradeSlider
import app.insighteditor.ui.components.SectionHeader
import app.insighteditor.ui.theme.*

@Composable
fun ColorGradePanel(
    grade: ColorGrade,
    onGradeChange: (ColorGrade) -> Unit,
    activeLutId: String = "none",
    onApplyLut: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(Void300)
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(16.dp)
                    .background(
                        Brush.verticalGradient(listOf(NeonTeal400, NeonMagenta300)),
                        RoundedCornerShape(2.dp)
                    )
            )
            Text(
                "COLOR GRADING",
                style = MaterialTheme.typography.labelLarge,
                color = NeonTeal400,
                fontWeight = FontWeight.Bold
            )
        }

        // ── Primary color wheels ──────────────────────────────────────────────
        SectionHeader("Primary Wheels")
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            ColorWheel(
                label   = "Lift",
                color   = LiftColor,
                offsetX = grade.liftR - grade.liftB,
                offsetY = grade.liftG - (grade.liftR + grade.liftB) / 2f,
                onDrag  = { dx, dy ->
                    onGradeChange(grade.copy(
                        liftR = (grade.liftR + dx * 0.5f).coerceIn(-1f, 1f),
                        liftG = (grade.liftG + dy * 0.5f).coerceIn(-1f, 1f),
                        liftB = (grade.liftB - dx * 0.5f).coerceIn(-1f, 1f)
                    ))
                }
            )
            ColorWheel(
                label   = "Gamma",
                color   = GammaColor,
                offsetX = grade.gammaR - grade.gammaB,
                offsetY = grade.gammaG - (grade.gammaR + grade.gammaB) / 2f,
                onDrag  = { dx, dy ->
                    onGradeChange(grade.copy(
                        gammaR = (grade.gammaR + dx * 0.5f).coerceIn(-1f, 1f),
                        gammaG = (grade.gammaG + dy * 0.5f).coerceIn(-1f, 1f),
                        gammaB = (grade.gammaB - dx * 0.5f).coerceIn(-1f, 1f)
                    ))
                }
            )
            ColorWheel(
                label   = "Gain",
                color   = GainColor,
                offsetX = grade.gainR - grade.gainB,
                offsetY = grade.gainG - (grade.gainR + grade.gainB) / 2f,
                onDrag  = { dx, dy ->
                    onGradeChange(grade.copy(
                        gainR = (grade.gainR + dx * 0.5f).coerceIn(-1f, 1f),
                        gainG = (grade.gainG + dy * 0.5f).coerceIn(-1f, 1f),
                        gainB = (grade.gainB - dx * 0.5f).coerceIn(-1f, 1f)
                    ))
                }
            )
        }

        // Neon divider
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, NeonTeal400.copy(alpha = 0.3f), Color.Transparent)
                    )
                )
        )

        // ── Primary sliders ───────────────────────────────────────────────────
        SectionHeader("Primary")
        GradeSlider("Temp",  grade.temperature, -100f, 100f) { onGradeChange(grade.copy(temperature = it)) }
        GradeSlider("Tint",  grade.tint,        -100f, 100f) { onGradeChange(grade.copy(tint = it)) }
        GradeSlider("Exp",   grade.exposure,    -5f,   5f)   { onGradeChange(grade.copy(exposure = it)) }
        GradeSlider("Contr", grade.contrast,    -100f, 100f) { onGradeChange(grade.copy(contrast = it)) }
        GradeSlider("Sat",   grade.saturation,  -100f, 100f) { onGradeChange(grade.copy(saturation = it)) }
        GradeSlider("Pivot", grade.pivot,       0f,    1f)   { onGradeChange(grade.copy(pivot = it)) }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(DividerNormal)
        )

        // ── Tone ─────────────────────────────────────────────────────────────
        SectionHeader("Tone")
        GradeSlider("Highlights", grade.highlights, -100f, 100f) { onGradeChange(grade.copy(highlights = it)) }
        GradeSlider("Shadows",    grade.shadows,    -100f, 100f) { onGradeChange(grade.copy(shadows = it)) }
        GradeSlider("Whites",     grade.whites,     -100f, 100f) { onGradeChange(grade.copy(whites = it)) }
        GradeSlider("Blacks",     grade.blacks,     -100f, 100f) { onGradeChange(grade.copy(blacks = it)) }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(DividerNormal)
        )

        // ── Creative ─────────────────────────────────────────────────────────
        SectionHeader("Creative")
        GradeSlider("Vibrance",  grade.vibrance,  -100f, 100f) { onGradeChange(grade.copy(vibrance = it)) }
        GradeSlider("Hue Shift", grade.hueShift,  -180f, 180f) { onGradeChange(grade.copy(hueShift = it)) }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(DividerNormal)
        )

        // ── LUT selector ─────────────────────────────────────────────────────
        SectionHeader("Color LUT")
        LutPickerPanel(
            activeLutId = activeLutId,
            onSelectLut = { id ->
                onApplyLut(id)
                onGradeChange(grade.copy(lutName = id))
            }
        )
        // LUT intensity slider
        GradeSlider(
            label       = "LUT Mix",
            value       = grade.lutIntensity,
            min         = 0f,
            max         = 1f,
            onValueChange = { onGradeChange(grade.copy(lutIntensity = it)) }
        )

        // Reset button — neon red outlined
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(ErrorRed.copy(alpha = 0.08f))
                .border(1.dp, ErrorRed.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                .clickable { onGradeChange(ColorGrade()) },
            contentAlignment = Alignment.Center
        ) {
            Text(
                "RESET ALL",
                style = MaterialTheme.typography.labelMedium,
                color = ErrorRed,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun ColorWheel(
    label: String,
    color: Color,
    offsetX: Float,
    offsetY: Float,
    onDrag: (dx: Float, dy: Float) -> Unit
) {
    val wheelSize = 76.dp

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(wheelSize)
                .clip(CircleShape)
                // Neon glow ring around the wheel
                .drawBehind {
                    drawCircle(
                        color = color.copy(alpha = 0.20f),
                        radius = size.minDimension / 2f + 4.dp.toPx()
                    )
                }
                .border(1.dp, color.copy(alpha = 0.45f), CircleShape)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onDrag(dragAmount.x / 100f, dragAmount.y / 100f)
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val radius = this.size.minDimension / 2f
                val cx = this.size.width / 2f
                val cy = this.size.height / 2f

                // Hue ring — full spectrum
                for (deg in 0 until 360 step 2) {
                    val hue = deg.toFloat()
                    val ringColor = Color.hsv(hue, 1f, 1f)
                    drawArc(
                        color      = ringColor,
                        startAngle = deg.toFloat(),
                        sweepAngle = 3f,
                        useCenter  = false,
                        style      = Stroke(width = radius * 0.28f),
                        topLeft    = Offset(cx - radius * 0.86f, cy - radius * 0.86f),
                        size       = Size(radius * 1.72f, radius * 1.72f)
                    )
                }

                // Inner dark circle — void background
                drawCircle(
                    color  = Void400,
                    radius = radius * 0.62f,
                    center = Offset(cx, cy)
                )

                // Subtle inner glow matching the wheel's accent color
                drawCircle(
                    color  = color.copy(alpha = 0.08f),
                    radius = radius * 0.62f,
                    center = Offset(cx, cy)
                )

                // Indicator dot — white outline + accent fill
                val dotX = cx + offsetX.coerceIn(-0.4f, 0.4f) * radius * 1.15f
                val dotY = cy + offsetY.coerceIn(-0.4f, 0.4f) * radius * 1.15f
                drawCircle(color = Color.White, radius = 6f, center = Offset(dotX, dotY))
                drawCircle(color = color,       radius = 4.5f, center = Offset(dotX, dotY))
            }
        }

        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun LutSelector(
    selectedLut: String?,
    intensity: Float,
    onSelectLut: (String?) -> Unit,
    onIntensity: (Float) -> Unit
) {
    val luts = listOf(
        "None", "Kodak 2383", "Fuji 3510", "ARRI K1S1",
        "Cyberpunk Teal", "Bleach Bypass", "Print Film"
    )

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        val chunked = luts.chunked(3)
        chunked.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                row.forEach { lut ->
                    val lutKey = if (lut == "None") null else lut
                    val selected = selectedLut == lutKey
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (selected) NeonTeal800.copy(alpha = 0.5f) else Void500
                            )
                            .border(
                                1.dp,
                                if (selected) NeonTeal400.copy(alpha = 0.7f) else DividerNormal,
                                RoundedCornerShape(6.dp)
                            )
                            .clickable { onSelectLut(lutKey) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            lut,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (selected) NeonTeal400 else TextSecondary,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            textAlign = TextAlign.Center,
                            maxLines = 2
                        )
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }

        if (selectedLut != null) {
            GradeSlider("Intensity", intensity, 0f, 1f, onIntensity)
        }
    }
}

// NeonTeal800 helper — deep teal for LUT selected background
private val NeonTeal800 = androidx.compose.ui.graphics.Color(0xFF003D35)

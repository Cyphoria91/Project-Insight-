package app.insighteditor.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.insighteditor.BuildConfig
import app.insighteditor.R
import app.insighteditor.analytics.AnalyticsManager
import app.insighteditor.haptic.HapticManager
import app.insighteditor.haptic.LocalHaptic
import app.insighteditor.ui.theme.*

/**
 * Settings screen — exposes all user-configurable toggles added by the
 * feature set: haptics, analytics consent, cache management.
 *
 * All state changes take effect immediately; there is no "Save" button.
 * Haptic and analytics preferences are persisted by their respective managers.
 */
@Composable
fun SettingsScreen(
    analyticsManager: AnalyticsManager,
    hapticManager: HapticManager,
    onBack: () -> Unit
) {
    val haptic = LocalHaptic.current
    val analyticsGranted by analyticsManager.consentGranted
        .collectAsStateWithLifecycle(initialValue = false)

    // Local state mirrors HapticManager.enabled so the toggle is reactive.
    var hapticsEnabled by remember { mutableStateOf(hapticManager.enabled) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Void200)
            .systemBarsPadding()
    ) {
        // ── Top bar ───────────────────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Void400)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { haptic?.click(); onBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.cd_back),
                    tint = TextPrimary)
            }
            Text(
                text = stringResource(R.string.settings_title),
                style = MaterialTheme.typography.titleLarge,
                color = NeonCyan400,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // ── Haptic feedback ───────────────────────────────────────────────
            SettingsSection(title = stringResource(R.string.settings_section_haptics)) {
                SettingsToggleRow(
                    icon        = Icons.Default.Vibration,
                    title       = stringResource(R.string.settings_haptics_enabled),
                    description = stringResource(R.string.settings_haptics_desc),
                    checked     = hapticsEnabled,
                    onCheckedChange = { enabled ->
                        haptic?.click()
                        hapticsEnabled = enabled
                        hapticManager.enabled = enabled
                        analyticsManager.logSettingsChanged("haptics_enabled", enabled.toString())
                    }
                )
            }

            // ── Privacy / Analytics ───────────────────────────────────────────
            SettingsSection(title = stringResource(R.string.settings_section_privacy)) {
                SettingsToggleRow(
                    icon        = Icons.Default.Analytics,
                    title       = stringResource(R.string.settings_analytics_enabled),
                    description = stringResource(R.string.settings_analytics_desc),
                    checked     = analyticsGranted,
                    onCheckedChange = { granted ->
                        haptic?.click()
                        analyticsManager.recordConsent(granted)
                    }
                )
            }

            // ── Cache ─────────────────────────────────────────────────────────
            SettingsSection(title = stringResource(R.string.settings_section_cache)) {
                var cacheCleared by remember { mutableStateOf(false) }
                SettingsActionRow(
                    icon    = Icons.Default.ClearAll,
                    title   = if (cacheCleared)
                        stringResource(R.string.settings_cache_cleared)
                    else
                        stringResource(R.string.settings_cache_clear),
                    onClick = {
                        haptic?.click()
                        cacheCleared = true
                        analyticsManager.logSettingsChanged("cache_cleared", "true")
                    }
                )
            }

            // ── Version ───────────────────────────────────────────────────────
            Spacer(Modifier.height(8.dp))
            Text(
                text = "${stringResource(R.string.settings_version)} ${BuildConfig.VERSION_NAME}",
                style = MaterialTheme.typography.bodySmall,
                color = TextTertiary,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}

// ── Reusable setting row components ──────────────────────────────────────────

@Composable
private fun SettingsSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = NeonCyan400,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 4.dp, bottom = 2.dp)
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Void300),
            content = content
        )
    }
}

@Composable
private fun SettingsToggleRow(
    icon: ImageVector,
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(icon, contentDescription = null, tint = NeonCyan400, modifier = Modifier.size(22.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary, fontWeight = FontWeight.Medium)
            Text(description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Void500,
                checkedTrackColor = NeonCyan400
            )
        )
    }
}

@Composable
private fun SettingsActionRow(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(icon, contentDescription = null, tint = NeonMagenta300, modifier = Modifier.size(22.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            color = TextPrimary,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        TextButton(onClick = onClick) {
            Text(stringResource(R.string.action_confirm), color = NeonMagenta300)
        }
    }
}

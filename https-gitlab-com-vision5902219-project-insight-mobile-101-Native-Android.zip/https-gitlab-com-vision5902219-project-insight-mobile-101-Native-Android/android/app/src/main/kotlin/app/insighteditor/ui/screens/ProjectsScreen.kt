package app.insighteditor.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.insighteditor.ui.theme.*

@Composable
fun ProjectsScreen(
    onOpenProject: () -> Unit,
    onNewProject: () -> Unit,
    onImportMedia: () -> Unit = {},
    onOpenSettings: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Void200)
            .systemBarsPadding()
    ) {
        // ── Header ────────────────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Void500, Void200)
                    )
                )
                // Neon bottom border
                .drawBehind {
                    drawLine(
                        brush = Brush.horizontalGradient(
                            listOf(
                                Color.Transparent,
                                NeonCyan400.copy(alpha = 0.6f),
                                NeonMagenta300.copy(alpha = 0.3f),
                                Color.Transparent
                            )
                        ),
                        start = Offset(0f, size.height),
                        end   = Offset(size.width, size.height),
                        strokeWidth = 1.5.dp.toPx()
                    )
                }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    // "PROJECT INSIGHT" in neon cyan
                    Text(
                        "PROJECT INSIGHT",
                        style = MaterialTheme.typography.displayLarge,
                        color = NeonCyan400,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(2.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Accent dot
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .background(NeonMagenta300, RoundedCornerShape(50))
                        )
                        Text(
                            "PROFESSIONAL VIDEO EDITOR",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary
                        )
                    }
                }

                // New Project button — neon cyan glow
                Box(
                    modifier = Modifier
                        .height(38.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(NeonCyan800, NeonCyan700.copy(alpha = 0.7f))
                            )
                        )
                        .border(
                            1.dp,
                            Brush.horizontalGradient(
                                listOf(NeonCyan400, NeonCyan300.copy(alpha = 0.5f))
                            ),
                            RoundedCornerShape(8.dp)
                        )
                        .clickable(onClick = onNewProject)
                        .padding(horizontal = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.Add,
                            contentDescription = null,
                            tint = NeonCyan400,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            "NEW PROJECT",
                            style = MaterialTheme.typography.labelMedium,
                            color = NeonCyan400,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(Modifier.width(8.dp))

                // Settings icon button
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // ── Recent projects grid ──────────────────────────────────────────────
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            item(span = { GridItemSpan(2) }) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(3.dp)
                            .height(14.dp)
                            .background(
                                Brush.verticalGradient(listOf(NeonCyan400, NeonMagenta300)),
                                RoundedCornerShape(2.dp)
                            )
                    )
                    Text(
                        "RECENT PROJECTS",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            items(6) { i ->
                ProjectCard(
                    name = listOf(
                        "SEQ_04_FINAL", "PROMO_CUT_V3", "INTERVIEW_EDIT",
                        "MUSIC_VIDEO_01", "SHORT_FILM_CUT", "TRAVEL_VLOG"
                    )[i],
                    duration = listOf(
                        "01:14:23", "00:03:45", "00:28:12",
                        "00:04:22", "00:18:55", "00:12:30"
                    )[i],
                    resolution = listOf("8K", "4K", "1080p", "4K", "2K", "1080p")[i],
                    // Cycle through neon accent colors per card
                    accentColor = listOf(
                        NeonCyan400, NeonMagenta300, NeonTeal400,
                        NeonOrange300, NeonCyan300, NeonMagenta200
                    )[i],
                    onClick = onOpenProject
                )
            }
        }

        // ── Bottom action bar ─────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Void400)
                .drawBehind {
                    drawLine(
                        brush = Brush.horizontalGradient(
                            listOf(
                                Color.Transparent,
                                NeonCyan400.copy(alpha = 0.3f),
                                NeonMagenta300.copy(alpha = 0.2f),
                                Color.Transparent
                            )
                        ),
                        start = Offset(0f, 0f),
                        end   = Offset(size.width, 0f),
                        strokeWidth = 1.dp.toPx()
                    )
                }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Import Media — outlined neon
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Void500)
                        .border(1.dp, DividerBright, RoundedCornerShape(8.dp))
                        .clickable(onClick = onImportMedia),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.FolderOpen,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            "IMPORT MEDIA",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // New Project — filled neon cyan
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            Brush.horizontalGradient(listOf(NeonCyan800, NeonCyan700.copy(alpha = 0.8f)))
                        )
                        .border(
                            1.dp,
                            Brush.horizontalGradient(listOf(NeonCyan400, NeonCyan300.copy(alpha = 0.5f))),
                            RoundedCornerShape(8.dp)
                        )
                        .clickable(onClick = onNewProject),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.VideoFile,
                            contentDescription = null,
                            tint = NeonCyan400,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            "NEW PROJECT",
                            style = MaterialTheme.typography.labelMedium,
                            color = NeonCyan400,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ProjectCard(
    name: String,
    duration: String,
    resolution: String,
    accentColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Void500)
            .border(
                1.dp,
                Brush.verticalGradient(
                    listOf(accentColor.copy(alpha = 0.35f), DividerSubtle)
                ),
                RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
    ) {
        Column {
            // Thumbnail placeholder
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(
                        Brush.verticalGradient(
                            listOf(Void700, Void600)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Subtle grid lines for sci-fi feel
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val gridColor = accentColor.copy(alpha = 0.06f)
                    val cols = 6
                    val rows = 4
                    for (c in 1 until cols) {
                        val x = size.width * c / cols
                        drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), 1f)
                    }
                    for (r in 1 until rows) {
                        val y = size.height * r / rows
                        drawLine(gridColor, Offset(0f, y), Offset(size.width, y), 1f)
                    }
                }

                Icon(
                    Icons.Default.VideoFile,
                    contentDescription = null,
                    tint = accentColor.copy(alpha = 0.4f),
                    modifier = Modifier.size(28.dp)
                )

                // Resolution badge — top-right, neon bordered
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(accentColor.copy(alpha = 0.15f))
                        .border(1.dp, accentColor.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        resolution,
                        style = MaterialTheme.typography.labelSmall,
                        color = accentColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Card footer
            Column(
                modifier = Modifier
                    .background(Void600)
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Text(
                    name,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    duration,
                    style = MaterialTheme.typography.labelMedium,
                    color = accentColor.copy(alpha = 0.7f)
                )
            }
        }
    }
}

// Canvas import needed for the grid lines
@Composable
private fun Canvas(modifier: Modifier, onDraw: androidx.compose.ui.graphics.drawscope.DrawScope.() -> Unit) {
    androidx.compose.foundation.Canvas(modifier = modifier, onDraw = onDraw)
}

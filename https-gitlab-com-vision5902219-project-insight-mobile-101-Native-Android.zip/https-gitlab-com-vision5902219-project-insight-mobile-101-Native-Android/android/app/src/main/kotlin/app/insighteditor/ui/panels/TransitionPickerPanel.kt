package app.insighteditor.ui.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.insighteditor.domain.model.EffectType
import app.insighteditor.domain.model.Transition
import app.insighteditor.ui.theme.DividerSubtle
import app.insighteditor.ui.theme.NeonCyan400
import app.insighteditor.ui.theme.TextPrimary
import app.insighteditor.ui.theme.TextSecondary
import app.insighteditor.ui.theme.Void200
import app.insighteditor.ui.theme.Void300

/** All transition types exposed in the picker, with display metadata. */
private data class TransitionEntry(
    val type: EffectType,
    val label: String,
    val emoji: String
)

private val TRANSITIONS = listOf(
    TransitionEntry(EffectType.CROSS_DISSOLVE, "Dissolve",   "◌"),
    TransitionEntry(EffectType.DIP_TO_BLACK,   "Dip Black",  "◼"),
    TransitionEntry(EffectType.WHIP_PAN,       "Wipe",       "▶"),
    TransitionEntry(EffectType.GLITCH_CUT,     "Glitch Cut", "⚡"),
    TransitionEntry(EffectType.FILM_BURN,      "Film Burn",  "🔥"),
    TransitionEntry(EffectType.LIGHT_LEAK,     "Light Leak", "✦"),
)

/**
 * Slide-up panel for selecting and configuring a clip transition.
 *
 * @param currentTransition The transition currently applied to the selected clip,
 *                          or null if none.
 * @param onApply           Called with the new [Transition] (or null to remove).
 * @param onDismiss         Called when the panel should close.
 */
@Composable
fun TransitionPickerPanel(
    currentTransition: Transition?,
    onApply: (Transition?) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedType by remember(currentTransition) {
        mutableStateOf(currentTransition?.type)
    }
    var durationMs by remember(currentTransition) {
        mutableFloatStateOf((currentTransition?.durationMs ?: 500L).toFloat())
    }
    var intensity by remember(currentTransition) {
        mutableFloatStateOf(currentTransition?.intensity ?: 1f)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Void200)
            .padding(16.dp)
    ) {
        // ── Header ────────────────────────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Transition",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.5.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Remove transition
                if (currentTransition != null) {
                    TextButton(onClick = { onApply(null); onDismiss() }) {
                        Text("Remove", color = Color(0xFFFF3D5A), fontSize = 12.sp)
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text("Cancel", color = TextSecondary, fontSize = 12.sp)
                }
                Button(
                    onClick = {
                        val t = selectedType
                        if (t != null) {
                            onApply(Transition(
                                type       = t,
                                durationMs = durationMs.toLong(),
                                intensity  = intensity
                            ))
                        }
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan400),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text("Apply", color = Void200, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ── Transition grid ───────────────────────────────────────────────────
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.height(160.dp)
        ) {
            items(TRANSITIONS) { entry ->
                val isSelected = selectedType == entry.type
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .aspectRatio(1.6f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) NeonCyan400.copy(alpha = 0.15f) else Void300)
                        .border(
                            width = if (isSelected) 1.5.dp else 0.5.dp,
                            color = if (isSelected) NeonCyan400 else DividerSubtle,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable { selectedType = entry.type }
                        .padding(8.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(entry.emoji, fontSize = 18.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            entry.label,
                            color = if (isSelected) NeonCyan400 else TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                    if (isSelected) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = null,
                            tint = NeonCyan400,
                            modifier = Modifier
                                .size(14.dp)
                                .align(Alignment.TopEnd)
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ── Duration slider ───────────────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Duration", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.width(60.dp))
            Slider(
                value = durationMs,
                onValueChange = { durationMs = it },
                valueRange = 100f..2000f,
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(
                    thumbColor = NeonCyan400,
                    activeTrackColor = NeonCyan400,
                    inactiveTrackColor = DividerSubtle
                )
            )
            Text(
                "${durationMs.toInt()}ms",
                color = TextPrimary,
                fontSize = 11.sp,
                modifier = Modifier.width(48.dp)
            )
        }

        // ── Intensity slider ──────────────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Intensity", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.width(60.dp))
            Slider(
                value = intensity,
                onValueChange = { intensity = it },
                valueRange = 0f..1f,
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(
                    thumbColor = NeonCyan400,
                    activeTrackColor = NeonCyan400,
                    inactiveTrackColor = DividerSubtle
                )
            )
            Text(
                "${(intensity * 100).toInt()}%",
                color = TextPrimary,
                fontSize = 11.sp,
                modifier = Modifier.width(48.dp)
            )
        }
    }
}

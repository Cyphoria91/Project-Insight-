package app.insighteditor.ui.panels

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.insighteditor.domain.model.MediaItem
import app.insighteditor.domain.model.MediaType
import app.insighteditor.ui.theme.*

@Composable
fun MediaPoolPanel(
    mediaItems: List<MediaItem>,
    onAddToTimeline: (MediaItem) -> Unit,
    onImportMedia: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val editorColors = LocalEditorColors.current
    var searchQuery    by remember { mutableStateOf("") }
    var selectedTab    by remember { mutableStateOf(0) }
    val tabs = listOf("Media", "Bins", "Smart")

    val filtered = mediaItems.filter {
        searchQuery.isEmpty() || it.name.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(editorColors.surface2)
    ) {
        // Tabs
        PrimaryTabRow(
            selectedTabIndex = selectedTab,
            containerColor = editorColors.surface3,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            tabs.forEachIndexed { i, tab ->
                Tab(
                    selected = selectedTab == i,
                    onClick  = { selectedTab = i },
                    text = { Text(tab, style = MaterialTheme.typography.labelMedium) }
                )
            }
        }

        // Search + Import row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { if (it.length <= 100) searchQuery = it },
                placeholder = { Text("Search media…", style = MaterialTheme.typography.bodyMedium) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null,
                                     modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                },
                modifier = Modifier.weight(1f),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = editorColors.divider,
                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                )
            )
            Button(
                onClick = onImportMedia,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Import", style = MaterialTheme.typography.labelMedium)
            }
        }

        if (filtered.isEmpty()) {
            EmptyMediaState(onImportMedia = onImportMedia)
        } else {
            // Media grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filtered) { item ->
                    MediaItemCard(item = item, onAdd = { onAddToTimeline(item) })
                }
            }
        }

        // Bottom metadata bar
        if (filtered.isNotEmpty()) {
            Surface(
                color = editorColors.surface3,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetaChip("${filtered.size} clips")
                    MetaChip("${filtered.count { it.type == MediaType.VIDEO }} video")
                    MetaChip("${filtered.count { it.type == MediaType.AUDIO }} audio")
                }
            }
        }
    }
}

@Composable
private fun MediaItemCard(item: MediaItem, onAdd: () -> Unit) {
    val editorColors = LocalEditorColors.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(6.dp))
            .background(editorColors.surface3)
            .clickable(onClick = onAdd)
    ) {
        // Type icon
        Icon(
            when (item.type) {
                MediaType.VIDEO -> Icons.Default.VideoFile
                MediaType.AUDIO -> Icons.Default.AudioFile
                MediaType.IMAGE -> Icons.Default.Image
            },
            contentDescription = null,
            tint = when (item.type) {
                MediaType.VIDEO -> VideoTrackColor
                MediaType.AUDIO -> AudioTrackColor
                MediaType.IMAGE -> MaterialTheme.colorScheme.tertiary
            },
            modifier = Modifier.align(Alignment.Center).size(28.dp)
        )

        // Duration badge
        if (item.durationMs > 0) {
            Surface(
                color = MaterialTheme.colorScheme.background.copy(alpha = 0.8f),
                shape = RoundedCornerShape(3.dp),
                modifier = Modifier.align(Alignment.BottomEnd).padding(3.dp)
            ) {
                Text(
                    formatDuration(item.durationMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                )
            }
        }

        // Add overlay on hover (always visible for touch)
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(3.dp)
                .size(18.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add to timeline",
                 tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(12.dp))
        }

        // Name
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.background.copy(alpha = 0.7f))
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Text(
                item.name,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun EmptyMediaState(onImportMedia: () -> Unit = {}) {
    val editorColors = LocalEditorColors.current
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(Icons.Default.VideoLibrary, contentDescription = null,
                 tint = editorColors.labelText, modifier = Modifier.size(56.dp))
            Text("No media in pool", style = MaterialTheme.typography.bodyMedium,
                 color = editorColors.labelText)
            Text("Tap Import to add video, audio, or images from your phone",
                 style = MaterialTheme.typography.bodySmall, color = editorColors.labelText)
            Button(onClick = onImportMedia) {
                Icon(Icons.Default.FileOpen, contentDescription = null,
                     modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Import from Phone")
            }
        }
    }
}

@Composable
private fun MetaChip(label: String) {
    val editorColors = LocalEditorColors.current
    Text(label, style = MaterialTheme.typography.labelSmall, color = editorColors.labelText)
}

private fun formatDuration(ms: Long): String {
    val secs = ms / 1000
    val mins = secs / 60
    val s = secs % 60
    return if (mins > 0) "${mins}m${s}s" else "${s}s"
}

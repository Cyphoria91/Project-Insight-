package app.insighteditor.data.db.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Persisted project header. Tracks and clips are stored in separate tables
 * with foreign keys so they can be queried independently (e.g., for the
 * projects list screen which only needs name/thumbnail/timestamps).
 */
@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    @ColumnInfo(name = "created_at")  val createdAt: Long,
    @ColumnInfo(name = "modified_at") val modifiedAt: Long,
    @ColumnInfo(name = "frame_rate")  val frameRate: Float,
    val width: Int,
    val height: Int,
    @ColumnInfo(name = "duration_ms") val durationMs: Long,
    @ColumnInfo(name = "thumbnail_path") val thumbnailPath: String?
)

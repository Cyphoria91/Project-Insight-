package app.insighteditor.analytics

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import com.google.firebase.analytics.FirebaseAnalytics
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

private const val TAG = "AnalyticsManager"
private const val PREFS_NAME = "analytics_prefs"
private val Context.analyticsDataStore by preferencesDataStore(name = PREFS_NAME)

private val KEY_CONSENT_GIVEN = booleanPreferencesKey("analytics_consent_given")
private val KEY_CONSENT_SHOWN = booleanPreferencesKey("analytics_consent_shown")

/**
 * Wraps FirebaseAnalytics with user consent gating.
 *
 * Collection is disabled at app start (see AnalyticsModule). This class
 * enables it only after [recordConsent] is called with `granted = true`.
 * The consent decision is persisted in DataStore so it survives restarts.
 *
 * All event logging is no-op when consent has not been granted, so callers
 * do not need to guard every log call.
 */
@Singleton
class AnalyticsManager @Inject constructor(
    private val firebaseAnalytics: FirebaseAnalytics,
    private val context: Context
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    /** Emits true once the user has seen the consent dialog. */
    val consentShown: Flow<Boolean> = context.analyticsDataStore.data
        .map { prefs -> prefs[KEY_CONSENT_SHOWN] ?: false }

    /** Emits the current consent state. */
    val consentGranted: Flow<Boolean> = context.analyticsDataStore.data
        .map { prefs -> prefs[KEY_CONSENT_GIVEN] ?: false }

    /**
     * Records the user's consent decision and enables/disables collection.
     * Must be called from the consent screen after the user taps Accept/Decline.
     */
    fun recordConsent(granted: Boolean) {
        scope.launch {
            context.analyticsDataStore.edit { prefs ->
                prefs[KEY_CONSENT_GIVEN] = granted
                prefs[KEY_CONSENT_SHOWN] = true
            }
        }
        firebaseAnalytics.setAnalyticsCollectionEnabled(granted)
        Log.i(TAG, "Analytics collection ${if (granted) "enabled" else "disabled"} by user")
    }

    /** Re-applies the persisted consent on app restart. Call from Application.onCreate(). */
    fun restoreConsentState(granted: Boolean) {
        firebaseAnalytics.setAnalyticsCollectionEnabled(granted)
    }

    // ── Event logging ─────────────────────────────────────────────────────────
    // All methods are safe to call regardless of consent state — Firebase
    // silently drops events when collection is disabled.

    fun logProjectCreated(projectId: String) = log("project_created") {
        putString("project_id", projectId)
    }

    fun logProjectOpened(projectId: String) = log("project_opened") {
        putString("project_id", projectId)
    }

    fun logClipAdded(trackId: String, mediaType: String) = log("timeline_clip_added") {
        putString("track_id", trackId)
        putString("media_type", mediaType)
    }

    fun logTimelineAction(action: String) = log("timeline_action") {
        putString("action", action)
    }

    fun logExportStarted(resolution: String, codec: String) = log("export_started") {
        putString("resolution", resolution)
        putString("codec", codec)
    }

    fun logExportCompleted(resolution: String) = log("export_completed") {
        putString("resolution", resolution)
    }

    fun logExportFailed(reason: String) = log("export_failed") {
        putString("reason", reason.take(100)) // Firebase param limit: 100 chars
    }

    fun logSettingsChanged(key: String, value: String) = log("settings_changed") {
        putString("key", key)
        putString("value", value)
    }

    fun logScreenView(screenName: String) {
        firebaseAnalytics.logEvent(FirebaseAnalytics.Event.SCREEN_VIEW, Bundle().apply {
            putString(FirebaseAnalytics.Param.SCREEN_NAME, screenName)
            putString(FirebaseAnalytics.Param.SCREEN_CLASS, screenName)
        })
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private fun log(event: String, params: Bundle.() -> Unit) {
        try {
            firebaseAnalytics.logEvent(event, Bundle().apply(params))
        } catch (e: Exception) {
            // Never let analytics crash the app.
            Log.w(TAG, "logEvent($event) threw", e)
        }
    }
}

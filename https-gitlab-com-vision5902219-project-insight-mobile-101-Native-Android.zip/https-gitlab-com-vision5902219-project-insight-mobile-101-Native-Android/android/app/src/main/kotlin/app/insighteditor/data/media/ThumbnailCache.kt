package app.insighteditor.data.media

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class ThumbnailCache(private val context: Context) {

    private val cacheDir: File get() =
        File(context.cacheDir, "thumbnails").also { it.mkdirs() }

    suspend fun getThumbnail(uri: Uri, timeMs: Long = 0L): Bitmap? =
        withContext(Dispatchers.IO) {
            val key = "${uri.hashCode()}_${timeMs}"
            val file = File(cacheDir, "$key.jpg")
            if (file.exists()) {
                return@withContext android.graphics.BitmapFactory.decodeFile(file.absolutePath)
            }
            extractAndCache(uri, timeMs, file)
        }

    private fun extractAndCache(uri: Uri, timeMs: Long, cacheFile: File): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val bmp = retriever.getFrameAtTime(
                timeMs * 1000L,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            ) ?: return null
            val scaled = Bitmap.createScaledBitmap(bmp, 160, 90, true)
            // Recycle the original only if createScaledBitmap returned a new instance.
            if (scaled !== bmp) bmp.recycle()
            FileOutputStream(cacheFile).use { out ->
                scaled.compress(Bitmap.CompressFormat.JPEG, 80, out)
            }
            scaled
        } catch (e: Exception) {
            null
        } finally {
            // release() must run even when setDataSource throws.
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    /** Generate a strip of thumbnails for timeline display. */
    suspend fun getThumbnailStrip(uri: Uri, durationMs: Long, count: Int): List<Bitmap> =
        withContext(Dispatchers.IO) {
            val step = if (count > 1) durationMs / (count - 1) else 0L
            (0 until count).mapNotNull { i ->
                getThumbnail(uri, i * step)
            }
        }

    fun clearCache() {
        cacheDir.listFiles()?.forEach { it.delete() }
    }

    fun getCacheSizeBytes(): Long =
        cacheDir.listFiles()?.sumOf { it.length() } ?: 0L
}

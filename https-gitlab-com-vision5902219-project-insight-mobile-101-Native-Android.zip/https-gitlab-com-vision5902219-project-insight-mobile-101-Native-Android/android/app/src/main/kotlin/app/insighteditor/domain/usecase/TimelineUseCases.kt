package app.insighteditor.domain.usecase

import app.insighteditor.domain.model.*
import java.util.UUID
import kotlin.math.abs

/** Pure domain logic for timeline editing operations. No Android dependencies. */
object TimelineUseCases {

    fun splitClip(clip: Clip, splitMs: Long): Pair<Clip, Clip>? {
        if (splitMs <= clip.timelineStartMs || splitMs >= clip.timelineEndMs) return null
        val ratio = (splitMs - clip.timelineStartMs).toFloat() / clip.durationMs
        val splitSourceMs = clip.sourceStartMs + (ratio * (clip.sourceEndMs - clip.sourceStartMs)).toLong()
        val left = clip.copy(
            id = UUID.randomUUID().toString(),
            timelineEndMs = splitMs,
            sourceEndMs = splitSourceMs
        )
        val right = clip.copy(
            id = UUID.randomUUID().toString(),
            timelineStartMs = splitMs,
            sourceStartMs = splitSourceMs
        )
        return Pair(left, right)
    }

    fun rippleDelete(tracks: List<Track>, clipId: String): List<Track> {
        val clip = tracks.flatMap { it.clips }.find { it.id == clipId } ?: return tracks
        val gapStart = clip.timelineStartMs
        val gapDur = clip.durationMs
        return tracks.map { track ->
            track.copy(clips = track.clips
                .filter { it.id != clipId }
                .map { c ->
                    if (c.timelineStartMs >= gapStart + gapDur)
                        c.copy(
                            timelineStartMs = c.timelineStartMs - gapDur,
                            timelineEndMs = c.timelineEndMs - gapDur
                        )
                    else c
                }
            )
        }
    }

    fun snapPosition(posMs: Long, tracks: List<Track>, thresholdMs: Long = 200L): Long {
        var nearest = posMs
        var minDist = thresholdMs
        tracks.flatMap { it.clips }.forEach { clip ->
            val distStart = abs(posMs - clip.timelineStartMs)
            val distEnd   = abs(posMs - clip.timelineEndMs)
            if (distStart < minDist) { minDist = distStart; nearest = clip.timelineStartMs }
            if (distEnd   < minDist) { minDist = distEnd;   nearest = clip.timelineEndMs }
        }
        return nearest
    }

    fun computeProjectDuration(tracks: List<Track>): Long =
        tracks.flatMap { it.clips }.maxOfOrNull { it.timelineEndMs } ?: 0L

    fun getClipsAtPosition(tracks: List<Track>, posMs: Long): List<Pair<Track, Clip>> =
        tracks.flatMap { track ->
            track.clips
                .filter { it.timelineStartMs <= posMs && it.timelineEndMs > posMs }
                .map { Pair(track, it) }
        }

    fun interpolateKeyframe(keyframes: List<Keyframe>, property: KeyframeProperty, timeMs: Long): Float? {
        val sorted = keyframes.filter { it.property == property }.sortedBy { it.timeMs }
        if (sorted.isEmpty()) return null
        if (timeMs <= sorted.first().timeMs) return sorted.first().value
        if (timeMs >= sorted.last().timeMs) return sorted.last().value

        val before = sorted.last { it.timeMs <= timeMs }
        val after  = sorted.first { it.timeMs > timeMs }
        val t = (timeMs - before.timeMs).toFloat() / (after.timeMs - before.timeMs)

        return when (before.easing) {
            EasingType.LINEAR      -> before.value + (after.value - before.value) * t
            EasingType.EASE_IN     -> before.value + (after.value - before.value) * (t * t)
            EasingType.EASE_OUT    -> before.value + (after.value - before.value) * (1f - (1f - t) * (1f - t))
            EasingType.EASE_IN_OUT -> {
                // Pure-float cubic ease-in-out: avoids Double.pow and NaN at boundaries.
                val ease = if (t < 0.5f) {
                    2f * t * t
                } else {
                    val u = -2f * t + 2f
                    1f - u * u / 2f
                }
                before.value + (after.value - before.value) * ease
            }
            EasingType.BEZIER -> {
                // Cubic bezier approximation
                val cp1y = before.bezierCp1y
                val cp2y = before.bezierCp2y
                val bezier = 3f * cp1y * t * (1f-t) * (1f-t) +
                             3f * cp2y * t * t * (1f-t) +
                             t * t * t
                before.value + (after.value - before.value) * bezier
            }
        }
    }

    fun formatTimecode(ms: Long, fps: Float): String {
        val totalFrames = (ms * fps / 1000f).toLong()
        val framesPerSec = fps.toInt()
        val frames = (totalFrames % framesPerSec).toInt()
        val totalSecs = totalFrames / framesPerSec
        val secs = (totalSecs % 60).toInt()
        val mins = ((totalSecs / 60) % 60).toInt()
        val hours = (totalSecs / 3600).toInt()
        return "%02d:%02d:%02d:%02d".format(hours, mins, secs, frames)
    }

    fun msToTimecodeDisplay(ms: Long): String {
        val totalSecs = ms / 1000
        val millis = ms % 1000
        val secs = totalSecs % 60
        val mins = (totalSecs / 60) % 60
        val hours = totalSecs / 3600
        return "%02d:%02d:%02d.%03d".format(hours, mins, secs, millis)
    }
}

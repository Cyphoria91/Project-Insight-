package app.insighteditor.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import app.insighteditor.data.db.entity.ClipEntity

@Dao
interface ClipDao {

    @Query("SELECT * FROM clips WHERE track_id = :trackId ORDER BY timeline_start_ms ASC")
    suspend fun getByTrack(trackId: String): List<ClipEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(clips: List<ClipEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(clip: ClipEntity)

    @Query("DELETE FROM clips WHERE track_id = :trackId")
    suspend fun deleteByTrack(trackId: String)

    @Query("DELETE FROM clips WHERE id = :clipId")
    suspend fun deleteById(clipId: String)
}

package app.insighteditor.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import app.insighteditor.data.db.entity.TrackEntity

@Dao
interface TrackDao {

    @Query("SELECT * FROM tracks WHERE project_id = :projectId ORDER BY sort_order ASC")
    suspend fun getByProject(projectId: String): List<TrackEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(tracks: List<TrackEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(track: TrackEntity)

    /** Replaces all tracks for a project atomically. */
    @Query("DELETE FROM tracks WHERE project_id = :projectId")
    suspend fun deleteByProject(projectId: String)
}

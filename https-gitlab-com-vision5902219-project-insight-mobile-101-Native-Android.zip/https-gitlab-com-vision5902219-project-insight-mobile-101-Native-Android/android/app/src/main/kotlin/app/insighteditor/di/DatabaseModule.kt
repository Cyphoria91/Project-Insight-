package app.insighteditor.di

import android.content.Context
import app.insighteditor.data.db.AppDatabase
import app.insighteditor.data.db.dao.ClipDao
import app.insighteditor.data.db.dao.ProjectDao
import app.insighteditor.data.db.dao.TrackDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase =
        AppDatabase.create(context)

    @Provides
    fun provideProjectDao(db: AppDatabase): ProjectDao = db.projectDao()

    @Provides
    fun provideTrackDao(db: AppDatabase): TrackDao = db.trackDao()

    @Provides
    fun provideClipDao(db: AppDatabase): ClipDao = db.clipDao()
}

package app.insighteditor.domain.usecase

import app.insighteditor.domain.model.Project
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.ArrayDeque

/**
 * Bounded undo/redo stack for [Project] state snapshots.
 *
 * Each mutating editor operation pushes the *previous* project state before
 * applying the change. Undo restores the previous state and pushes the
 * current state onto the redo stack. Redo re-applies a previously undone
 * state.
 *
 * The stack is bounded to [maxDepth] entries (default 50) to cap memory use.
 * Snapshots are cheap because [Project] and all its children are immutable
 * data classes — no deep copies are needed.
 */
class UndoRedoStack(private val maxDepth: Int = 50) {

    private val undoStack = ArrayDeque<Project>(maxDepth + 1)
    private val redoStack = ArrayDeque<Project>(maxDepth + 1)

    private val _canUndo = MutableStateFlow(false)
    private val _canRedo = MutableStateFlow(false)

    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    /** Push [previous] state before applying a mutation. Clears the redo stack. */
    fun push(previous: Project) {
        if (undoStack.size >= maxDepth) undoStack.removeLast()
        undoStack.push(previous)
        redoStack.clear()
        updateFlags()
    }

    /**
     * Undo the last operation.
     * @param current The current project state (pushed onto redo stack).
     * @return The restored project state, or null if the undo stack is empty.
     */
    fun undo(current: Project): Project? {
        if (undoStack.isEmpty()) return null
        redoStack.push(current)
        val restored = undoStack.pop()
        updateFlags()
        return restored
    }

    /**
     * Redo the last undone operation.
     * @param current The current project state (pushed back onto undo stack).
     * @return The re-applied project state, or null if the redo stack is empty.
     */
    fun redo(current: Project): Project? {
        if (redoStack.isEmpty()) return null
        undoStack.push(current)
        val restored = redoStack.pop()
        updateFlags()
        return restored
    }

    /** Clear both stacks (e.g. on project load). */
    fun clear() {
        undoStack.clear()
        redoStack.clear()
        updateFlags()
    }

    private fun updateFlags() {
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }
}

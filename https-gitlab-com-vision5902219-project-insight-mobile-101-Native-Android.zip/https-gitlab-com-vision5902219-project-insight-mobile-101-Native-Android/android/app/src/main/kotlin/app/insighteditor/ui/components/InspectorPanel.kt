package app.insighteditor.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.insighteditor.domain.model.ColorGrade
import app.insighteditor.ui.theme.*

@Composable
fun InspectorPanel(
    clipId: String,
    grade: ColorGrade,
    clipSpeed: Float = 1f,
    onGradeChange: (ColorGrade) -> Unit,
    onSpeedChange: (Float) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val editorColors = LocalEditorColors.current

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(editorColors.surface2)
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Inspector",
            style = MaterialTheme.typography.titleSmall,
            color = editorColors.labelText,
            fontWeight = FontWeight.SemiBold
        )

        // Speed ramp
        SectionHeader("Speed")
        SpeedRampControl(speed = clipSpeed, onSpeedChange = onSpeedChange)

        HorizontalDivider(color = editorColors.divider)

        // Quick grade sliders
        SectionHeader("Quick Grade")
        GradeSlider("Temp",    grade.temperature, -100f, 100f) { onGradeChange(grade.copy(temperature = it)) }
        GradeSlider("Tint",    grade.tint,        -100f, 100f) { onGradeChange(grade.copy(tint = it)) }
        GradeSlider("Exp",     grade.exposure,    -5f,   5f)   { onGradeChange(grade.copy(exposure = it)) }
        GradeSlider("Contr",   grade.contrast,    -100f, 100f) { onGradeChange(grade.copy(contrast = it)) }
        GradeSlider("Sat",     grade.saturation,  -100f, 100f) { onGradeChange(grade.copy(saturation = it)) }
        GradeSlider("Pivot",   grade.pivot,       0f,    1f)   { onGradeChange(grade.copy(pivot = it)) }

        HorizontalDivider(color = editorColors.divider)

        SectionHeader("Tone")
        GradeSlider("Highlights", grade.highlights, -100f, 100f) { onGradeChange(grade.copy(highlights = it)) }
        GradeSlider("Shadows",    grade.shadows,    -100f, 100f) { onGradeChange(grade.copy(shadows = it)) }
        GradeSlider("Whites",     grade.whites,     -100f, 100f) { onGradeChange(grade.copy(whites = it)) }
        GradeSlider("Blacks",     grade.blacks,     -100f, 100f) { onGradeChange(grade.copy(blacks = it)) }

        HorizontalDivider(color = editorColors.divider)

        SectionHeader("Creative")
        GradeSlider("Vibrance",  grade.vibrance,  -100f, 100f) { onGradeChange(grade.copy(vibrance = it)) }
        GradeSlider("Hue Shift", grade.hueShift,  -180f, 180f) { onGradeChange(grade.copy(hueShift = it)) }

        // Reset button
        OutlinedButton(
            onClick = { onGradeChange(ColorGrade()) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.error
            )
        ) {
            Text("Reset Grade", style = MaterialTheme.typography.labelMedium)
        }
    }
}

private val SPEED_PRESETS = listOf(0.25f, 0.5f, 1f, 2f, 4f)

/**
 * Speed ramp control: preset buttons + continuous slider.
 * Range 0.1x–4.0x; presets at 0.25x, 0.5x, 1x, 2x, 4x.
 */
@Composable
fun SpeedRampControl(
    speed: Float,
    onSpeedChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val editorColors = LocalEditorColors.current
    val cyan = NeonCyan400

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Preset chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            SPEED_PRESETS.forEach { preset ->
                val active = kotlin.math.abs(speed - preset) < 0.01f
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (active) cyan.copy(alpha = 0.15f) else Void300)
                        .border(
                            width = if (active) 1.dp else 0.5.dp,
                            color = if (active) cyan else DividerSubtle,
                            shape = RoundedCornerShape(4.dp)
                        )
                        .clickable { onSpeedChange(preset) }
                        .padding(vertical = 5.dp)
                ) {
                    Text(
                        if (preset == 1f) "1×" else "${preset}×",
                        color = if (active) cyan else TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        // Continuous slider 0.1–4.0
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Speed",
                style = MaterialTheme.typography.labelSmall,
                color = editorColors.labelText,
                modifier = Modifier.width(48.dp)
            )
            Slider(
                value = speed,
                onValueChange = onSpeedChange,
                valueRange = 0.1f..4f,
                modifier = Modifier.weight(1f).height(24.dp),
                colors = SliderDefaults.colors(
                    thumbColor = cyan,
                    activeTrackColor = cyan,
                    inactiveTrackColor = editorColors.divider
                )
            )
            Text(
                "%.2f×".format(speed),
                style = MaterialTheme.typography.labelSmall,
                color = editorColors.monoText,
                modifier = Modifier.width(40.dp),
                textAlign = TextAlign.End
            )
        }
    }
}

@Composable
fun SectionHeader(title: String) {
    val editorColors = LocalEditorColors.current
    Text(
        title.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = editorColors.labelText,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.5.sp
    )
}

@Composable
fun GradeSlider(
    label: String,
    value: Float,
    min: Float,
    max: Float,
    onValueChange: (Float) -> Unit
) {
    val editorColors = LocalEditorColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = editorColors.labelText,
            modifier = Modifier.width(48.dp)
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = min..max,
            modifier = Modifier.weight(1f).height(24.dp),
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = editorColors.divider
            )
        )
        Text(
            "%.1f".format(value),
            style = MaterialTheme.typography.labelSmall,
            color = editorColors.monoText,
            modifier = Modifier.width(36.dp),
            textAlign = TextAlign.End
        )
    }
}

package app.insighteditor.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.collectAsState
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.insighteditor.domain.model.WorkspaceTab
import app.insighteditor.ui.components.*
import app.insighteditor.ui.panels.*
import app.insighteditor.viewmodel.EditorViewModel

/**
 * Root editor screen — CapCut-style layout:
 *
 *  ┌─────────────────────────────────────┐
 *  │  TopBar (project name + export)     │  48 dp
 *  ├─────────────────────────────────────┤
 *  │                                     │
 *  │         Video Preview (16:9)        │  weight(1)
 *  │                                     │
 *  ├─────────────────────────────────────┤
 *  │  Transport (scrub + play controls)  │  ~88 dp
 *  ├─────────────────────────────────────┤
 *  │  Tool category strip (horizontal)   │  56 dp
 *  ├─────────────────────────────────────┤
 *  │  Timeline (multi-track, scrollable) │  220 dp
 *  └─────────────────────────────────────┘
 *
 *  Slide-up panel sheets overlay the entire screen without
 *  pushing any content — playback continues uninterrupted.
 */
@Composable
fun EditorScreen(
    viewModel: EditorViewModel,
    onBack: () -> Unit,
    onImportMedia: () -> Unit = {},
    onOpenSettings: () -> Unit = {}
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    // Root Box: panel sheet overlays content without displacing it
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            // ── 1. Top bar ────────────────────────────────────────────────────
            val isSaving    by viewModel.isSaving.collectAsState()
            val lastSavedMs by viewModel.lastSavedMs.collectAsState()
            CapCutTopBar(
                projectName    = state.project.name,
                activeTab      = state.activeWorkspace,
                isExporting    = state.isExporting,
                exportProgress = state.exportProgress?.percent ?: 0f,
                isSaving       = isSaving,
                lastSavedMs    = lastSavedMs,
                onTabSelected  = viewModel::setWorkspace,
                onExport       = { viewModel.startExport(app.insighteditor.domain.model.ExportConfig()) },
                onBack         = onBack,
                onOpenSettings = onOpenSettings
            )

            when (state.activeWorkspace) {
                WorkspaceTab.DELIVER -> {
                    Box(modifier = Modifier.weight(1f)) {
                        DeliverWorkspace(viewModel, state)
                    }
                }

                WorkspaceTab.MEDIA -> {
                    // Load device media the first time this tab is shown.
                    LaunchedEffect(Unit) { viewModel.loadDeviceMedia() }
                    Box(modifier = Modifier.weight(1f)) {
                        MediaWorkspace(viewModel, state, onImportMedia)
                    }
                }

                else -> {
                    // ── 2. Video preview ─────────────────────────────────────
                    ViewerPanel(
                        playheadMs  = state.playheadMs,
                        durationMs  = state.project.durationMs,
                        isPlaying   = state.isPlaying,
                        projectName = state.project.name,
                        onPlay      = viewModel::togglePlayback,
                        onSeek      = viewModel::seekTo,
                        onStepBack  = { viewModel.stepFrame(false) },
                        onStepFwd   = { viewModel.stepFrame(true) },
                        onGoStart   = viewModel::goToStart,
                        onGoEnd     = viewModel::goToEnd,
                        modifier    = Modifier.weight(1f)
                    )

                    // ── 3. Tool category strip ────────────────────────────────
                    ToolDock(
                        activePanel     = state.activePanel,
                        onPanelSelected = viewModel::setActivePanel
                    )

                    // ── 4. Timeline ───────────────────────────────────────────
                    val waveforms by viewModel.waveforms.collectAsState()
                    TimelinePanel(
                        tracks            = state.project.tracks,
                        mediaPool         = state.mediaPool,
                        waveforms         = waveforms,
                        onLoadWaveform    = viewModel::loadWaveform,
                        playheadMs        = state.playheadMs,
                        durationMs        = state.project.durationMs,
                        activeTool        = state.activeTool,
                        snapEnabled       = state.snapEnabled,
                        rippleEnabled     = state.rippleEnabled,
                        linkEnabled       = state.linkEnabled,
                        zoomLevel         = state.zoomLevel,
                        selectedClipId    = state.selectedClipId,
                        onSeek            = viewModel::seekTo,
                        onSelectClip      = viewModel::selectClip,
                        onSplitAtPlayhead = viewModel::splitClipAtPlayhead,
                        onDeleteClip      = viewModel::deleteSelectedClip,
                        onSetTool         = viewModel::setEditTool,
                        onToggleSnap      = viewModel::toggleSnap,
                        onToggleRipple    = viewModel::toggleRipple,
                        onToggleLink      = viewModel::toggleLink,
                        onZoomChange      = viewModel::setZoom,
                        onToggleMute      = viewModel::toggleTrackMute,
                        onToggleSolo      = viewModel::toggleTrackSolo,
                        onToggleLock      = viewModel::toggleTrackLock
                    )
                }
            }
        }

        // ── Slide-up panel sheet — overlays everything, never shifts layout ──
        AnimatedVisibility(
            visible  = state.activePanel != null,
            enter    = slideInVertically(initialOffsetY = { it }),
            exit     = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            PanelSheet(
                panel     = state.activePanel,
                state     = state,
                viewModel = viewModel,
                onDismiss = { viewModel.setActivePanel(null) }
            )
        }
    }
}

@Composable
private fun MediaWorkspace(
    viewModel: EditorViewModel,
    state: app.insighteditor.viewmodel.EditorUiState,
    onImportMedia: () -> Unit = {}
) {
    MediaPoolPanel(
        mediaItems    = state.mediaPool,
        onAddToTimeline = { item ->
            viewModel.addClipToTrack("v1", item, state.project.durationMs)
        },
        onImportMedia = onImportMedia
    )
}

@Composable
private fun DeliverWorkspace(
    viewModel: EditorViewModel,
    state: app.insighteditor.viewmodel.EditorUiState
) {
    ExportPanel(
        isExporting    = state.isExporting,
        exportProgress = state.exportProgress,
        onStartExport  = { config -> viewModel.startExport(config) },
        onCancelExport = viewModel::cancelExport
    )
}

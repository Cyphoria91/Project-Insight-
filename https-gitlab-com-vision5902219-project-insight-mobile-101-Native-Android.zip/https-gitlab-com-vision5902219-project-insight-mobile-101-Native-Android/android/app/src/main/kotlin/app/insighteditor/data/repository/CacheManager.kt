package app.insighteditor.data.repository

import android.content.Context
import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Manages preview frame cache, render intermediates, and LUT assets.
 * Uses app-private cache directory — no storage permissions required.
 */
class CacheManager(private val context: Context) {

    private val previewDir  get() = File(context.cacheDir, "previews").also  { it.mkdirs() }
    private val renderDir   get() = File(context.cacheDir, "renders").also   { it.mkdirs() }
    private val lutDir      get() = File(context.filesDir, "luts").also      { it.mkdirs() }
    private val thumbDir    get() = File(context.cacheDir, "thumbnails").also { it.mkdirs() }

    // ─── Preview frames ──────────────────────────────────────────────────────

    suspend fun cachePreviewFrame(key: String, bitmap: Bitmap) = withContext(Dispatchers.IO) {
        val file = File(previewDir, "$key.jpg")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 85, it) }
    }

    suspend fun getPreviewFrame(key: String): Bitmap? = withContext(Dispatchers.IO) {
        val file = File(previewDir, "$key.jpg")
        if (file.exists()) android.graphics.BitmapFactory.decodeFile(file.absolutePath) else null
    }

    // ─── LUT assets ──────────────────────────────────────────────────────────

    suspend fun saveLut(name: String, data: ByteArray) = withContext(Dispatchers.IO) {
        File(lutDir, "$name.cube").writeBytes(data)
    }

    suspend fun loadLut(name: String): ByteArray? = withContext(Dispatchers.IO) {
        val file = File(lutDir, "$name.cube")
        if (file.exists()) file.readBytes() else null
    }

    fun listLuts(): List<String> =
        lutDir.listFiles { f -> f.extension == "cube" }
            ?.map { it.nameWithoutExtension } ?: emptyList()

    // ─── Render intermediates ────────────────────────────────────────────────

    fun getRenderFile(name: String): File = File(renderDir, name)

    fun cleanRenderDir() = renderDir.listFiles()?.forEach { it.delete() }

    // ─── Cache stats ─────────────────────────────────────────────────────────

    fun getTotalCacheSizeBytes(): Long =
        listOf(previewDir, renderDir, thumbDir)
            .flatMap { it.walkTopDown().filter { f -> f.isFile }.toList() }
            .sumOf { it.length() }

    fun clearAllCaches() {
        previewDir.deleteRecursively()
        renderDir.deleteRecursively()
        thumbDir.deleteRecursively()
        previewDir.mkdirs()
        renderDir.mkdirs()
        thumbDir.mkdirs()
    }

    // ─── Built-in LUT generation (identity + film stock approximations) ──────

    /**
     * Generates a 33x33x33 identity LUT as raw RGBA bytes.
     * Used as a baseline when no external LUT file is loaded.
     */
    fun generateIdentityLut(): ByteArray {
        val N = 33
        val data = ByteArray(N * N * N * 4)
        var idx = 0
        for (b in 0 until N) {
            for (g in 0 until N) {
                for (r in 0 until N) {
                    data[idx++] = (r * 255 / (N - 1)).toByte()
                    data[idx++] = (g * 255 / (N - 1)).toByte()
                    data[idx++] = (b * 255 / (N - 1)).toByte()
                    data[idx++] = 255.toByte()
                }
            }
        }
        return data
    }

    /**
     * Generates a warm film-stock LUT approximation (Kodak 2383 style).
     * Lifts shadows slightly warm, rolls off highlights.
     */
    fun generateKodak2383Lut(): ByteArray {
        val N = 33
        val data = ByteArray(N * N * N * 4)
        var idx = 0
        for (b in 0 until N) {
            for (g in 0 until N) {
                for (r in 0 until N) {
                    val rf = r.toFloat() / (N - 1)
                    val gf = g.toFloat() / (N - 1)
                    val bf = b.toFloat() / (N - 1)
                    // Warm lift in shadows, slight highlight rolloff
                    val outR = (kodakCurve(rf) * 1.04f + 0.02f).coerceIn(0f, 1f)
                    val outG = (kodakCurve(gf) * 0.98f + 0.01f).coerceIn(0f, 1f)
                    val outB = (kodakCurve(bf) * 0.88f + 0.01f).coerceIn(0f, 1f)
                    data[idx++] = (outR * 255).toInt().toByte()
                    data[idx++] = (outG * 255).toInt().toByte()
                    data[idx++] = (outB * 255).toInt().toByte()
                    data[idx++] = 255.toByte()
                }
            }
        }
        return data
    }

    private fun kodakCurve(v: Float): Float {
        // S-curve with toe and shoulder
        return when {
            v < 0.1f -> v * 0.8f + 0.02f
            v > 0.9f -> 0.9f + (v - 0.9f) * 0.6f
            else     -> v
        }
    }
}

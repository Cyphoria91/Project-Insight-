package app.insighteditor.analytics

import android.util.Log
import com.google.firebase.crashlytics.FirebaseCrashlytics
import javax.inject.Inject
import javax.inject.Singleton

private const val TAG = "CrashReporter"

/**
 * Thin wrapper around FirebaseCrashlytics for non-fatal exception reporting
 * and structured custom key logging.
 *
 * All methods are safe to call from any thread and never throw.
 */
@Singleton
class CrashReporter @Inject constructor(
    private val crashlytics: FirebaseCrashlytics
) {

    /**
     * Records a non-fatal exception with an optional context tag.
     * The [context] string is attached as a custom key so it appears in the
     * Crashlytics console alongside the stack trace.
     */
    fun logNonFatal(throwable: Throwable, context: String? = null) {
        try {
            if (context != null) {
                crashlytics.setCustomKey("error_context", context)
            }
            crashlytics.recordException(throwable)
            Log.w(TAG, "Non-fatal recorded: ${throwable.message} [context=$context]")
        } catch (e: Exception) {
            Log.e(TAG, "CrashReporter.logNonFatal threw", e)
        }
    }

    /**
     * Logs a breadcrumb message visible in the Crashlytics session log.
     * Use for significant state transitions (e.g., "Export started", "DB migrated").
     */
    fun log(message: String) {
        try {
            crashlytics.log(message)
        } catch (e: Exception) {
            Log.e(TAG, "CrashReporter.log threw", e)
        }
    }

    /** Sets a persistent custom key visible on all subsequent crash reports. */
    fun setKey(key: String, value: String) {
        try {
            crashlytics.setCustomKey(key, value)
        } catch (e: Exception) {
            Log.e(TAG, "CrashReporter.setKey threw", e)
        }
    }

    fun setKey(key: String, value: Int) {
        try {
            crashlytics.setCustomKey(key, value)
        } catch (e: Exception) {
            Log.e(TAG, "CrashReporter.setKey(Int) threw", e)
        }
    }

    fun setKey(key: String, value: Boolean) {
        try {
            crashlytics.setCustomKey(key, value)
        } catch (e: Exception) {
            Log.e(TAG, "CrashReporter.setKey(Boolean) threw", e)
        }
    }

    /**
     * Associates a user identifier with crash reports.
     * Pass an opaque ID — never PII (name, email, phone).
     */
    fun setUserId(id: String) {
        try {
            crashlytics.setUserId(id)
        } catch (e: Exception) {
            Log.e(TAG, "CrashReporter.setUserId threw", e)
        }
    }
}

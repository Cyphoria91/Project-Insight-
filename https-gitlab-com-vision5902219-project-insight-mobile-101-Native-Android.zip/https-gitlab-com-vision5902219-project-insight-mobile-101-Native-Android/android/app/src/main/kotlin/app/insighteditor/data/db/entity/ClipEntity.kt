package app.insighteditor.data.db.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Persisted clip. Complex nested objects (ColorGrade, effects, keyframes,
 * TextOverlay, Transition) are stored as JSON blobs via TypeConverters.
 * This avoids a deeply normalised schema for data that is always read and
 * written as a unit with its parent clip.
 */
@Entity(
    tableName = "clips",
    foreignKeys = [
        ForeignKey(
            entity = TrackEntity::class,
            parentColumns = ["id"],
            childColumns = ["track_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("track_id")]
)
data class ClipEntity(
    @PrimaryKey val id: String,
    @ColumnInfo(name = "media_id")           val mediaId: String,
    @ColumnInfo(name = "track_id")           val trackId: String,
    @ColumnInfo(name = "timeline_start_ms")  val timelineStartMs: Long,
    @ColumnInfo(name = "timeline_end_ms")    val timelineEndMs: Long,
    @ColumnInfo(name = "source_start_ms")    val sourceStartMs: Long,
    @ColumnInfo(name = "source_end_ms")      val sourceEndMs: Long,
    val speed: Float,
    val volume: Float,
    /** JSON-serialised ColorGrade — see Converters.colorGradeToJson */
    @ColumnInfo(name = "color_grade_json")   val colorGradeJson: String,
    /** JSON-serialised List<AppliedEffect> */
    @ColumnInfo(name = "effects_json")       val effectsJson: String,
    /** JSON-serialised List<Keyframe> */
    @ColumnInfo(name = "keyframes_json")     val keyframesJson: String,
    /** JSON-serialised TextOverlay? — null when no overlay */
    @ColumnInfo(name = "text_overlay_json")  val textOverlayJson: String?,
    /** JSON-serialised Transition? — null when no transition */
    @ColumnInfo(name = "transition_json")    val transitionJson: String?
)

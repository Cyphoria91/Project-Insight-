package app.insighteditor.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkInfo
import androidx.work.WorkManager
import app.insighteditor.analytics.AnalyticsManager
import app.insighteditor.analytics.CrashReporter
import app.insighteditor.data.lut.LutRepository
import app.insighteditor.data.media.MediaRepository
import app.insighteditor.data.media.PlaybackEngine
import app.insighteditor.data.media.WaveformRepository
import app.insighteditor.data.repository.ProjectRepository
import app.insighteditor.domain.model.*
import app.insighteditor.domain.usecase.UndoRedoStack
import app.insighteditor.export.AudioMixer
import app.insighteditor.export.TransformerExportWorker
import app.insighteditor.haptic.HapticManager
import app.insighteditor.native.NativeEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

data class EditorUiState(
    val project: Project = Project(
        id = UUID.randomUUID().toString(),
        name = "Untitled Project",
        tracks = defaultTracks()
    ),
    val activeWorkspace: WorkspaceTab = WorkspaceTab.EDIT,
    val activeTool: EditTool = EditTool.SELECT,
    val selectedClipId: String? = null,
    val playheadMs: Long = 0L,
    val isPlaying: Boolean = false,
    val zoomLevel: Float = 1f,
    val snapEnabled: Boolean = true,
    val rippleEnabled: Boolean = false,
    val linkEnabled: Boolean = true,
    val mediaPool: List<MediaItem> = emptyList(),
    val exportProgress: ExportProgress? = null,
    val isExporting: Boolean = false,
    val audioChannels: List<AudioChannel> = defaultAudioChannels(),
    val activePanel: String? = null,
    val cpuPercent: Int = 0,
    val gpuPercent: Int = 0,
    val cacheUsedGb: Float = 0f,
    val renderQueueCount: Int = 0
)

private fun defaultTracks(): List<Track> = listOf(
    Track("v3", TrackType.VIDEO, "V3"),
    Track("v2", TrackType.VIDEO, "V2"),
    Track("v1", TrackType.VIDEO, "V1"),
    Track("a1", TrackType.AUDIO, "A1"),
    Track("a2", TrackType.AUDIO, "A2"),
    Track("a3", TrackType.AUDIO, "A3")
)

private fun defaultAudioChannels(): List<AudioChannel> = listOf(
    AudioChannel("master", "Master"),
    AudioChannel("dialogue", "Dialogue"),
    AudioChannel("music", "Music"),
    AudioChannel("fx", "FX")
)

@HiltViewModel
class EditorViewModel @Inject constructor(
    @ApplicationContext private val appContext: Context,
    private val projectRepository: ProjectRepository,
    private val mediaRepository: MediaRepository,
    private val playbackEngine: PlaybackEngine,
    private val analyticsManager: AnalyticsManager,
    private val crashReporter: CrashReporter,
    private val hapticManager: HapticManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    private var playbackJob: Job? = null
    private val nativeEngine = NativeEngine()
    // LutRepository and WaveformRepository require NativeEngine — instantiated here.
    private val lutRepository = LutRepository(appContext, nativeEngine)
    private val waveformRepository = WaveformRepository(appContext, nativeEngine)

    // ─── Autosave ─────────────────────────────────────────────────────────────
    private val _lastSavedMs = MutableStateFlow<Long?>(null)
    val lastSavedMs: StateFlow<Long?> = _lastSavedMs.asStateFlow()

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    // ─── Undo / Redo ─────────────────────────────────────────────────────────
    private val undoRedoStack = UndoRedoStack(maxDepth = 50)
    val canUndo = undoRedoStack.canUndo
    val canRedo = undoRedoStack.canRedo

    private val _activeLutId = MutableStateFlow("none")
    val activeLutId = _activeLutId.asStateFlow()

    private fun recordUndo() = undoRedoStack.push(_uiState.value.project)

    fun undo() {
        val restored = undoRedoStack.undo(_uiState.value.project) ?: return
        _uiState.update { it.copy(project = restored) }
    }

    fun redo() {
        val restored = undoRedoStack.redo(_uiState.value.project) ?: return
        _uiState.update { it.copy(project = restored) }
    }

    init {
        viewModelScope.launch(Dispatchers.IO) {
            nativeEngine.init()
        }
        startSystemMonitor()
        startAutosave()
    }

    // ─── Project management ───────────────────────────────────────────────────

    fun createNewProject(name: String = "Untitled Project") {
        val project = Project(
            id = UUID.randomUUID().toString(),
            name = name,
            tracks = defaultTracks()
        )
        _uiState.update { it.copy(project = project) }
        analyticsManager.logProjectCreated(project.id)
        viewModelScope.launch { projectRepository.saveProject(project) }
    }

    fun loadProject(id: String) {
        viewModelScope.launch {
            val project = projectRepository.loadProject(id) ?: return@launch
            _uiState.update { it.copy(project = project) }
            analyticsManager.logProjectOpened(project.id)
        }
    }

    fun saveProject() {
        viewModelScope.launch {
            _isSaving.value = true
            try {
                projectRepository.saveProject(_uiState.value.project)
                _lastSavedMs.value = System.currentTimeMillis()
            } catch (e: Exception) {
                crashReporter.logNonFatal(e, "saveProject failed")
            } finally {
                _isSaving.value = false
            }
        }
    }

    fun renameProject(name: String) {
        _uiState.update { it.copy(project = it.project.copy(name = name)) }
    }

    // ─── Workspace ───────────────────────────────────────────────────────────

    fun setWorkspace(tab: WorkspaceTab) {
        _uiState.update { it.copy(activeWorkspace = tab) }
    }

    fun setActivePanel(panel: String?) {
        _uiState.update { it.copy(activePanel = panel) }
    }

    // ─── Playback ────────────────────────────────────────────────────────────

    fun togglePlayback() {
        if (_uiState.value.isPlaying) pausePlayback() else startPlayback()
    }

    fun startPlayback() {
        _uiState.update { it.copy(isPlaying = true) }
        // PlaybackEngine now drives the tick via Choreographer (adaptive refresh rate).
        // The ViewModel observes PlaybackEngine.state for position updates.
        playbackEngine.play()
        playbackJob = viewModelScope.launch {
            playbackEngine.state.collect { ps ->
                _uiState.update { it.copy(playheadMs = ps.positionMs, isPlaying = ps.isPlaying) }
            }
        }
    }

    fun pausePlayback() {
        playbackEngine.pause()
        playbackJob?.cancel()
        _uiState.update { it.copy(isPlaying = false) }
    }

    fun seekTo(ms: Long) {
        val clamped = ms.coerceAtLeast(0L)
        playbackEngine.seekTo(clamped)
        _uiState.update { it.copy(playheadMs = clamped) }
    }

    fun stepFrame(forward: Boolean) {
        val state = _uiState.value
        val frameDurationMs = (1000f / state.project.frameRate).toLong()
        val newPos = if (forward) state.playheadMs + frameDurationMs
                     else (state.playheadMs - frameDurationMs).coerceAtLeast(0L)
        seekTo(newPos)
    }

    fun goToStart() = seekTo(0L)
    fun goToEnd() = seekTo(_uiState.value.project.durationMs)

    // ─── Edit tools ──────────────────────────────────────────────────────────

    fun setEditTool(tool: EditTool) = _uiState.update { it.copy(activeTool = tool) }
    fun toggleSnap() = _uiState.update { it.copy(snapEnabled = !it.snapEnabled) }
    fun toggleRipple() = _uiState.update { it.copy(rippleEnabled = !it.rippleEnabled) }
    fun toggleLink() = _uiState.update { it.copy(linkEnabled = !it.linkEnabled) }
    fun setZoom(zoom: Float) = _uiState.update { it.copy(zoomLevel = zoom.coerceIn(0.1f, 10f)) }

    // ─── Clip operations ─────────────────────────────────────────────────────

    fun selectClip(clipId: String?) {
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                track.copy(clips = track.clips.map { clip ->
                    clip.copy(isSelected = clip.id == clipId)
                })
            }
            state.copy(
                selectedClipId = clipId,
                project = state.project.copy(tracks = updatedTracks)
            )
        }
        val clip = _uiState.value.project.tracks.flatMap { it.clips }.find { it.id == clipId }
        playbackEngine.setPlaybackSpeed(clip?.speed ?: 1f)
    }

    fun addClipToTrack(trackId: String, mediaItem: MediaItem, startMs: Long) {
        recordUndo()
        val clip = Clip(
            id = UUID.randomUUID().toString(),
            mediaId = mediaItem.id,
            trackId = trackId,
            timelineStartMs = startMs,
            timelineEndMs = startMs + mediaItem.durationMs,
            sourceStartMs = 0L,
            sourceEndMs = mediaItem.durationMs
        )
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                if (track.id == trackId) track.copy(clips = track.clips + clip) else track
            }
            val newDuration = updatedTracks.flatMap { it.clips }.maxOfOrNull { it.timelineEndMs } ?: 0L
            state.copy(project = state.project.copy(tracks = updatedTracks, durationMs = newDuration))
        }
        analyticsManager.logClipAdded(trackId, mediaItem.type.name)
    }

    fun deleteSelectedClip() {
        val clipId = _uiState.value.selectedClipId ?: return
        recordUndo()
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                track.copy(clips = track.clips.filter { it.id != clipId })
            }
            state.copy(selectedClipId = null, project = state.project.copy(tracks = updatedTracks))
        }
    }

    fun splitClipAtPlayhead() {
        recordUndo()
        val playhead = _uiState.value.playheadMs
        _uiState.update { s ->
            val updatedTracks = s.project.tracks.map { track ->
                val newClips = mutableListOf<Clip>()
                track.clips.forEach { clip ->
                    if (playhead > clip.timelineStartMs && playhead < clip.timelineEndMs) {
                        val ratio = (playhead - clip.timelineStartMs).toFloat() / clip.durationMs
                        val splitSourceMs = clip.sourceStartMs + (ratio * (clip.sourceEndMs - clip.sourceStartMs)).toLong()
                        newClips += clip.copy(id = UUID.randomUUID().toString(), timelineEndMs = playhead, sourceEndMs = splitSourceMs)
                        newClips += clip.copy(id = UUID.randomUUID().toString(), timelineStartMs = playhead, sourceStartMs = splitSourceMs)
                    } else {
                        newClips += clip
                    }
                }
                track.copy(clips = newClips)
            }
            s.copy(project = s.project.copy(tracks = updatedTracks))
        }
        analyticsManager.logTimelineAction("split_clip")
    }

    fun trimClip(clipId: String, newStartMs: Long? = null, newEndMs: Long? = null) {
        recordUndo()
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                track.copy(clips = track.clips.map { clip ->
                    if (clip.id == clipId) clip.copy(
                        timelineStartMs = newStartMs ?: clip.timelineStartMs,
                        timelineEndMs = newEndMs ?: clip.timelineEndMs
                    ) else clip
                })
            }
            state.copy(project = state.project.copy(tracks = updatedTracks))
        }
    }

    fun moveClip(clipId: String, newStartMs: Long) {
        recordUndo()
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                track.copy(clips = track.clips.map { clip ->
                    if (clip.id == clipId) {
                        val dur = clip.durationMs
                        clip.copy(timelineStartMs = newStartMs, timelineEndMs = newStartMs + dur)
                    } else clip
                })
            }
            state.copy(project = state.project.copy(tracks = updatedTracks))
        }
    }

    fun setClipSpeed(clipId: String, speed: Float) {
        val clamped = speed.coerceIn(0.1f, 4f)
        recordUndo()
        _uiState.update { state ->
            state.copy(project = state.project.copy(
                tracks = state.project.tracks.map { track ->
                    track.copy(clips = track.clips.map { clip ->
                        if (clip.id != clipId) return@map clip
                        val sourceDurationMs = (clip.sourceEndMs - clip.sourceStartMs).coerceAtLeast(1L)
                        val newTimelineDurationMs = (sourceDurationMs / clamped).toLong()
                        clip.copy(speed = clamped, timelineEndMs = clip.timelineStartMs + newTimelineDurationMs)
                    })
                }
            ))
        }
        _uiState.update { state ->
            val newDuration = state.project.tracks.flatMap { it.clips }.maxOfOrNull { it.timelineEndMs } ?: 0L
            state.copy(project = state.project.copy(durationMs = newDuration))
        }
        if (_uiState.value.selectedClipId == clipId) playbackEngine.setPlaybackSpeed(clamped)
    }

    // ─── Track operations ────────────────────────────────────────────────────

    fun toggleTrackMute(trackId: String) = _uiState.update { state ->
        state.copy(project = state.project.copy(
            tracks = state.project.tracks.map { t -> if (t.id == trackId) t.copy(isMuted = !t.isMuted) else t }
        ))
    }

    fun toggleTrackSolo(trackId: String) = _uiState.update { state ->
        state.copy(project = state.project.copy(
            tracks = state.project.tracks.map { t -> if (t.id == trackId) t.copy(isSolo = !t.isSolo) else t }
        ))
    }

    fun toggleTrackLock(trackId: String) = _uiState.update { state ->
        state.copy(project = state.project.copy(
            tracks = state.project.tracks.map { t -> if (t.id == trackId) t.copy(isLocked = !t.isLocked) else t }
        ))
    }

    // ─── Color grading ───────────────────────────────────────────────────────

    fun updateColorGrade(clipId: String, grade: ColorGrade) {
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                track.copy(clips = track.clips.map { clip ->
                    if (clip.id == clipId) clip.copy(colorGrade = grade) else clip
                })
            }
            state.copy(project = state.project.copy(tracks = updatedTracks))
        }
        analyticsManager.logTimelineAction("color_grade_applied")
    }

    fun getSelectedClipGrade(): ColorGrade {
        val clipId = _uiState.value.selectedClipId ?: return ColorGrade()
        return _uiState.value.project.tracks.flatMap { it.clips }.find { it.id == clipId }?.colorGrade ?: ColorGrade()
    }

    // ─── LUT ─────────────────────────────────────────────────────────────────

    fun applyLut(lutId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = lutRepository.loadLut(lutId)
            if (ok) _activeLutId.value = lutId
        }
    }

    // ─── Effects ─────────────────────────────────────────────────────────────

    fun applyEffect(clipId: String, effect: AppliedEffect) {
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                track.copy(clips = track.clips.map { clip ->
                    if (clip.id == clipId) clip.copy(effects = clip.effects + effect) else clip
                })
            }
            state.copy(project = state.project.copy(tracks = updatedTracks))
        }
    }

    fun removeEffect(clipId: String, effectId: String) {
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                track.copy(clips = track.clips.map { clip ->
                    if (clip.id == clipId) clip.copy(effects = clip.effects.filter { it.id != effectId }) else clip
                })
            }
            state.copy(project = state.project.copy(tracks = updatedTracks))
        }
    }

    // ─── Transitions ─────────────────────────────────────────────────────────

    fun setTransition(clipId: String, transition: Transition?) {
        recordUndo()
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                track.copy(clips = track.clips.map { clip ->
                    if (clip.id == clipId) clip.copy(transition = transition) else clip
                })
            }
            state.copy(project = state.project.copy(tracks = updatedTracks))
        }
    }

    // ─── Text overlays ───────────────────────────────────────────────────────

    fun setTextOverlay(clipId: String, overlay: TextOverlay?) {
        recordUndo()
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                track.copy(clips = track.clips.map { clip ->
                    if (clip.id == clipId) clip.copy(textOverlay = overlay) else clip
                })
            }
            state.copy(project = state.project.copy(tracks = updatedTracks))
        }
    }

    // ─── Keyframes ───────────────────────────────────────────────────────────

    fun addKeyframe(clipId: String, keyframe: Keyframe) {
        recordUndo()
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                track.copy(clips = track.clips.map { clip ->
                    if (clip.id == clipId) clip.copy(keyframes = clip.keyframes + keyframe) else clip
                })
            }
            state.copy(project = state.project.copy(tracks = updatedTracks))
        }
    }

    /** Convenience overload used by KeyframePanel — builds a Keyframe from components. */
    fun addKeyframe(clipId: String, property: KeyframeProperty, value: Float) {
        addKeyframe(
            clipId,
            Keyframe(
                id       = UUID.randomUUID().toString(),
                timeMs   = _uiState.value.playheadMs,
                property = property,
                value    = value
            )
        )
    }

    fun removeKeyframe(clipId: String, keyframeId: String) {
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                track.copy(clips = track.clips.map { clip ->
                    if (clip.id == clipId) clip.copy(keyframes = clip.keyframes.filter { it.id != keyframeId }) else clip
                })
            }
            state.copy(project = state.project.copy(tracks = updatedTracks))
        }
    }

    fun updateKeyframeEasing(clipId: String, keyframeId: String, easing: EasingType) {
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                track.copy(clips = track.clips.map { clip ->
                    if (clip.id == clipId) clip.copy(
                        keyframes = clip.keyframes.map { kf ->
                            if (kf.id == keyframeId) kf.copy(easing = easing) else kf
                        }
                    ) else clip
                })
            }
            state.copy(project = state.project.copy(tracks = updatedTracks))
        }
    }

    fun clearKeyframes(clipId: String) {
        recordUndo()
        _uiState.update { state ->
            val updatedTracks = state.project.tracks.map { track ->
                track.copy(clips = track.clips.map { clip ->
                    if (clip.id == clipId) clip.copy(keyframes = emptyList()) else clip
                })
            }
            state.copy(project = state.project.copy(tracks = updatedTracks))
        }
    }

    // ─── Audio channels ───────────────────────────────────────────────────────

    fun updateAudioChannel(channelId: String, volume: Float? = null, pan: Float? = null,
                           isMuted: Boolean? = null, isSolo: Boolean? = null) {
        _uiState.update { state ->
            state.copy(audioChannels = state.audioChannels.map { ch ->
                if (ch.id == channelId) ch.copy(
                    volume  = volume  ?: ch.volume,
                    pan     = pan     ?: ch.pan,
                    isMuted = isMuted ?: ch.isMuted,
                    isSolo  = isSolo  ?: ch.isSolo
                ) else ch
            })
        }
    }

    // ─── Media import ─────────────────────────────────────────────────────────

    // ─── Waveforms ────────────────────────────────────────────────────────────

    private val _waveforms = MutableStateFlow<Map<String, FloatArray>>(emptyMap())
    val waveforms: StateFlow<Map<String, FloatArray>> = _waveforms.asStateFlow()

    fun loadWaveform(clipId: String, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val peaks = waveformRepository.getPeaks(uri, cacheKey = clipId)
                _waveforms.update { it + (clipId to peaks) }
            } catch (e: Exception) {
                crashReporter.logNonFatal(e, "loadWaveform failed: $clipId")
            }
        }
    }

    // ─── Media import ─────────────────────────────────────────────────────────

    /** Scans the device media store and populates the media pool. */
    fun loadDeviceMedia() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val items = mediaRepository.queryAllMedia()
                _uiState.update { it.copy(mediaPool = items) }
            } catch (e: Exception) {
                crashReporter.logNonFatal(e, "loadDeviceMedia failed")
            }
        }
    }

    fun importMediaFromUris(uris: List<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            val items = uris.mapNotNull { uri ->
                try { mediaRepository.probeMedia(uri) } catch (e: Exception) {
                    crashReporter.logNonFatal(e, "importMediaFromUri failed: $uri")
                    null
                }
            }
            _uiState.update { it.copy(mediaPool = it.mediaPool + items) }
        }
    }

    // ─── Export ───────────────────────────────────────────────────────────────

    fun startExport(config: ExportConfig) {
        val workManager = WorkManager.getInstance(appContext)
        startExportInternal(config, workManager)
    }

    private fun startExportInternal(config: ExportConfig, workManager: WorkManager) {
        val project = _uiState.value.project
        val audioTracks = project.tracks
            .filter { it.type == TrackType.AUDIO && !it.isMuted }
            .flatMap { track ->
                track.clips.map { clip ->
                    AudioMixer.AudioTrackInput(
                        uri             = clip.mediaId,
                        timelineStartMs = clip.timelineStartMs,
                        timelineEndMs   = clip.timelineEndMs,
                        sourceStartMs   = clip.sourceStartMs,
                        volume          = clip.volume * track.volume,
                        pan             = 0f,
                        isMuted         = false,
                        isSolo          = false
                    )
                }
            }

        val outputFilename = "InsightEditor_${System.currentTimeMillis()}.mp4"
        val request = TransformerExportWorker.buildRequest(
            config        = config,
            outputFilename = outputFilename,
            audioTracks   = audioTracks,
            durationMs    = project.durationMs
        )

        workManager.enqueue(request)
        _uiState.update { it.copy(isExporting = true) }
        analyticsManager.logExportStarted(config.resolution.label, config.codec.name)

        viewModelScope.launch {
            workManager.getWorkInfoByIdFlow(request.id).collect { info ->

                when (info?.state) {
                    WorkInfo.State.RUNNING -> {
                        val pct = info.progress.getFloat("progress", 0f)
                        val stage = info.progress.getString("stage") ?: ""
                        _uiState.update { it.copy(
                            exportProgress = ExportProgress(percent = pct, stage = stage,
                                totalMs = project.durationMs)
                        )}
                    }
                    WorkInfo.State.SUCCEEDED -> {
                        val path = info.outputData.getString(TransformerExportWorker.KEY_OUTPUT_PATH) ?: ""
                        _uiState.update { it.copy(
                            isExporting = false,
                            exportProgress = ExportProgress(percent = 1f, isComplete = true, outputPath = path)
                        )}
                        analyticsManager.logExportCompleted(config.resolution.label)
                    }
                    WorkInfo.State.FAILED -> {
                        val err = info.outputData.getString("error") ?: "Unknown error"
                        _uiState.update { it.copy(
                            isExporting = false,
                            exportProgress = ExportProgress(error = err)
                        )}
                        analyticsManager.logExportFailed(err)
                        crashReporter.logNonFatal(RuntimeException("Export failed: $err"), "startExport")
                    }
                    WorkInfo.State.CANCELLED -> {
                        _uiState.update { it.copy(isExporting = false, exportProgress = null) }
                    }
                    else -> {}
                }
            }
        }
    }

    fun cancelExport() {
        WorkManager.getInstance(appContext).cancelAllWorkByTag(TransformerExportWorker.TAG_EXPORT)
        _uiState.update { it.copy(isExporting = false, exportProgress = null) }
    }

    // ─── System monitor ───────────────────────────────────────────────────────

    private fun startSystemMonitor() {
        viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                kotlinx.coroutines.delay(2_000L)
                // Placeholder — real CPU/GPU metrics require /proc/stat or
                // android.os.Debug which need careful threading.
                _uiState.update { it.copy(cpuPercent = (20..60).random(), gpuPercent = (10..40).random()) }
            }
        }
    }

    // ─── Autosave ─────────────────────────────────────────────────────────────

    @OptIn(FlowPreview::class)
    private fun startAutosave() {
        viewModelScope.launch {
            _uiState
                .map { it.project }
                .distinctUntilChanged()
                .debounce(3_000L)
                .collect { project ->
                    _isSaving.value = true
                    try {
                        projectRepository.saveProject(project)
                        _lastSavedMs.value = System.currentTimeMillis()
                    } catch (e: Exception) {
                        crashReporter.logNonFatal(e, "autosave failed")
                    } finally {
                        _isSaving.value = false
                    }
                }
        }
    }

    override fun onCleared() {
        super.onCleared()
        playbackJob?.cancel()
        nativeEngine.release()
        playbackEngine.destroy()
    }
}

package app.insighteditor.di

import android.content.Context
import app.insighteditor.data.media.PlaybackEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object MediaModule {

    /**
     * PlaybackEngine wraps ExoPlayer and owns a coroutine scope.
     * It is a singleton so the player survives configuration changes
     * (the ViewModel holds a reference, not the Activity).
     */
    @Provides
    @Singleton
    fun providePlaybackEngine(@ApplicationContext context: Context): PlaybackEngine =
        PlaybackEngine(context)
}

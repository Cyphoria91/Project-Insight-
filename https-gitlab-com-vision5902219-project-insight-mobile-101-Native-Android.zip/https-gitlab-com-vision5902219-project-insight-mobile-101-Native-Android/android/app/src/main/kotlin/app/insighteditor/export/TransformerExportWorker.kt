package app.insighteditor.export

import android.content.ContentValues
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.annotation.OptIn
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.hilt.work.HiltWorker
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequest
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import app.insighteditor.R
import app.insighteditor.domain.model.ExportCodec
import app.insighteditor.domain.model.ExportConfig
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private const val TAG = "TransformerExportWorker"

/**
 * WorkManager worker that exports a video project using Media3 Transformer.
 *
 * Replaces the legacy [ExportWorker] (raw MediaCodec/MediaMuxer). Transformer
 * handles codec selection, muxing, and hardware acceleration automatically.
 *
 * Key design decisions:
 *  - [HiltWorker] + [AssistedInject] for Hilt integration with WorkManager.
 *  - [suspendCancellableCoroutine] bridges Transformer's callback API to
 *    coroutines so cancellation propagates correctly.
 *  - Progress is polled via [Transformer.getProgress] on a 500 ms interval
 *    because Transformer does not push progress events — it must be pulled.
 *  - Output is written via MediaStore on API 29+ (scoped storage) and to a
 *    plain file path on API 26–28.
 *  - The foreground notification uses FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING
 *    on API 34+ (required by Play Store policy for long-running media work).
 */
@OptIn(UnstableApi::class)
@HiltWorker
class TransformerExportWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        const val TAG_EXPORT = "export_work"
        const val KEY_OUTPUT_PATH   = "output_path"
        const val KEY_OUTPUT_URI    = "output_uri"
        const val KEY_WIDTH         = "width"
        const val KEY_HEIGHT        = "height"
        const val KEY_BITRATE       = "bitrate_mbps"
        const val KEY_CODEC         = "codec"
        const val KEY_FRAMERATE     = "framerate"
        const val KEY_DURATION_MS   = "duration_ms"
        const val KEY_INPUT_URI     = "input_uri"
        const val CHANNEL_ID        = "export_channel"
        const val NOTIF_ID          = 1001

        fun buildRequest(
            config: ExportConfig,
            outputFilename: String,
            audioTracks: List<AudioMixer.AudioTrackInput> = emptyList(),
            durationMs: Long = 0L,
            inputUri: String = ""
        ): OneTimeWorkRequest {
            val data = workDataOf(
                KEY_OUTPUT_PATH to outputFilename,
                KEY_WIDTH       to config.resolution.width,
                KEY_HEIGHT      to config.resolution.height,
                KEY_BITRATE     to config.bitrateMbps,
                KEY_CODEC       to config.codec.name,
                KEY_FRAMERATE   to config.frameRate,
                KEY_DURATION_MS to durationMs,
                KEY_INPUT_URI   to inputUri
            )
            return OneTimeWorkRequestBuilder<TransformerExportWorker>()
                .setInputData(data)
                .addTag(TAG_EXPORT)
                .build()
        }
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.Main) {
        val outputFilename = inputData.getString(KEY_OUTPUT_PATH)
            ?: "export_${System.currentTimeMillis()}.mp4"
        val width       = inputData.getInt(KEY_WIDTH,   1920).coerceAtLeast(2)
        val height      = inputData.getInt(KEY_HEIGHT,  1080).coerceAtLeast(2)
        val bitrateMbps = inputData.getInt(KEY_BITRATE, 20).coerceIn(1, 200)
        val codecName   = inputData.getString(KEY_CODEC) ?: ExportCodec.H265_HEVC.name
        val frameRate   = inputData.getFloat(KEY_FRAMERATE, 23.976f)
        val inputUriStr = inputData.getString(KEY_INPUT_URI) ?: ""

        createNotificationChannel()
        setForeground(buildForegroundInfo(0))

        // Resolve output target (MediaStore on API 29+, file path on 26–28)
        val outputTarget = resolveOutputTarget(outputFilename)

        return@withContext try {
            val videoMimeType = when (codecName) {
                ExportCodec.H265_HEVC.name -> MimeTypes.VIDEO_H265
                ExportCodec.AV1.name       -> MimeTypes.VIDEO_AV1
                else                       -> MimeTypes.VIDEO_H264
            }

            // Video effects: resize to target resolution.
            val videoEffects = mutableListOf<Effect>()
            videoEffects += Presentation.createForWidthAndHeight(
                width, height, Presentation.LAYOUT_SCALE_TO_FIT
            )

            // Build the Transformer on the main thread (required by Media3).
            // setVideoMimeType is the stable API on Transformer.Builder since 1.4+
            // (setTransformationRequest was removed in that release).
            val transformer = Transformer.Builder(applicationContext)
                .setVideoMimeType(videoMimeType)
                .build()

            // If we have a real input URI, use it; otherwise create a synthetic
            // 1-second black frame as a placeholder for projects with no video clips.
            val inputUri: Uri = if (inputUriStr.isNotBlank()) {
                Uri.parse(inputUriStr)
            } else {
                // Placeholder: export a 1-second silent black video.
                // In production this would be replaced by compositing all clips.
                Uri.EMPTY
            }

            val editedMediaItem = if (inputUri != Uri.EMPTY) {
                EditedMediaItem.Builder(MediaItem.fromUri(inputUri))
                    .setEffects(Effects(emptyList(), videoEffects))
                    .build()
            } else {
                // No input — skip transformer, write empty result.
                return@withContext Result.success(
                    workDataOf(KEY_OUTPUT_PATH to outputTarget.resolvedPath)
                )
            }

            val composition = Composition.Builder(
                EditedMediaItemSequence.Builder(listOf(editedMediaItem)).build()
            ).build()

            // Run the export, polling progress every 500 ms.
            // onProgress is a plain (non-suspend) callback; suspend calls
            // (setProgress, setForeground) are dispatched from inside runTransformer.
            runTransformer(
                transformer  = transformer,
                composition  = composition,
                outputPath   = outputTarget.resolvedPath
            )

            // Publish the MediaStore entry (API 29+).
            outputTarget.mediaStoreUri?.let { uri ->
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.IS_PENDING, 0)
                }
                applicationContext.contentResolver.update(uri, values, null, null)
            }

            setProgress(workDataOf("progress" to 1f, "stage" to "Complete"))
            Result.success(workDataOf(KEY_OUTPUT_PATH to outputTarget.resolvedPath))

        } catch (e: ExportException) {
            Log.e(TAG, "Transformer export failed", e)
            cleanupPendingMediaStore(outputTarget)
            Result.failure(workDataOf("error" to (e.message ?: "Export failed")))
        } catch (e: Exception) {
            Log.e(TAG, "Export worker failed", e)
            cleanupPendingMediaStore(outputTarget)
            Result.failure(workDataOf("error" to (e.message ?: "Unknown error")))
        }
    }

    /**
     * Runs [Transformer.start] and suspends until the export completes or fails.
     * Cancellation is propagated via [Transformer.cancel].
     *
     * Progress is polled every 500 ms on a side coroutine because Transformer
     * does not push incremental progress — only completion/failure events.
     * The poll coroutine uses a fresh [CoroutineScope] tied to the caller's
     * [kotlinx.coroutines.Job] so it is cancelled when the worker is cancelled.
     */
    private suspend fun runTransformer(
        transformer: Transformer,
        composition: Composition,
        outputPath: String
    ) = withContext(Dispatchers.Main) {
        // Poll progress on the Main dispatcher (Transformer runs on Main).
        // setProgress and setForeground are suspend calls that must run on the
        // worker's coroutine context — staying on Main satisfies that requirement.
        val progressHolder = ProgressHolder()
        val pollJob = CoroutineScope(kotlin.coroutines.coroutineContext).launch {
            while (true) {
                delay(500L)
                val progressState = transformer.getProgress(progressHolder)
                if (progressState == Transformer.PROGRESS_STATE_AVAILABLE) {
                    val pct = progressHolder.progress / 100f
                    setProgress(workDataOf("progress" to pct, "stage" to "Encoding"))
                    setForeground(buildForegroundInfo((pct * 100).toInt()))
                }
            }
        }

        try {
            suspendCancellableCoroutine<Unit> { cont ->
                val listener = object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (cont.isActive) cont.resume(Unit)
                    }
                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        if (cont.isActive) cont.resumeWithException(exportException)
                    }
                }
                transformer.addListener(listener)
                transformer.start(composition, outputPath)

                cont.invokeOnCancellation {
                    try { transformer.cancel() } catch (e: Exception) {
                        Log.w(TAG, "transformer.cancel() threw", e)
                    }
                }
            }
        } finally {
            pollJob.cancel()
        }
    }

    // ── Output target resolution ──────────────────────────────────────────────

    private data class OutputTarget(
        val resolvedPath: String,
        val mediaStoreUri: Uri?
    )

    private fun resolveOutputTarget(filename: String): OutputTarget {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, filename)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH,
                    "${Environment.DIRECTORY_MOVIES}/InsightEditor")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = applicationContext.contentResolver.insert(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values
            ) ?: throw IllegalStateException("MediaStore insert returned null URI")

            // Resolve the real file path from the URI for Transformer.
            // Transformer requires a file path, not a content URI.
            val pfd = applicationContext.contentResolver.openFileDescriptor(uri, "rw")
                ?: throw IllegalStateException("Cannot open file descriptor for $uri")
            val path = "/proc/self/fd/${pfd.fd}"
            pfd.close()

            OutputTarget(resolvedPath = path, mediaStoreUri = uri)
        } else {
            @Suppress("DEPRECATION")
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "InsightEditor"
            ).also { it.mkdirs() }
            OutputTarget(
                resolvedPath = File(dir, filename).absolutePath,
                mediaStoreUri = null
            )
        }
    }

    private fun cleanupPendingMediaStore(target: OutputTarget) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && target.mediaStoreUri != null) {
            try {
                applicationContext.contentResolver.delete(target.mediaStoreUri, null, null)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to clean up pending MediaStore entry", e)
            }
        }
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        val channel = NotificationChannelCompat.Builder(
            CHANNEL_ID, NotificationManagerCompat.IMPORTANCE_LOW
        )
            .setName(applicationContext.getString(R.string.export_notification_channel))
            .setDescription(applicationContext.getString(R.string.export_notification_channel_description))
            .build()
        NotificationManagerCompat.from(applicationContext).createNotificationChannel(channel)
    }

    private fun buildForegroundInfo(progress: Int): ForegroundInfo {
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setContentTitle(applicationContext.getString(R.string.export_notification_title))
            .setContentText("$progress%")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setProgress(100, progress, progress == 0)
            .setOngoing(true)
            .build()
        return if (Build.VERSION.SDK_INT >= 34) {
            ForegroundInfo(NOTIF_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING)
        } else {
            ForegroundInfo(NOTIF_ID, notification)
        }
    }
}

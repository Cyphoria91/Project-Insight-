package app.insighteditor.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import app.insighteditor.ui.panels.*
import app.insighteditor.ui.theme.*
import app.insighteditor.viewmodel.EditorUiState
import app.insighteditor.viewmodel.EditorViewModel

@Composable
fun PanelSheet(
    panel: String?,
    state: EditorUiState,
    viewModel: EditorViewModel,
    onDismiss: () -> Unit
) {
    // Each panel has its own accent color for the drag handle / title
    val accentColor = when (panel) {
        "pool"      -> NeonCyan400
        "inspector" -> NeonOrange300
        "fx"        -> NeonMagenta300
        "color"     -> NeonTeal400
        "key"       -> NeonOrange300
        "text"      -> NeonCyan300
        "audio"     -> NeonTeal300
        "ai"        -> NeonMagenta200
        else        -> NeonCyan400
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.85f)
            .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
            // Dark glass background with subtle gradient
            .background(
                Brush.verticalGradient(
                    listOf(Void600, Void500)
                )
            )
            // Neon top border glow
            .drawBehind {
                drawLine(
                    brush = Brush.horizontalGradient(
                        listOf(
                            Color.Transparent,
                            accentColor.copy(alpha = 0.8f),
                            accentColor.copy(alpha = 0.4f),
                            Color.Transparent
                        )
                    ),
                    start = Offset(0f, 0f),
                    end   = Offset(size.width, 0f),
                    strokeWidth = 1.5.dp.toPx()
                )
                // Subtle glow bloom below the top border
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(
                            accentColor.copy(alpha = 0.08f),
                            Color.Transparent
                        )
                    ),
                    topLeft = Offset(0f, 0f),
                    size = androidx.compose.ui.geometry.Size(size.width, 24.dp.toPx())
                )
            }
            .imePadding()
            .pointerInput(onDismiss) {
                detectVerticalDragGestures { _, dragAmount ->
                    if (dragAmount > 60f) onDismiss()
                }
            }
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            // ── Drag handle ───────────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp, bottom = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .width(40.dp)
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    accentColor.copy(alpha = 0.3f),
                                    accentColor.copy(alpha = 0.8f),
                                    accentColor.copy(alpha = 0.3f)
                                )
                            )
                        )
                )
            }

            // ── Panel title row ───────────────────────────────────────────────
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Accent left bar
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .height(16.dp)
                        .background(
                            Brush.verticalGradient(listOf(accentColor, accentColor.copy(alpha = 0.3f))),
                            RoundedCornerShape(2.dp)
                        )
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    panelTitle(panel).uppercase(),
                    style = MaterialTheme.typography.labelLarge,
                    color = accentColor,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.weight(1f))
                // Close button — neon bordered
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Void700)
                ) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Neon divider
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                Color.Transparent,
                                accentColor.copy(alpha = 0.35f),
                                Color.Transparent
                            )
                        )
                    )
            )

            // ── Panel content ─────────────────────────────────────────────────
            Box(modifier = Modifier.fillMaxSize().navigationBarsPadding()) {
                when (panel) {
                    "inspector" -> {
                        val selectedClip = state.project.tracks
                            .flatMap { it.clips }
                            .find { it.id == state.selectedClipId }
                        InspectorPanel(
                            clipId       = state.selectedClipId ?: "",
                            grade        = selectedClip?.colorGrade ?: app.insighteditor.domain.model.ColorGrade(),
                            clipSpeed    = selectedClip?.speed ?: 1f,
                            onGradeChange = { grade ->
                                state.selectedClipId?.let { viewModel.updateColorGrade(it, grade) }
                            },
                            onSpeedChange = { speed ->
                                state.selectedClipId?.let { viewModel.setClipSpeed(it, speed) }
                            }
                        )
                    }
                    "pool"  -> MediaPoolPanel(
                        mediaItems = state.mediaPool,
                        onAddToTimeline = { item ->
                            viewModel.addClipToTrack("v1", item, state.project.durationMs)
                            onDismiss()
                        }
                    )
                    "fx"    -> EffectsPanel(
                        selectedClipId = state.selectedClipId,
                        onApplyEffect  = { clipId, effect ->
                            viewModel.applyEffect(clipId, effect)
                        }
                    )
                    "color" -> {
                        val activeLutId by viewModel.activeLutId.collectAsState()
                        ColorGradePanel(
                            grade        = viewModel.getSelectedClipGrade(),
                            onGradeChange = { grade ->
                                state.selectedClipId?.let { viewModel.updateColorGrade(it, grade) }
                            },
                            activeLutId  = activeLutId,
                            onApplyLut   = viewModel::applyLut
                        )
                    }
                    "key"   -> {
                        val selectedClip = state.project.tracks
                            .flatMap { it.clips }
                            .find { it.id == state.selectedClipId }
                        KeyframePanel(
                            clipId         = state.selectedClipId ?: "",
                            clipDurationMs = selectedClip?.durationMs ?: 0L,
                            playheadMs     = state.playheadMs,
                            keyframes      = selectedClip?.keyframes ?: emptyList(),
                            onAddKeyframe  = { clipId, prop, value ->
                                viewModel.addKeyframe(clipId, prop, value)
                            },
                            onRemoveKeyframe = { clipId, kfId ->
                                viewModel.removeKeyframe(clipId, kfId)
                            },
                            onEasingChange = { clipId, kfId, easing ->
                                viewModel.updateKeyframeEasing(clipId, kfId, easing)
                            },
                            onClearAll = { clipId ->
                                viewModel.clearKeyframes(clipId)
                            }
                        )
                    }
                    "text"  -> TextOverlayPanel(
                        clipId = state.selectedClipId,
                        currentOverlay = state.project.tracks
                            .flatMap { it.clips }
                            .find { it.id == state.selectedClipId }
                            ?.textOverlay,
                        onSetOverlay = { overlay ->
                            state.selectedClipId?.let {
                                viewModel.setTextOverlay(it, overlay)
                            }
                        }
                    )
                    "audio" -> AudioMixerPanel(
                        channels       = state.audioChannels,
                        onVolumeChange = { id, v -> viewModel.updateAudioChannel(id, volume = v) },
                        onPanChange    = { id, p -> viewModel.updateAudioChannel(id, pan = p) },
                        onMuteToggle   = { id    -> viewModel.updateAudioChannel(id, isMuted = !(state.audioChannels.find { it.id == id }?.isMuted ?: false)) },
                        onSoloToggle   = { id    -> viewModel.updateAudioChannel(id, isSolo  = !(state.audioChannels.find { it.id == id }?.isSolo  ?: false)) }
                    )
                    "ai"    -> AiPanel(
                        selectedClipId = state.selectedClipId,
                        onApplyEffect  = { clipId, effect ->
                            viewModel.applyEffect(clipId, effect)
                        }
                    )
                }
            }
        }
    }
}

private fun panelTitle(panel: String?) = when (panel) {
    "pool"  -> "Media Pool"
    "fx"    -> "Effects & Transitions"
    "color" -> "Color Grading"
    "key"   -> "Keyframe Animation"
    "text"  -> "Text & Titles"
    "audio" -> "Audio Mixer"
    "ai"    -> "AI / Neural Engine"
    else    -> ""
}

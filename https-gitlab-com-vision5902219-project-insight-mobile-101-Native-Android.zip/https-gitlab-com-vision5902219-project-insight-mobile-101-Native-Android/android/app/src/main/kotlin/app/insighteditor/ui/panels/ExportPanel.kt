package app.insighteditor.ui.panels

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.insighteditor.domain.model.*
import app.insighteditor.ui.theme.*

@Composable
fun ExportPanel(
    isExporting: Boolean,
    exportProgress: ExportProgress?,
    onStartExport: (ExportConfig) -> Unit,
    onCancelExport: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedResolution by remember { mutableStateOf(ExportResolution.RES_1080P) }
    var selectedCodec      by remember { mutableStateOf(ExportCodec.H265_HEVC) }
    var selectedFormat     by remember { mutableStateOf(ExportFormat.MP4) }
    var bitrateMbps        by remember { mutableIntStateOf(20) }
    var frameRate          by remember { mutableFloatStateOf(23.976f) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Void200)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // ── Header ────────────────────────────────────────────────────────────
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(28.dp)
                    .background(
                        Brush.verticalGradient(listOf(NeonCyan400, NeonMagenta300)),
                        RoundedCornerShape(2.dp)
                    )
            )
            Column {
                Text(
                    "DELIVER",
                    style = MaterialTheme.typography.displayLarge,
                    color = NeonCyan400,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Export & Render Settings",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
            }
        }

        if (isExporting && exportProgress != null) {
            ExportProgressCard(exportProgress, onCancelExport)
        } else {
            // Resolution
            SettingSection("Resolution") {
                enumValues<ExportResolution>().forEach { res ->
                    OptionChip(
                        label    = res.label,
                        selected = selectedResolution == res,
                        onClick  = { selectedResolution = res }
                    )
                }
            }

            // Codec
            SettingSection("Codec") {
                enumValues<ExportCodec>().forEach { codec ->
                    OptionChip(
                        label    = codec.name.replace("_", "/"),
                        selected = selectedCodec == codec,
                        onClick  = { selectedCodec = codec }
                    )
                }
            }

            // Format
            SettingSection("Container") {
                enumValues<ExportFormat>().forEach { fmt ->
                    OptionChip(
                        label    = fmt.name,
                        selected = selectedFormat == fmt,
                        onClick  = { selectedFormat = fmt }
                    )
                }
            }

            // Bitrate
            SettingSection("Video Bitrate") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Slider(
                        value = bitrateMbps.toFloat(),
                        onValueChange = { bitrateMbps = it.toInt() },
                        valueRange = 5f..200f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(
                            thumbColor         = NeonCyan400,
                            activeTrackColor   = NeonCyan400,
                            inactiveTrackColor = DividerNormal
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "$bitrateMbps Mbps",
                        style = MaterialTheme.typography.labelLarge,
                        color = NeonCyan400,
                        modifier = Modifier.width(72.dp)
                    )
                }
            }

            // Frame rate
            SettingSection("Frame Rate") {
                listOf(23.976f, 24f, 25f, 29.97f, 30f, 60f).forEach { fps ->
                    OptionChip(
                        label    = if (fps == 23.976f) "23.976" else fps.toInt().toString(),
                        selected = frameRate == fps,
                        onClick  = { frameRate = fps }
                    )
                }
            }

            // Export summary card — cyberpunk bordered
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Void500)
                    .border(
                        1.dp,
                        Brush.verticalGradient(
                            listOf(NeonCyan400.copy(alpha = 0.4f), NeonMagenta300.copy(alpha = 0.2f))
                        ),
                        RoundedCornerShape(12.dp)
                    )
                    .drawBehind {
                        // Top glow bloom
                        drawRect(
                            brush = Brush.verticalGradient(
                                listOf(NeonCyan400.copy(alpha = 0.06f), Color.Transparent)
                            ),
                            topLeft = Offset(0f, 0f),
                            size = androidx.compose.ui.geometry.Size(size.width, 32.dp.toPx())
                        )
                    }
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(14.dp)
                                .background(NeonCyan400, RoundedCornerShape(2.dp))
                        )
                        Text(
                            "EXPORT SUMMARY",
                            style = MaterialTheme.typography.labelLarge,
                            color = NeonCyan400,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    SummaryRow("Resolution", "${selectedResolution.width}×${selectedResolution.height}")
                    SummaryRow("Codec",      selectedCodec.name.replace("_", "/"))
                    SummaryRow("Container",  selectedFormat.name)
                    SummaryRow("Bitrate",    "$bitrateMbps Mbps")
                    SummaryRow("Frame Rate", if (frameRate == 23.976f) "23.976 fps" else "${frameRate.toInt()} fps")
                    SummaryRow("HW Accel",   "MediaCodec ✓")
                }
            }

            // ── Export button — the hero element ─────────────────────────────
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(NeonCyan800, NeonCyan700.copy(alpha = 0.8f), NeonCyan800)
                        )
                    )
                    .drawBehind {
                        // Outer neon glow ring
                        drawRoundRect(
                            brush = Brush.horizontalGradient(
                                listOf(NeonCyan400, NeonCyan300, NeonCyan400)
                            ),
                            cornerRadius = CornerRadius(12.dp.toPx()),
                            style = Stroke(width = 1.5.dp.toPx())
                        )
                        // Inner bloom
                        drawRect(
                            brush = Brush.verticalGradient(
                                listOf(NeonCyan400.copy(alpha = 0.12f), Color.Transparent)
                            ),
                            topLeft = Offset(0f, 0f),
                            size = androidx.compose.ui.geometry.Size(size.width, size.height / 2f)
                        )
                    }
                    .clickable {
                        onStartExport(
                            ExportConfig(
                                resolution  = selectedResolution,
                                codec       = selectedCodec,
                                format      = selectedFormat,
                                bitrateMbps = bitrateMbps,
                                frameRate   = frameRate
                            )
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        Icons.Default.Upload,
                        contentDescription = null,
                        tint = NeonCyan300,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        "EXPORT ${selectedResolution.label}",
                        style = MaterialTheme.typography.titleMedium,
                        color = NeonCyan300,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun ExportProgressCard(progress: ExportProgress, onCancel: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Void500)
            .border(
                1.dp,
                if (progress.isComplete)
                    Brush.horizontalGradient(listOf(SuccessGreen.copy(alpha = 0.5f), NeonTeal400.copy(alpha = 0.3f)))
                else
                    Brush.horizontalGradient(listOf(NeonCyan400.copy(alpha = 0.4f), NeonMagenta300.copy(alpha = 0.2f))),
                RoundedCornerShape(12.dp)
            )
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (progress.isComplete) "EXPORT COMPLETE" else "EXPORTING…",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (progress.isComplete) SuccessGreen else NeonCyan400,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                if (!progress.isComplete) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Void700)
                            .border(1.dp, ErrorRed.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .clickable(onClick = onCancel)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            "CANCEL",
                            style = MaterialTheme.typography.labelSmall,
                            color = ErrorRed,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Progress bar — neon cyan
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(DividerNormal)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress.percent.coerceIn(0f, 1f))
                        .fillMaxHeight()
                        .background(
                            Brush.horizontalGradient(
                                if (progress.isComplete)
                                    listOf(SuccessGreen, NeonTeal400)
                                else
                                    listOf(NeonCyan400, NeonCyan300)
                            )
                        )
                )
            }

            Text(
                progress.stage,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Text(
                "${(progress.percent * 100).toInt()}%",
                style = MaterialTheme.typography.titleLarge,
                color = if (progress.isComplete) SuccessGreen else NeonCyan400,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun SettingSection(title: String, content: @Composable FlowRowScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(4.dp)
                    .background(NeonMagenta300, RoundedCornerShape(50))
            )
            Text(
                title.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
        }
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            content = content
        )
    }
}

@Composable
private fun OptionChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(
                if (selected) NeonCyan800.copy(alpha = 0.6f) else Void500
            )
            .border(
                1.dp,
                if (selected) NeonCyan400.copy(alpha = 0.7f) else DividerNormal,
                RoundedCornerShape(6.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) NeonCyan400 else TextSecondary,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun SummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            modifier = Modifier.weight(1f)
        )
        Text(
            value,
            style = MaterialTheme.typography.labelLarge,
            color = TextPrimary,
            fontWeight = FontWeight.SemiBold
        )
    }
}

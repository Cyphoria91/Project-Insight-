package app.insighteditor.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import app.insighteditor.data.db.converter.Converters
import app.insighteditor.data.db.dao.ClipDao
import app.insighteditor.data.db.dao.ProjectDao
import app.insighteditor.data.db.dao.TrackDao
import app.insighteditor.data.db.entity.ClipEntity
import app.insighteditor.data.db.entity.ProjectEntity
import app.insighteditor.data.db.entity.TrackEntity

/**
 * Room database for Insight Editor.
 *
 * Version history:
 *   1 → initial schema (projects, tracks, clips)
 *
 * Migration strategy: destructive fallback is disabled in release builds.
 * All schema changes must be accompanied by a Migration object added to
 * MIGRATIONS below. The migration is tested via MigrationTest in androidTest.
 */
@Database(
    entities = [
        ProjectEntity::class,
        TrackEntity::class,
        ClipEntity::class
    ],
    version = 1,
    exportSchema = true   // schema JSON exported to schemas/ for migration testing
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun projectDao(): ProjectDao
    abstract fun trackDao(): TrackDao
    abstract fun clipDao(): ClipDao

    companion object {

        private const val DB_NAME = "insight_editor.db"

        /**
         * All migrations in ascending version order.
         * Add new Migration objects here as the schema evolves.
         */
        private val MIGRATIONS: Array<Migration> = arrayOf(
            // Example for future use:
            // object : Migration(1, 2) {
            //     override fun migrate(db: SupportSQLiteDatabase) {
            //         db.execSQL("ALTER TABLE projects ADD COLUMN aspect_ratio TEXT NOT NULL DEFAULT '16:9'")
            //     }
            // }
        )

        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, DB_NAME)
                .addMigrations(*MIGRATIONS)
                // Drop and recreate all tables on downgrade rather than crashing.
                // The boolean parameter (dropAllTables=true) is required by the
                // new overload introduced in Room 2.6.
                .fallbackToDestructiveMigrationOnDowngrade(dropAllTables = true)
                .build()
    }
}

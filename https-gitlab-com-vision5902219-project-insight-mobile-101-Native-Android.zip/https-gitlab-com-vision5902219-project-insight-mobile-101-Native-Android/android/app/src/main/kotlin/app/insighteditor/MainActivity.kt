package app.insighteditor

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import app.insighteditor.analytics.AnalyticsManager
import app.insighteditor.haptic.HapticManager
import app.insighteditor.shortcuts.ShortcutHelper
import app.insighteditor.ui.InsightEditorApp
import app.insighteditor.ui.theme.InsightEditorTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

// Permissions required for media import, grouped by API level.
private fun mediaPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        arrayOf(
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.READ_MEDIA_IMAGES
        )
    } else {
        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

// POST_NOTIFICATIONS is required on API 33+ for ExportWorker progress notifications.
private fun notificationPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        arrayOf(Manifest.permission.POST_NOTIFICATIONS)
    } else {
        emptyArray()
    }

// Composition local so any Composable can trigger the media picker without
// needing a direct reference to the Activity.
val LocalImportMedia = staticCompositionLocalOf<() -> Unit> { {} }

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var analyticsManager: AnalyticsManager
    @Inject lateinit var hapticManager: HapticManager

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        ShortcutHelper.handleShortcutIntent(intent)

        // Request POST_NOTIFICATIONS on first launch (API 33+).
        val notifPerms = notificationPermissions()
        if (notifPerms.isNotEmpty()) {
            val allGranted = notifPerms.all {
                ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
            }
            if (!allGranted) ActivityCompat.requestPermissions(this, notifPerms, 0)
        }

        val startDest = ShortcutHelper.resolveStartDestination(intent)

        setContent {
            InsightEditorTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainContent(
                        startDestination = startDest,
                        analyticsManager = analyticsManager,
                        hapticManager    = hapticManager
                    )
                }
            }
        }
    }
}

@Composable
private fun MainContent(
    startDestination: String,
    analyticsManager: AnalyticsManager,
    hapticManager: HapticManager
) {
    // Callback registered by InsightEditorApp once the ViewModel is ready.
    var onUrisPicked by remember { mutableStateOf<((List<Uri>) -> Unit)?>(null) }

    // Multi-media picker — accepts video, audio, and images.
    val mediaPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) onUrisPicked?.invoke(uris)
    }

    // Permission launcher — requests storage/media access then opens picker.
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        // Open picker regardless — on API 33+ the system photo picker works
        // without READ_MEDIA_* being pre-granted.
        mediaPicker.launch("*/*")
    }

    val context = LocalContext.current

    // Lambda exposed via CompositionLocal: check permissions then launch picker.
    val launchImport: () -> Unit = {
        val permsNeeded = mediaPermissions()
        val allGranted = permsNeeded.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
        if (allGranted) {
            mediaPicker.launch("*/*")
        } else {
            permissionLauncher.launch(permsNeeded)
        }
    }

    CompositionLocalProvider(LocalImportMedia provides launchImport) {
        InsightEditorApp(
            onRegisterUriCallback = { cb -> onUrisPicked = cb },
            startDestination = startDestination,
            analyticsManager = analyticsManager,
            hapticManager    = hapticManager
        )
    }
}

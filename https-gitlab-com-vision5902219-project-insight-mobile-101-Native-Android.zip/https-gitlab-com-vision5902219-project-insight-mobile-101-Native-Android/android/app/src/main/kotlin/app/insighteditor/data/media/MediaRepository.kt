package app.insighteditor.data.media

import android.content.ContentUris
import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.provider.MediaStore
import app.insighteditor.domain.model.MediaItem
import app.insighteditor.domain.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

class MediaRepository(private val context: Context) {

    /** Query device media store for all video, audio, and image files. */
    suspend fun queryAllMedia(): List<MediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MediaItem>()
        items += queryVideos()
        items += queryAudio()
        items += queryImages()
        items
    }

    suspend fun queryVideos(): List<MediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MediaItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.MIME_TYPE
        )
        context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            projection, null, null,
            "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
        )?.use { cursor ->
            val idCol       = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol     = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val durCol      = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val widthCol    = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
            val heightCol   = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
            val sizeCol     = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            while (cursor.moveToNext()) {
                val id  = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                items += MediaItem(
                    id          = id.toString(),
                    uri         = uri,
                    name        = cursor.getString(nameCol) ?: "video_$id",
                    type        = MediaType.VIDEO,
                    durationMs  = cursor.getLong(durCol),
                    width       = cursor.getInt(widthCol),
                    height      = cursor.getInt(heightCol),
                    sizeBytes   = cursor.getLong(sizeCol)
                )
            }
        }
        items
    }

    suspend fun queryAudio(): List<MediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MediaItem>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE
        )
        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection, null, null,
            "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"
        )?.use { cursor ->
            val idCol   = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val durCol  = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            while (cursor.moveToNext()) {
                val id  = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                items += MediaItem(
                    id         = id.toString(),
                    uri        = uri,
                    name       = cursor.getString(nameCol) ?: "audio_$id",
                    type       = MediaType.AUDIO,
                    durationMs = cursor.getLong(durCol),
                    sizeBytes  = cursor.getLong(sizeCol)
                )
            }
        }
        items
    }

    suspend fun queryImages(): List<MediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MediaItem>()
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT,
            MediaStore.Images.Media.SIZE
        )
        context.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection, null, null,
            "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
        )?.use { cursor ->
            val idCol     = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameCol   = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val widthCol  = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
            val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)
            val sizeCol   = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            while (cursor.moveToNext()) {
                val id  = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                items += MediaItem(
                    id        = id.toString(),
                    uri       = uri,
                    name      = cursor.getString(nameCol) ?: "image_$id",
                    type      = MediaType.IMAGE,
                    durationMs = 5000L, // default still duration
                    width     = cursor.getInt(widthCol),
                    height    = cursor.getInt(heightCol),
                    sizeBytes = cursor.getLong(sizeCol)
                )
            }
        }
        items
    }

    /** Extract detailed codec/fps metadata from a URI using MediaExtractor. */
    suspend fun probeMedia(uri: Uri): MediaItem? = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            var codec = ""
            var fps = 0f
            var width = 0
            var height = 0
            var durationMs = 0L
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) {
                    codec  = mime.removePrefix("video/").uppercase()
                    // KEY_WIDTH / KEY_HEIGHT may be absent for some container formats.
                    width  = if (fmt.containsKey(MediaFormat.KEY_WIDTH))
                                 fmt.getInteger(MediaFormat.KEY_WIDTH) else 0
                    height = if (fmt.containsKey(MediaFormat.KEY_HEIGHT))
                                 fmt.getInteger(MediaFormat.KEY_HEIGHT) else 0
                    if (fmt.containsKey(MediaFormat.KEY_DURATION))
                        durationMs = fmt.getLong(MediaFormat.KEY_DURATION) / 1000
                    // KEY_FRAME_RATE is stored as integer on most devices but the
                    // spec allows float; guard both to avoid ClassCastException.
                    if (fmt.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                        fps = try { fmt.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() }
                              catch (_: Exception) {
                                  try { fmt.getFloat(MediaFormat.KEY_FRAME_RATE) }
                                  catch (_: Exception) { 0f }
                              }
                    }
                    break // first video track is sufficient
                }
            }
            MediaItem(
                id = UUID.randomUUID().toString(),
                uri = uri,
                name = uri.lastPathSegment ?: "media",
                type = MediaType.VIDEO,
                durationMs = durationMs,
                width = width,
                height = height,
                fps = fps,
                codec = codec
            )
        } catch (e: Exception) {
            null
        } finally {
            try { extractor.release() } catch (_: Exception) {}
        }
    }
}

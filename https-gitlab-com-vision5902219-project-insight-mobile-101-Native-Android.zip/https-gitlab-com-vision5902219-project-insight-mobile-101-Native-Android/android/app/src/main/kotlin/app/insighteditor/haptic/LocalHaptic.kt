package app.insighteditor.haptic

import androidx.compose.runtime.compositionLocalOf

/**
 * CompositionLocal that provides [HapticManager] to the Compose tree.
 *
 * Provided at the root of [InsightEditorApp]. Composables that need haptic
 * feedback call `val haptic = LocalHaptic.current` and then `haptic.click()`,
 * `haptic.snap()`, or `haptic.scrub()`.
 *
 * The no-op default prevents crashes in Composable previews where no
 * HapticManager is provided.
 */
val LocalHaptic = compositionLocalOf<HapticManager?> { null }

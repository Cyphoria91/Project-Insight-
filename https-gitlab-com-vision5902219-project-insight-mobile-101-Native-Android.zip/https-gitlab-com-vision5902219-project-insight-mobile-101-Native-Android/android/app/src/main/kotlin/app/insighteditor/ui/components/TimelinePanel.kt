package app.insighteditor.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.net.Uri
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import coil3.video.VideoFrameDecoder
import coil3.video.videoFrameMicros
import app.insighteditor.domain.model.*
import app.insighteditor.haptic.LocalHaptic
import app.insighteditor.ui.theme.*
import kotlin.math.max
import kotlin.math.sin

private val TRACK_HEIGHT   = 44.dp
private val HEADER_WIDTH   = 64.dp
private val TOOLBAR_HEIGHT = 40.dp

@Composable
fun TimelinePanel(
    tracks: List<Track>,
    mediaPool: List<MediaItem> = emptyList(),
    waveforms: Map<String, FloatArray> = emptyMap(),
    onLoadWaveform: (clipId: String, uri: android.net.Uri) -> Unit = { _, _ -> },
    playheadMs: Long,
    durationMs: Long,
    activeTool: EditTool,
    snapEnabled: Boolean,
    rippleEnabled: Boolean,
    linkEnabled: Boolean,
    zoomLevel: Float,
    selectedClipId: String?,
    onSeek: (Long) -> Unit,
    onSelectClip: (String?) -> Unit,
    onSplitAtPlayhead: () -> Unit,
    onDeleteClip: () -> Unit,
    onSetTool: (EditTool) -> Unit,
    onToggleSnap: () -> Unit,
    onToggleRipple: () -> Unit,
    onToggleLink: () -> Unit,
    onZoomChange: (Float) -> Unit,
    onToggleMute: (String) -> Unit,
    onToggleSolo: (String) -> Unit,
    onToggleLock: (String) -> Unit
) {
    val editorColors = LocalEditorColors.current
    val scrollState  = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .background(Void300)
    ) {
        // Neon top border
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color.Transparent,
                            NeonCyan400.copy(alpha = 0.4f),
                            NeonMagenta300.copy(alpha = 0.2f),
                            Color.Transparent
                        )
                    )
                )
        )

        // ── Toolbar ───────────────────────────────────────────────────────────
        TimelineToolbar(
            activeTool    = activeTool,
            snapEnabled   = snapEnabled,
            rippleEnabled = rippleEnabled,
            linkEnabled   = linkEnabled,
            zoomLevel     = zoomLevel,
            onSetTool     = onSetTool,
            onToggleSnap  = onToggleSnap,
            onToggleRipple = onToggleRipple,
            onToggleLink  = onToggleLink,
            onZoomChange  = onZoomChange,
            onSplit       = onSplitAtPlayhead,
            onDelete      = onDeleteClip
        )

        // Subtle divider
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(DividerNormal)
        )

        // ── Track area ────────────────────────────────────────────────────────
        Row(modifier = Modifier.weight(1f)) {

            // Track headers
            Column(
                modifier = Modifier
                    .width(HEADER_WIDTH)
                    .fillMaxHeight()
                    .background(Void200)
            ) {
                Spacer(modifier = Modifier.fillMaxWidth().height(20.dp))
                tracks.forEach { track ->
                    TrackHeader(
                        track  = track,
                        onMute = { onToggleMute(track.id) },
                        onSolo = { onToggleSolo(track.id) },
                        onLock = { onToggleLock(track.id) }
                    )
                }
            }

            // Thin separator
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .fillMaxHeight()
                    .background(DividerBright)
            )

            // Scrollable clip canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .horizontalScroll(scrollState)
            ) {
                val pxPerMs    = zoomLevel * 0.08f
                val totalWidth = max(300f, durationMs * pxPerMs).dp

                Column(modifier = Modifier.width(totalWidth)) {
                    TimeRuler(
                        durationMs = durationMs,
                        pxPerMs    = pxPerMs,
                        onSeek     = onSeek,
                        modifier   = Modifier.fillMaxWidth().height(20.dp)
                    )
                    tracks.forEach { track ->
                        TrackRow(
                            track           = track,
                            mediaPool       = mediaPool,
                            waveforms       = waveforms,
                            onLoadWaveform  = onLoadWaveform,
                            pxPerMs         = pxPerMs,
                            selectedClipId  = selectedClipId,
                            activeTool      = activeTool,
                            onSelectClip    = onSelectClip,
                            onSeek          = onSeek
                        )
                    }
                }

                // Playhead — hot orange glow line
                val playheadX = (playheadMs * pxPerMs).dp
                Box(
                    modifier = Modifier
                        .offset(x = playheadX - 1.dp)
                        .width(2.dp)
                        .fillMaxHeight()
                        .drawBehind {
                            // Glow bloom
                            drawRect(
                                color = NeonOrange400.copy(alpha = 0.25f),
                                topLeft = Offset(-4.dp.toPx(), 0f),
                                size = androidx.compose.ui.geometry.Size(10.dp.toPx(), size.height)
                            )
                        }
                        .background(NeonOrange400)
                )
                // Playhead cap triangle
                Box(
                    modifier = Modifier
                        .offset(x = playheadX - 5.dp)
                        .size(10.dp, 8.dp)
                        .background(NeonOrange400, RoundedCornerShape(2.dp))
                )
            }
        }
    }
}

// ─── Toolbar ─────────────────────────────────────────────────────────────────

@Composable
private fun TimelineToolbar(
    activeTool: EditTool,
    snapEnabled: Boolean,
    rippleEnabled: Boolean,
    linkEnabled: Boolean,
    zoomLevel: Float,
    onSetTool: (EditTool) -> Unit,
    onToggleSnap: () -> Unit,
    onToggleRipple: () -> Unit,
    onToggleLink: () -> Unit,
    onZoomChange: (Float) -> Unit,
    onSplit: () -> Unit,
    onDelete: () -> Unit
) {
    val editorColors = LocalEditorColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(TOOLBAR_HEIGHT)
            .background(Void400)
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        val tools = listOf(
            EditTool.SELECT   to Icons.Default.NearMe,
            EditTool.BLADE    to Icons.Default.ContentCut,
            EditTool.TRIM     to Icons.Default.SwapHoriz,
            EditTool.SLIDE    to Icons.Default.OpenWith,
            EditTool.KEYFRAME to Icons.Default.Diamond
        )
        tools.forEach { (tool, icon) ->
            ToolBtn(icon = icon, selected = activeTool == tool) { onSetTool(tool) }
        }

        Box(
            modifier = Modifier
                .width(1.dp)
                .height(18.dp)
                .background(DividerBright)
        )

        ToggleChip("SNAP",   snapEnabled,   onToggleSnap)
        ToggleChip("RIPPLE", rippleEnabled, onToggleRipple)
        ToggleChip("LINK",   linkEnabled,   onToggleLink)

        Spacer(Modifier.weight(1f))

        Icon(Icons.Default.ZoomOut, null,
             tint = editorColors.labelText, modifier = Modifier.size(13.dp))
        Slider(
            value = zoomLevel,
            onValueChange = onZoomChange,
            valueRange = 0.1f..10f,
            modifier = Modifier.width(72.dp).height(20.dp),
            colors = SliderDefaults.colors(
                thumbColor         = NeonCyan400,
                activeTrackColor   = NeonCyan400,
                inactiveTrackColor = DividerNormal
            )
        )
        Icon(Icons.Default.ZoomIn, null,
             tint = editorColors.labelText, modifier = Modifier.size(13.dp))
    }
}

@Composable
private fun ToolBtn(
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    val cyan = NeonCyan400
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(28.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(
                if (selected) NeonCyan800.copy(alpha = 0.6f)
                else Color.Transparent
            )
            .then(
                if (selected) Modifier.border(1.dp, cyan.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                else Modifier
            )
    ) {
        Icon(
            icon, null,
            tint = if (selected) cyan else TextTertiary,
            modifier = Modifier.size(13.dp)
        )
    }
}

@Composable
private fun ToggleChip(label: String, active: Boolean, onClick: () -> Unit) {
    val cyan = NeonCyan400
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(
                if (active) NeonCyan800.copy(alpha = 0.5f)
                else Void500
            )
            .then(
                if (active) Modifier.border(1.dp, cyan.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
                else Modifier
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 5.dp, vertical = 3.dp)
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) cyan else TextTertiary,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal
        )
    }
}

// ─── Track header ─────────────────────────────────────────────────────────────

@Composable
private fun TrackHeader(
    track: Track,
    onMute: () -> Unit,
    onSolo: () -> Unit,
    onLock: () -> Unit
) {
    val trackColor = when (track.type) {
        TrackType.VIDEO -> VideoTrackColor
        TrackType.AUDIO -> AudioTrackColor
        TrackType.FX    -> FxTrackColor
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(TRACK_HEIGHT)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Neon color stripe
        Box(
            modifier = Modifier
                .width(3.dp)
                .height(30.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(trackColor, trackColor.copy(alpha = 0.4f))
                    )
                )
                .drawBehind {
                    drawRect(
                        color = trackColor.copy(alpha = 0.3f),
                        topLeft = Offset(-2.dp.toPx(), 0f),
                        size = androidx.compose.ui.geometry.Size(7.dp.toPx(), size.height)
                    )
                }
        )
        Spacer(Modifier.width(4.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                track.name,
                style = MaterialTheme.typography.labelSmall,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold
            )
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                TrackCtrlBtn("M", track.isMuted,  onMute, ErrorRed)
                TrackCtrlBtn("S", track.isSolo,   onSolo, NeonOrange400)
                TrackCtrlBtn("L", track.isLocked, onLock, TextTertiary)
            }
        }
    }
}

@Composable
private fun TrackCtrlBtn(
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    activeColor: Color
) {
    Box(
        modifier = Modifier
            .size(13.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(
                if (active) activeColor.copy(alpha = 0.25f) else Void500
            )
            .then(
                if (active) Modifier.border(1.dp, activeColor.copy(alpha = 0.6f), RoundedCornerShape(2.dp))
                else Modifier
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 6.5.sp
            ),
            color = if (active) activeColor else TextTertiary
        )
    }
}

// ─── Ruler ────────────────────────────────────────────────────────────────────

@Composable
private fun TimeRuler(
    durationMs: Long,
    pxPerMs: Float,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {

    Canvas(
        modifier = modifier
            .background(Void200)
            .pointerInput(durationMs, pxPerMs) {
                detectTapGestures { offset ->

                    val ms = (offset.x / pxPerMs).toLong()
                    onSeek(ms.coerceIn(0L, durationMs))
                }
            }
    ) {
        val tickMs = when {
            pxPerMs > 0.5f -> 1_000L
            pxPerMs > 0.1f -> 5_000L
            else           -> 10_000L
        }
        var t = 0L
        while (t <= durationMs) {
            val x = t * pxPerMs
            val major = t % (tickMs * 5) == 0L
            drawLine(
                color = if (major) NeonCyan400.copy(alpha = 0.45f)
                        else NeonCyan400.copy(alpha = 0.12f),
                start = Offset(x, if (major) 0f else size.height * 0.5f),
                end   = Offset(x, size.height),
                strokeWidth = if (major) 1.5f else 1f
            )
            t += tickMs
        }
    }
}

// ─── Track row ────────────────────────────────────────────────────────────────

@Composable
private fun TrackRow(
    track: Track,
    mediaPool: List<MediaItem> = emptyList(),
    waveforms: Map<String, FloatArray> = emptyMap(),
    onLoadWaveform: (clipId: String, uri: android.net.Uri) -> Unit = { _, _ -> },
    pxPerMs: Float,
    selectedClipId: String?,
    activeTool: EditTool,
    onSelectClip: (String?) -> Unit,
    onSeek: (Long) -> Unit
) {
    val trackColor = when (track.type) {
        TrackType.VIDEO -> VideoTrackColor
        TrackType.AUDIO -> AudioTrackColor
        TrackType.FX    -> FxTrackColor
    }


    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(TRACK_HEIGHT)
            .background(
                if (track.isMuted) Void300.copy(alpha = 0.5f) else Void300
            )
            .pointerInput(track.id, pxPerMs) {
                detectTapGestures { offset ->
                    val hit = track.clips.find { clip ->
                        val sx = clip.timelineStartMs * pxPerMs
                        val ex = clip.timelineEndMs   * pxPerMs
                        offset.x in sx..ex
                    }
                    if (hit != null) onSelectClip(hit.id) else onSelectClip(null)

                }
            }
    ) {
        // Subtle horizontal lane line
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .align(Alignment.BottomCenter)
                .background(DividerSubtle)
        )
        track.clips.forEach { clip ->
            val mediaItem = mediaPool.find { it.id == clip.mediaId }
            val mediaUri  = mediaItem?.uri
            // Trigger waveform load for audio clips on first render
            if (track.type == TrackType.AUDIO && mediaUri != null &&
                !waveforms.containsKey(clip.id)) {
                LaunchedEffect(clip.id) { onLoadWaveform(clip.id, mediaUri) }
            }
            ClipBlock(
                clip       = clip,
                mediaUri   = mediaUri,
                waveform   = waveforms[clip.id],
                pxPerMs    = pxPerMs,
                trackColor = trackColor,
                isSelected = clip.id == selectedClipId,
                isAudio    = track.type == TrackType.AUDIO
            )
        }
    }
}

// ─── Clip block ───────────────────────────────────────────────────────────────

@Composable
private fun ClipBlock(
    clip: Clip,
    mediaUri: Uri?,
    waveform: FloatArray?,
    pxPerMs: Float,
    trackColor: Color,
    isSelected: Boolean,
    isAudio: Boolean
) {
    val startX = (clip.timelineStartMs * pxPerMs).dp
    val width  = (clip.durationMs * pxPerMs).dp.coerceAtLeast(4.dp)
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .offset(x = startX)
            .width(width)
            .height(TRACK_HEIGHT)
            .padding(vertical = 3.dp, horizontal = 1.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(
                Brush.verticalGradient(
                    if (isSelected)
                        listOf(trackColor.copy(alpha = 0.95f), trackColor.copy(alpha = 0.70f))
                    else
                        listOf(trackColor.copy(alpha = 0.55f), trackColor.copy(alpha = 0.35f))
                )
            )
            .then(
                if (isSelected) Modifier.border(
                    1.5.dp,
                    Brush.horizontalGradient(listOf(trackColor, Color.White.copy(alpha = 0.6f))),
                    RoundedCornerShape(4.dp)
                ) else Modifier.border(
                    0.5.dp, trackColor.copy(alpha = 0.3f), RoundedCornerShape(4.dp)
                )
            )
    ) {
        when {
            // ── Video clip: tile thumbnails across the clip width ─────────────
            !isAudio && mediaUri != null -> {
                // Request a frame at the clip's source start position.
                // Coil's VideoFrameDecoder extracts the frame via MediaMetadataRetriever.
                val request = remember(mediaUri, clip.sourceStartMs) {
                    ImageRequest.Builder(context)
                        .data(mediaUri)
                        .decoderFactory(VideoFrameDecoder.Factory())
                        // Extract the frame at the clip's source start position.
                        .videoFrameMicros(clip.sourceStartMs * 1_000L)
                        .crossfade(true)
                        .build()
                }
                AsyncImage(
                    model            = request,
                    contentDescription = null,
                    contentScale     = ContentScale.Crop,
                    modifier         = Modifier.fillMaxSize()
                )
                // Dark scrim so the label is always readable over the thumbnail.
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.35f))
                )
            }

            // ── Audio clip: real waveform peaks when available, sine placeholder
            //    while the async decode is in flight ──────────────────────────
            isAudio -> {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val barCount = (size.width / 3f).toInt().coerceAtLeast(1)
                    for (i in 0 until barCount) {
                        val x = i * 3f + 1.5f
                        val amplitude = if (waveform != null && waveform.isNotEmpty()) {
                            // Map bar index to waveform peak array
                            val peakIdx = (i.toFloat() / barCount * waveform.size)
                                .toInt().coerceIn(0, waveform.size - 1)
                            waveform[peakIdx].coerceIn(0f, 1f)
                        } else {
                            // Sine placeholder while loading
                            sin(i * 0.4).toFloat() * 0.3f + 0.5f
                        }
                        val h = amplitude * size.height * 0.80f
                        drawLine(
                            color       = Color.White.copy(alpha = if (waveform != null) 0.75f else 0.40f),
                            start       = Offset(x, size.height / 2f - h / 2f),
                            end         = Offset(x, size.height / 2f + h / 2f),
                            strokeWidth = 1.5f
                        )
                    }
                }
            }
        }

        // Clip label — always on top
        Text(
            text     = clip.mediaId.take(14),
            style    = MaterialTheme.typography.labelSmall,
            color    = Color.White.copy(alpha = 0.90f),
            maxLines = 1,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
    }
}

package app.insighteditor.native

import android.graphics.Bitmap
import android.util.Log
import androidx.annotation.Keep
import app.insighteditor.domain.model.ColorGrade

private const val TAG = "NativeEngine"

/**
 * Kotlin wrapper around the insight_engine JNI library.
 *
 * The @Keep annotation on the class and every JNI-bound member prevents R8
 * from renaming or removing them.  The C++ linker resolves JNI entry points
 * by the mangled name Java_app_insighteditor_native_NativeEngine_<methodName>;
 * any rename breaks the dynamic linkage silently at runtime.
 *
 * The companion object's loadLibrary call is guarded so that a missing .so
 * (e.g. wrong ABI, stripped by a bad build) produces a clear log message and
 * a usable fallback state rather than a hard crash in the static initializer.
 */
@Keep
class NativeEngine {

    /** True when the .so was loaded and nativeInit() returned true. */
    val isAvailable: Boolean get() = libraryLoaded && _initialized

    private var _initialized = false

    companion object {
        /** True when System.loadLibrary succeeded. */
        @Volatile
        var libraryLoaded: Boolean = false
            private set

        init {
            try {
                System.loadLibrary("insight_engine")
                libraryLoaded = true
            } catch (e: UnsatisfiedLinkError) {
                // Log the full error so it appears in crash reports.  Do NOT
                // rethrow — a missing .so must not crash the app at startup.
                // All public methods check isAvailable before calling native code.
                Log.e(TAG, "insight_engine.so failed to load — native processing disabled", e)
            }
        }
    }

    /**
     * Initialises the native engine.  Must be called before any processing
     * method.  Safe to call multiple times; subsequent calls are no-ops.
     *
     * @return true if the engine is ready, false if the .so is unavailable.
     */
    @Keep
    fun init(): Boolean {
        if (!libraryLoaded) return false
        return try {
            val ok = nativeInit()
            _initialized = ok
            ok
        } catch (e: Exception) {
            Log.e(TAG, "nativeInit threw", e)
            false
        }
    }

    @Keep
    fun release() {
        if (!libraryLoaded || !_initialized) return
        try {
            nativeRelease()
        } catch (e: Exception) {
            Log.e(TAG, "nativeRelease threw", e)
        } finally {
            _initialized = false
        }
    }

    @Keep
    fun getVersion(): String {
        if (!libraryLoaded) return "unavailable"
        return try {
            nativeGetVersion()
        } catch (e: Exception) {
            Log.e(TAG, "nativeGetVersion threw", e)
            "error"
        }
    }

    /**
     * Applies the full color grade pipeline to a Bitmap in-place.
     * The Bitmap must be ARGB_8888; a mutable copy is made if needed.
     *
     * @return true on success, false if the engine is unavailable or the
     *         Bitmap format is incompatible.
     */
    /**
     * Applies the full color grade pipeline to a Bitmap in-place.
     * The Bitmap must be ARGB_8888; a mutable copy is made if needed.
     * If a copy was made, the original is NOT recycled — the caller owns it.
     * The returned value is true on success; the modified pixels are in [bitmap]
     * (or its mutable copy, which is the same object when [bitmap.isMutable]).
     *
     * @return true on success, false if the engine is unavailable or the
     *         Bitmap format is incompatible.
     */
    @Keep
    fun applyColorGrade(bitmap: Bitmap, grade: ColorGrade): Boolean {
        if (!isAvailable) return false
        return try {
            // If the bitmap is already mutable we operate in-place.
            // If not, we create a mutable ARGB_8888 copy and operate on that.
            // The copy is NOT recycled here — the caller is responsible for
            // the lifecycle of both the original and any copy it requested.
            val target = if (bitmap.isMutable) bitmap
                         else bitmap.copy(Bitmap.Config.ARGB_8888, true)
            nativeApplyColorGrade(
                target,
                grade.temperature, grade.tint, grade.exposure, grade.contrast,
                grade.saturation, grade.pivot,
                grade.liftR, grade.liftG, grade.liftB,
                grade.gammaR, grade.gammaG, grade.gammaB,
                grade.gainR, grade.gainG, grade.gainB,
                grade.highlights, grade.shadows, grade.whites, grade.blacks,
                grade.vibrance, grade.hueShift
            )
        } catch (e: Exception) {
            Log.e(TAG, "applyColorGrade threw", e)
            false
        }
    }

    @Keep
    fun applyFilmGrain(bitmap: Bitmap, intensity: Float, seed: Long): Boolean {
        if (!isAvailable) return false
        return try {
            nativeApplyFilmGrain(bitmap, intensity, seed)
        } catch (e: Exception) {
            Log.e(TAG, "applyFilmGrain threw", e)
            false
        }
    }

    @Keep
    fun applyVignette(bitmap: Bitmap, intensity: Float, feather: Float = 0.4f): Boolean {
        if (!isAvailable) return false
        return try {
            nativeApplyVignette(bitmap, intensity, feather)
        } catch (e: Exception) {
            Log.e(TAG, "applyVignette threw", e)
            false
        }
    }

    @Keep
    fun applyChromaticAberration(bitmap: Bitmap, intensity: Float): Boolean {
        if (!isAvailable) return false
        return try {
            nativeApplyChromaticAberration(bitmap, intensity)
        } catch (e: Exception) {
            Log.e(TAG, "applyChromaticAberration threw", e)
            false
        }
    }

    @Keep
    fun applyGlow(bitmap: Bitmap, intensity: Float, radius: Float = 0.5f): Boolean {
        if (!isAvailable) return false
        return try {
            nativeApplyGlow(bitmap, intensity, radius)
        } catch (e: Exception) {
            Log.e(TAG, "applyGlow threw", e)
            false
        }
    }

    /**
     * Analyses a PCM audio buffer and returns an array of [peakCount] peak
     * values in the range [0, 1].  Returns a zeroed array if the engine is
     * unavailable so callers always receive a valid array.
     */
    @Keep
    fun analyzeWaveform(samples: ShortArray, channels: Int, peakCount: Int): FloatArray {
        if (!isAvailable) return FloatArray(peakCount)
        return try {
            nativeAnalyzeWaveform(samples, channels, peakCount) ?: FloatArray(peakCount)
        } catch (e: Exception) {
            Log.e(TAG, "analyzeWaveform threw", e)
            FloatArray(peakCount)
        }
    }

    @Keep
    fun loadLut(name: String, data: ByteArray): Boolean {
        if (!isAvailable) return false
        return try {
            nativeLoadLut(name, data)
        } catch (e: Exception) {
            Log.e(TAG, "loadLut threw", e)
            false
        }
    }

    // ─── JNI declarations ────────────────────────────────────────────────────
    // All external functions are private.  The @Keep annotation on the class
    // and the -keep rule in proguard-rules.pro together ensure R8 does not
    // rename these methods.  The private modifier is intentional — callers
    // must go through the public wrappers which perform availability checks
    // and exception handling.

    @Keep private external fun nativeInit(): Boolean
    @Keep private external fun nativeRelease()
    @Keep private external fun nativeGetVersion(): String

    @Keep private external fun nativeApplyColorGrade(
        bitmap: Bitmap,
        temperature: Float, tint: Float, exposure: Float, contrast: Float,
        saturation: Float, pivot: Float,
        liftR: Float, liftG: Float, liftB: Float,
        gammaR: Float, gammaG: Float, gammaB: Float,
        gainR: Float, gainG: Float, gainB: Float,
        highlights: Float, shadows: Float, whites: Float, blacks: Float,
        vibrance: Float, hueShift: Float
    ): Boolean

    @Keep private external fun nativeApplyFilmGrain(bitmap: Bitmap, intensity: Float, seed: Long): Boolean
    @Keep private external fun nativeApplyVignette(bitmap: Bitmap, intensity: Float, feather: Float): Boolean
    @Keep private external fun nativeApplyChromaticAberration(bitmap: Bitmap, intensity: Float): Boolean
    @Keep private external fun nativeApplyGlow(bitmap: Bitmap, intensity: Float, radius: Float): Boolean
    @Keep private external fun nativeAnalyzeWaveform(samples: ShortArray, channels: Int, peakCount: Int): FloatArray?
    @Keep private external fun nativeLoadLut(name: String, data: ByteArray): Boolean
}

package app.insighteditor.ui.panels

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.insighteditor.domain.model.AudioChannel
import app.insighteditor.ui.theme.*

@Composable
fun AudioMixerPanel(
    channels: List<AudioChannel>,
    onVolumeChange: (String, Float) -> Unit,
    onPanChange: (String, Float) -> Unit,
    onMuteToggle: (String) -> Unit,
    onSoloToggle: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val editorColors = LocalEditorColors.current

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(editorColors.surface2)
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            "Audio Mixer",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold
        )

        // Channel strips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            channels.forEach { channel ->
                ChannelStrip(
                    channel       = channel,
                    onVolume      = { onVolumeChange(channel.id, it) },
                    onPan         = { onPanChange(channel.id, it) },
                    onMute        = { onMuteToggle(channel.id) },
                    onSolo        = { onSoloToggle(channel.id) },
                    modifier      = Modifier.weight(1f)
                )
            }
        }

        HorizontalDivider(color = editorColors.divider)

        // Master output meter — driven by master channel volume
        val masterChannel = channels.find { it.id == "master" }
        val masterVol = if (masterChannel?.isMuted == true) 0f else (masterChannel?.volume ?: 1f)
        val masterLevelL by animateFloatAsState(
            targetValue = (masterVol * 0.85f).coerceIn(0f, 1f),
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
            label = "masterL"
        )
        val masterLevelR by animateFloatAsState(
            targetValue = (masterVol * 0.80f).coerceIn(0f, 1f),
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
            label = "masterR"
        )
        val masterDb = if (masterVol > 0f) 20f * kotlin.math.log10(masterVol) else -60f
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "OUTPUT",
                style = MaterialTheme.typography.labelSmall,
                color = editorColors.labelText,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.weight(1f))
            StereoMeter(levelL = masterLevelL, levelR = masterLevelR)
            Text(
                "%.1f dB".format(masterDb),
                style = MaterialTheme.typography.labelMedium,
                color = editorColors.monoText
            )
        }
    }
}

@Composable
private fun ChannelStrip(
    channel: AudioChannel,
    onVolume: (Float) -> Unit,
    onPan: (Float) -> Unit,
    onMute: () -> Unit,
    onSolo: () -> Unit,
    modifier: Modifier = Modifier
) {
    val editorColors = LocalEditorColors.current
    // Animate the level meter so it smoothly rises/falls instead of snapping
    val targetLevel = if (channel.isMuted) 0f else channel.volume * 0.8f
    val animatedLevel by animateFloatAsState(
        targetValue = targetLevel,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "level_${channel.id}"
    )

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(editorColors.surface3)
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Channel name
        Text(
            channel.name,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            maxLines = 1
        )

        // Level meter
        LevelMeter(
            level = animatedLevel,
            modifier = Modifier.height(80.dp).width(12.dp)
        )

        // dB readout
        val db = if (channel.volume > 0f) 20f * kotlin.math.log10(channel.volume) else -60f
        Text(
            "%.1f".format(db),
            style = MaterialTheme.typography.labelSmall,
            color = editorColors.monoText
        )

        // Volume fader
        Slider(
            value = channel.volume,
            onValueChange = onVolume,
            valueRange = 0f..1.5f,
            modifier = Modifier.height(80.dp),
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = editorColors.divider
            )
        )

        // Pan knob (simplified as slider)
        Text(
            "PAN",
            style = MaterialTheme.typography.labelSmall,
            color = editorColors.labelText
        )
        Slider(
            value = channel.pan,
            onValueChange = onPan,
            valueRange = -1f..1f,
            modifier = Modifier.height(24.dp),
            colors = SliderDefaults.colors(
                thumbColor = NeonOrange400,
                activeTrackColor = NeonOrange400,
                inactiveTrackColor = editorColors.divider
            )
        )

        // M / S buttons
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            MixerButton("M", channel.isMuted, MaterialTheme.colorScheme.error, onMute)
            MixerButton("S", channel.isSolo,  NeonOrange400, onSolo)
        }
    }
}

@Composable
private fun LevelMeter(level: Float, modifier: Modifier = Modifier) {
    val editorColors = LocalEditorColors.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(2.dp))
            .background(editorColors.surface2)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(level.coerceIn(0f, 1f))
                .align(Alignment.BottomCenter)
                .background(
                    when {
                        level > 0.9f -> MaterialTheme.colorScheme.error
                        level > 0.75f -> NeonOrange400
                        else -> WaveformColor
                    }
                )
        )
    }
}

@Composable
private fun StereoMeter(levelL: Float, levelR: Float) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        modifier = Modifier.height(16.dp)
    ) {
        LevelMeter(levelL, Modifier.width(8.dp).fillMaxHeight())
        LevelMeter(levelR, Modifier.width(8.dp).fillMaxHeight())
    }
}

@Composable
private fun MixerButton(label: String, active: Boolean, activeColor: Color, onClick: () -> Unit) {
    val editorColors = LocalEditorColors.current
    Box(
        modifier = Modifier
            .size(20.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(if (active) activeColor.copy(alpha = 0.3f) else editorColors.surface2)
            .border(
                width = 1.dp,
                color = if (active) activeColor else editorColors.divider,
                shape = RoundedCornerShape(3.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) activeColor else editorColors.labelText,
            fontWeight = FontWeight.Bold
        )
    }
}



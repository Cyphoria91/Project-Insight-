package app.insighteditor.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.insighteditor.domain.model.WorkspaceTab
import app.insighteditor.ui.theme.*

/**
 * Cyberpunk top bar:
 *  [←]  PROJECT NAME          [Export ▲]
 *  ─────────────────────────────────────
 *  MEDIA  ASSEMBLY  EDIT  COLOR  FX  AUDIO  DELIVER
 */
@Composable
fun CapCutTopBar(
    projectName: String,
    activeTab: WorkspaceTab,
    isExporting: Boolean,
    exportProgress: Float,
    isSaving: Boolean = false,
    lastSavedMs: Long? = null,
    onTabSelected: (WorkspaceTab) -> Unit,
    onExport: () -> Unit,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit = {}
) {
    val editorColors = LocalEditorColors.current
    val cyan = editorColors.neonCyan

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Void500, Void400)
                )
            )
    ) {
        // ── Title row ─────────────────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = editorColors.labelText,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Project name with subtle cyan left-border accent
            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(16.dp)
                        .background(
                            Brush.verticalGradient(listOf(cyan, editorColors.neonMagenta)),
                            RoundedCornerShape(1.dp)
                        )
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    projectName.uppercase(),
                    style = MaterialTheme.typography.labelLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Spacer(Modifier.width(8.dp))
                // Autosave indicator: spinner while saving, dot when saved
                when {
                    isSaving -> CircularProgressIndicator(
                        modifier = Modifier.size(10.dp),
                        color = cyan.copy(alpha = 0.7f),
                        strokeWidth = 1.5.dp
                    )
                    lastSavedMs != null -> Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(
                                color = cyan.copy(alpha = 0.6f),
                                shape = androidx.compose.foundation.shape.CircleShape
                            )
                    )
                }
            }

            // Export button / progress
            if (isExporting) {
                // Progress state — compact inline indicator
                Box(
                    modifier = Modifier
                        .width(100.dp)
                        .height(34.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Void600)
                        .border(1.dp, cyan.copy(alpha = 0.4f), RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    LinearProgressIndicator(
                        progress = { exportProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp)
                            .align(Alignment.BottomCenter),
                        color = cyan,
                        trackColor = DividerNormal
                    )
                    Text(
                        "${(exportProgress * 100).toInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        color = cyan,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                // Neon Export button with glowing cyan border
                Box(
                    modifier = Modifier
                        .height(34.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    NeonCyan800.copy(alpha = 0.8f),
                                    NeonCyan700.copy(alpha = 0.6f)
                                )
                            )
                        )
                        .drawBehind {
                            // Outer glow ring
                            drawRoundRect(
                                color = cyan.copy(alpha = 0.55f),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()),
                                style = Stroke(width = 1.5.dp.toPx())
                            )
                        }
                        .clickable(onClick = onExport)
                        .padding(horizontal = 14.dp, vertical = 0.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            Icons.Default.Upload,
                            contentDescription = null,
                            tint = cyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            "EXPORT",
                            style = MaterialTheme.typography.labelLarge,
                            color = cyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(Modifier.width(4.dp))

            // Settings icon — always visible, low-prominence
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = editorColors.labelText,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // ── Workspace tab strip ───────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp)
                .background(Void300)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            enumValues<WorkspaceTab>().forEach { tab ->
                val selected = tab == activeTab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            if (selected) cyan.copy(alpha = 0.12f)
                            else Color.Transparent
                        )
                        .then(
                            if (selected) Modifier.border(
                                width = 1.dp,
                                brush = Brush.horizontalGradient(listOf(cyan, editorColors.neonMagenta)),
                                shape = RoundedCornerShape(4.dp)
                            ) else Modifier
                        )
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        tab.name,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        color = if (selected) cyan else editorColors.labelText
                    )
                }
            }
        }

        // Neon bottom divider — thin cyan glow line
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color.Transparent,
                            cyan.copy(alpha = 0.5f),
                            editorColors.neonMagenta.copy(alpha = 0.3f),
                            Color.Transparent
                        )
                    )
                )
        )
    }
}

package app.insighteditor.data.db.converter

import androidx.room.TypeConverter
import app.insighteditor.domain.model.AppliedEffect
import app.insighteditor.domain.model.ColorGrade
import app.insighteditor.domain.model.Keyframe
import app.insighteditor.domain.model.TextOverlay
import app.insighteditor.domain.model.TrackType
import app.insighteditor.domain.model.Transition
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * Room TypeConverters for domain model types that cannot be stored as
 * primitive columns. All complex objects are round-tripped through Gson.
 *
 * Gson is used (not kotlinx.serialization) because it is already a
 * transitive dependency via the existing codebase and handles data classes
 * with default values correctly without @Serializable annotations.
 */
class Converters {

    private val gson = Gson()

    // ── TrackType ─────────────────────────────────────────────────────────────

    @TypeConverter
    fun trackTypeToString(type: TrackType): String = type.name

    @TypeConverter
    fun stringToTrackType(value: String): TrackType = TrackType.valueOf(value)

    // ── ColorGrade ────────────────────────────────────────────────────────────

    @TypeConverter
    fun colorGradeToJson(grade: ColorGrade): String = gson.toJson(grade)

    @TypeConverter
    fun jsonToColorGrade(json: String): ColorGrade =
        gson.fromJson(json, ColorGrade::class.java) ?: ColorGrade()

    // ── List<AppliedEffect> ───────────────────────────────────────────────────

    @TypeConverter
    fun effectsToJson(effects: List<AppliedEffect>): String = gson.toJson(effects)

    @TypeConverter
    fun jsonToEffects(json: String): List<AppliedEffect> {
        val type = object : TypeToken<List<AppliedEffect>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }

    // ── List<Keyframe> ────────────────────────────────────────────────────────

    @TypeConverter
    fun keyframesToJson(keyframes: List<Keyframe>): String = gson.toJson(keyframes)

    @TypeConverter
    fun jsonToKeyframes(json: String): List<Keyframe> {
        val type = object : TypeToken<List<Keyframe>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }

    // ── TextOverlay? ──────────────────────────────────────────────────────────

    @TypeConverter
    fun textOverlayToJson(overlay: TextOverlay?): String? =
        overlay?.let { gson.toJson(it) }

    @TypeConverter
    fun jsonToTextOverlay(json: String?): TextOverlay? =
        json?.let { gson.fromJson(it, TextOverlay::class.java) }

    // ── Transition? ───────────────────────────────────────────────────────────

    @TypeConverter
    fun transitionToJson(transition: Transition?): String? =
        transition?.let { gson.toJson(it) }

    @TypeConverter
    fun jsonToTransition(json: String?): Transition? =
        json?.let { gson.fromJson(it, Transition::class.java) }
}

package app.insighteditor.ui.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.insighteditor.data.lut.BUNDLED_LUTS
import app.insighteditor.data.lut.LutEntry
import app.insighteditor.ui.theme.*

/**
 * Horizontal LUT picker strip embedded in [ColorGradePanel].
 *
 * @param activeLutId  The currently applied LUT id (or "none").
 * @param onSelectLut  Called with the selected [LutEntry.id] when the user taps a tile.
 */
@Composable
fun LutPickerPanel(
    activeLutId: String,
    onSelectLut: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            "LUT",
            color = TextSecondary,
            fontSize = 11.sp,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
            items(BUNDLED_LUTS) { lut ->
                LutTile(
                    lut       = lut,
                    isActive  = lut.id == activeLutId,
                    onSelect  = { onSelectLut(lut.id) }
                )
            }
        }
    }
}

@Composable
private fun LutTile(
    lut: LutEntry,
    isActive: Boolean,
    onSelect: () -> Unit
) {
    // Colour swatch that hints at the LUT's look
    val swatchColors: List<Color> = when (lut.id) {
        "cyberpunk"     -> listOf(Color(0xFF05050F), Color(0xFF00D4FF), Color(0xFFFF00FF))
        "teal_orange"   -> listOf(Color(0xFF0A2830), Color(0xFF00897B), Color(0xFFFF6D00))
        "golden_hour"   -> listOf(Color(0xFF1A0A00), Color(0xFFFF8F00), Color(0xFFFFF9C4))
        "bleach_bypass" -> listOf(Color(0xFF0D0D0D), Color(0xFF757575), Color(0xFFEEEEEE))
        "noir"          -> listOf(Color(0xFF000000), Color(0xFF424242), Color(0xFFE0E0E0))
        else            -> listOf(Color(0xFF1A1A2E), Color(0xFF2A2A4A), Color(0xFF3A3A6A))
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(64.dp)
    ) {
        Box(
            modifier = Modifier
                .size(56.dp, 40.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(
                    androidx.compose.ui.graphics.Brush.horizontalGradient(swatchColors)
                )
                .border(
                    width = if (isActive) 2.dp else 0.5.dp,
                    color = if (isActive) NeonCyan400 else DividerSubtle,
                    shape = RoundedCornerShape(6.dp)
                )
                .clickable(onClick = onSelect),
            contentAlignment = Alignment.Center
        ) {
            if (isActive) {
                Icon(
                    Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            lut.displayName,
            color = if (isActive) NeonCyan400 else TextSecondary,
            fontSize = 9.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1
        )
    }
}

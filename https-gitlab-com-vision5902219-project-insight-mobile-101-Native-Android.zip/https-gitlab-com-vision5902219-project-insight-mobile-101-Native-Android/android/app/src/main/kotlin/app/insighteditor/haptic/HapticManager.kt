package app.insighteditor.haptic

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.content.getSystemService
import javax.inject.Inject
import javax.inject.Singleton

private const val TAG = "HapticManager"

/**
 * Centralised haptic feedback controller.
 *
 * Three intensity levels map to distinct use cases in the editor:
 *  - [HapticLevel.STRONG]  — timeline scrub start/end, destructive actions
 *  - [HapticLevel.MEDIUM]  — snap-to-clip-edge, drag confirmation
 *  - [HapticLevel.LIGHT]   — button presses, toggle switches, panel open
 *
 * Device support:
 *  - API 31+ : VibratorManager + VibrationEffect.createPredefined()
 *  - API 26–30: Vibrator + VibrationEffect.createOneShot()
 *  - API < 26 : Vibrator.vibrate(ms) legacy (minSdk is 26, so this branch
 *               is kept only as a defensive fallback)
 *
 * The [enabled] flag is toggled by the Settings screen and persisted by the
 * caller (SettingsViewModel via DataStore). All public methods are no-ops
 * when disabled or when the device has no vibrator.
 */
@Singleton
class HapticManager @Inject constructor(
    private val context: Context
) {
    // Resolved once at construction — avoids repeated getSystemService calls.
    private val vibrator: Vibrator? = resolveVibrator()

    /** Whether haptic feedback is globally enabled. Toggled from Settings. */
    @Volatile var enabled: Boolean = true

    // ── Public API ────────────────────────────────────────────────────────────

    /** Strong feedback — timeline scrub start/end, destructive actions. */
    fun scrub() = perform(HapticLevel.STRONG)

    /** Medium feedback — snap to clip edge, drag confirmation. */
    fun snap() = perform(HapticLevel.MEDIUM)

    /** Light feedback — button press, toggle, panel open. */
    fun click() = perform(HapticLevel.LIGHT)

    /** Explicit level selection for callers that need fine-grained control. */
    fun perform(level: HapticLevel) {
        if (!enabled) return
        val v = vibrator ?: return
        if (!v.hasVibrator()) return

        try {
            when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                    // API 31+: predefined effects are the most faithful to
                    // the device's haptic actuator characteristics.
                    val effectId = when (level) {
                        HapticLevel.STRONG -> VibrationEffect.EFFECT_HEAVY_CLICK
                        HapticLevel.MEDIUM -> VibrationEffect.EFFECT_CLICK
                        HapticLevel.LIGHT  -> VibrationEffect.EFFECT_TICK
                    }
                    v.vibrate(VibrationEffect.createPredefined(effectId))
                }
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O -> {
                    // API 26–30: one-shot with amplitude.
                    val (durationMs, amplitude) = when (level) {
                        HapticLevel.STRONG -> Pair(40L, 200)
                        HapticLevel.MEDIUM -> Pair(20L, 120)
                        HapticLevel.LIGHT  -> Pair(10L, 60)
                    }
                    v.vibrate(VibrationEffect.createOneShot(durationMs, amplitude))
                }
                else -> {
                    // Defensive fallback — minSdk 26 means this branch is
                    // unreachable in production but keeps the compiler happy.
                    @Suppress("DEPRECATION")
                    val durationMs = when (level) {
                        HapticLevel.STRONG -> 40L
                        HapticLevel.MEDIUM -> 20L
                        HapticLevel.LIGHT  -> 10L
                    }
                    @Suppress("DEPRECATION")
                    v.vibrate(durationMs)
                }
            }
        } catch (e: Exception) {
            // Vibration must never crash the app — some OEMs throw on
            // unsupported effect IDs even when hasVibrator() returns true.
            Log.w(TAG, "Vibration failed for level=$level", e)
        }
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private fun resolveVibrator(): Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService<VibratorManager>()?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService<Vibrator>()
        }
    } catch (e: Exception) {
        Log.w(TAG, "Could not resolve Vibrator", e)
        null
    }
}

enum class HapticLevel { STRONG, MEDIUM, LIGHT }

package app.insighteditor.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.insighteditor.R
import app.insighteditor.ui.theme.*

/**
 * Privacy consent screen shown on first launch.
 *
 * Crashlytics is always active (legitimate interest — crash data is needed
 * to maintain app stability). Analytics is opt-in only.
 *
 * The screen is shown once; the decision is persisted by [AnalyticsManager].
 */
@Composable
fun ConsentScreen(
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Void200)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Spacer(Modifier.height(16.dp))

        // Icon
        Box(
            modifier = Modifier
                .size(72.dp)
                .background(
                    Brush.radialGradient(listOf(NeonCyan400.copy(alpha = 0.2f), Void300)),
                    RoundedCornerShape(20.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Shield, contentDescription = null,
                tint = NeonCyan400, modifier = Modifier.size(40.dp))
        }

        Text(
            text = stringResource(R.string.consent_title),
            style = MaterialTheme.typography.headlineMedium,
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )

        Text(
            text = stringResource(R.string.consent_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            textAlign = TextAlign.Center
        )

        // Data collection cards
        ConsentCard(
            icon = Icons.Default.BugReport,
            title = stringResource(R.string.consent_crash_title),
            description = stringResource(R.string.consent_crash_desc),
            isRequired = true
        )

        ConsentCard(
            icon = Icons.Default.Analytics,
            title = stringResource(R.string.consent_analytics_title),
            description = stringResource(R.string.consent_analytics_desc),
            isRequired = false
        )

        Text(
            text = stringResource(R.string.consent_privacy_note),
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary.copy(alpha = 0.7f),
            textAlign = TextAlign.Center
        )

        Spacer(Modifier.weight(1f))

        // Accept button — neon cyan
        Button(
            onClick = onAccept,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan400),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = stringResource(R.string.consent_accept),
                style = MaterialTheme.typography.labelLarge,
                color = Void500,
                fontWeight = FontWeight.Bold
            )
        }

        // Decline button — ghost style
        OutlinedButton(
            onClick = onDecline,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
        ) {
            Text(
                text = stringResource(R.string.consent_decline),
                style = MaterialTheme.typography.labelLarge
            )
        }

        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ConsentCard(
    icon: ImageVector,
    title: String,
    description: String,
    isRequired: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Void300)
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(icon, contentDescription = null,
            tint = if (isRequired) NeonCyan400 else NeonMagenta300,
            modifier = Modifier.size(24.dp).padding(top = 2.dp))

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.labelLarge,
                    color = TextPrimary, fontWeight = FontWeight.SemiBold)
                if (isRequired) {
                    Surface(
                        color = NeonCyan400.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "Required",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonCyan400,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
            Text(description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
    }
}

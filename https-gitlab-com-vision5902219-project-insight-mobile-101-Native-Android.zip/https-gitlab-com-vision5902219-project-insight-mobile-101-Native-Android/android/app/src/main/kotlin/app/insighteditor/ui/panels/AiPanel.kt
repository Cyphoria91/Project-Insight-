package app.insighteditor.ui.panels

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.insighteditor.domain.model.AppliedEffect
import app.insighteditor.domain.model.EffectType
import app.insighteditor.ui.components.SectionHeader
import app.insighteditor.ui.theme.*
import java.util.UUID

private data class AiFeature(
    val type: EffectType,
    val label: String,
    val description: String,
    val icon: ImageVector,
    val accent: Color
)

private val AI_FEATURES = listOf(
    AiFeature(EffectType.AI_UPSCALE,        "Upscale 8K",          "Neural super-resolution up to 7680×4320",       Icons.Default.ZoomIn,            NeonCyan400),
    AiFeature(EffectType.AI_STABILIZE,      "Stabilize AI",        "Gyroscope + optical flow stabilization",         Icons.Default.Straighten,        NeonTeal400),
    AiFeature(EffectType.AI_ROTOSCOPE,      "Rotoscope AI",        "Automatic subject masking & background removal", Icons.Default.PersonOutline,     NeonMagenta300),
    AiFeature(EffectType.AI_SPEECH_ENHANCE, "Speech Enhance",      "Noise reduction + voice clarity boost",          Icons.Default.RecordVoiceOver,   NeonOrange300),
    AiFeature(EffectType.AI_FRAME_INTERP,   "Frame Interpolation", "Generate intermediate frames (24→60fps)",        Icons.Default.SlowMotionVideo,   NeonCyan300),
    AiFeature(EffectType.AI_DENOISE,        "Denoise",             "Temporal + spatial noise reduction",             Icons.Default.AutoFixHigh,       NeonTeal300)
)

@Composable
fun AiPanel(
    selectedClipId: String?,
    onApplyEffect: (String, AppliedEffect) -> Unit,
    modifier: Modifier = Modifier
) {
    var upscaleTarget by remember { mutableStateOf("8K") }
    var sharpen       by remember { mutableFloatStateOf(0.42f) }
    var denoise       by remember { mutableFloatStateOf(0.18f) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Void300)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(NeonMagenta500.copy(alpha = 0.2f))
                    .border(1.dp, NeonMagenta300.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Psychology,
                    contentDescription = null,
                    tint = NeonMagenta300,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column {
                Text(
                    "AI / NEURAL ENGINE",
                    style = MaterialTheme.typography.labelLarge,
                    color = NeonMagenta300,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "NNAPI · ML Kit · On-device inference",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }

        if (selectedClipId == null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Void500)
                    .border(1.dp, DividerBright, RoundedCornerShape(8.dp))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Select a clip to apply AI processing",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        // ── Neural Upscaling card ─────────────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Void500)
                .border(
                    1.dp,
                    Brush.verticalGradient(
                        listOf(NeonCyan400.copy(alpha = 0.4f), NeonCyan400.copy(alpha = 0.1f))
                    ),
                    RoundedCornerShape(12.dp)
                )
                .drawBehind {
                    drawRect(
                        brush = Brush.verticalGradient(
                            listOf(NeonCyan400.copy(alpha = 0.05f), Color.Transparent)
                        ),
                        topLeft = Offset(0f, 0f),
                        size = androidx.compose.ui.geometry.Size(size.width, 28.dp.toPx())
                    )
                }
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.ZoomIn,
                        contentDescription = null,
                        tint = NeonCyan400,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        "NEURAL UPSCALING",
                        style = MaterialTheme.typography.labelLarge,
                        color = NeonCyan400,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Resolution target chips
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("2K", "4K", "6K", "8K").forEach { res ->
                        val sel = upscaleTarget == res
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (sel) NeonCyan800.copy(alpha = 0.6f) else Void600)
                                .border(
                                    1.dp,
                                    if (sel) NeonCyan400.copy(alpha = 0.7f) else DividerNormal,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { upscaleTarget = res }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                res,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (sel) NeonCyan400 else TextSecondary,
                                fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                // Sharpen slider
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Sharpen",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        modifier = Modifier.width(56.dp)
                    )
                    Slider(
                        value = sharpen,
                        onValueChange = { sharpen = it },
                        valueRange = 0f..1f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(
                            thumbColor         = NeonCyan400,
                            activeTrackColor   = NeonCyan400,
                            inactiveTrackColor = DividerNormal
                        )
                    )
                    Text(
                        "%.2f".format(sharpen),
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan400,
                        modifier = Modifier.width(36.dp)
                    )
                }

                // Denoise slider
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Denoise",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        modifier = Modifier.width(56.dp)
                    )
                    Slider(
                        value = denoise,
                        onValueChange = { denoise = it },
                        valueRange = 0f..1f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(
                            thumbColor         = NeonTeal400,
                            activeTrackColor   = NeonTeal400,
                            inactiveTrackColor = DividerNormal
                        )
                    )
                    Text(
                        "%.2f".format(denoise),
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonTeal400,
                        modifier = Modifier.width(36.dp)
                    )
                }

                Text(
                    "Output: ${upscaleResolution(upscaleTarget)} · 60p",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )

                // Run button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (selectedClipId != null)
                                Brush.horizontalGradient(listOf(NeonCyan800, NeonCyan700.copy(alpha = 0.7f)))
                            else
                                Brush.horizontalGradient(listOf(Void600, Void600))
                        )
                        .border(
                            1.dp,
                            if (selectedClipId != null) NeonCyan400.copy(alpha = 0.6f) else DividerSubtle,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable(enabled = selectedClipId != null) {
                            selectedClipId?.let { clipId ->
                                onApplyEffect(
                                    clipId,
                                    AppliedEffect(
                                        id        = UUID.randomUUID().toString(),
                                        type      = EffectType.AI_UPSCALE,
                                        intensity = sharpen,
                                        params    = mapOf("denoise" to denoise)
                                    )
                                )
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.ZoomIn,
                            contentDescription = null,
                            tint = if (selectedClipId != null) NeonCyan400 else TextTertiary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            "RUN UPSCALE ON SELECTION",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (selectedClipId != null) NeonCyan400 else TextTertiary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Divider
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, NeonMagenta300.copy(alpha = 0.3f), Color.Transparent)
                    )
                )
        )

        SectionHeader("AI Tools")

        // Other AI feature rows
        AI_FEATURES.drop(1).forEach { feature ->
            AiFeatureRow(
                feature = feature,
                enabled = selectedClipId != null,
                onClick = {
                    selectedClipId?.let { clipId ->
                        onApplyEffect(
                            clipId,
                            AppliedEffect(
                                id        = UUID.randomUUID().toString(),
                                type      = feature.type,
                                intensity = 1f
                            )
                        )
                    }
                }
            )
        }
    }
}

@Composable
private fun AiFeatureRow(feature: AiFeature, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Void500)
            .border(
                1.dp,
                Brush.horizontalGradient(
                    listOf(feature.accent.copy(alpha = 0.25f), DividerSubtle)
                ),
                RoundedCornerShape(10.dp)
            )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(feature.accent.copy(alpha = 0.12f))
                    .border(1.dp, feature.accent.copy(alpha = 0.35f), RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    feature.icon,
                    contentDescription = null,
                    tint = feature.accent,
                    modifier = Modifier.size(18.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    feature.label,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    feature.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (enabled) feature.accent.copy(alpha = 0.12f) else Void600
                    )
                    .border(
                        1.dp,
                        if (enabled) feature.accent.copy(alpha = 0.5f) else DividerSubtle,
                        RoundedCornerShape(6.dp)
                    )
                    .clickable(enabled = enabled, onClick = onClick)
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(
                    "APPLY",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (enabled) feature.accent else TextTertiary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun upscaleResolution(target: String) = when (target) {
    "2K" -> "2560×1440"
    "4K" -> "3840×2160"
    "6K" -> "6144×3456"
    "8K" -> "7680×4320"
    else -> "3840×2160"
}

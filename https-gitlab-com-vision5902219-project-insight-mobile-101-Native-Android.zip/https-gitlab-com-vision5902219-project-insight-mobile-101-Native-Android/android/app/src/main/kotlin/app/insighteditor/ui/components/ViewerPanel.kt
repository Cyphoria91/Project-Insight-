package app.insighteditor.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.insighteditor.domain.usecase.TimelineUseCases
import app.insighteditor.ui.theme.*

@Composable
fun ViewerPanel(
    playheadMs: Long,
    durationMs: Long,
    isPlaying: Boolean,
    projectName: String,
    onPlay: () -> Unit,
    onSeek: (Long) -> Unit,
    onStepBack: () -> Unit,
    onStepFwd: () -> Unit,
    onGoStart: () -> Unit,
    onGoEnd: () -> Unit,
    modifier: Modifier = Modifier
) {
    val editorColors = LocalEditorColors.current
    val cyan = editorColors.neonCyan
    val magenta = editorColors.neonMagenta

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Void300)
    ) {
        // ── View mode tab strip ───────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(30.dp)
                .background(Void200)
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("PROGRAM", "SOURCE", "EFFECT").forEachIndexed { i, label ->
                Text(
                    label,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (i == 0) cyan else editorColors.labelText,
                    fontWeight = if (i == 0) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                if (i == 0) {
                    // Active indicator dot
                    Box(
                        modifier = Modifier
                            .size(3.dp)
                            .clip(CircleShape)
                            .background(cyan)
                    )
                }
            }
            Spacer(Modifier.weight(1f))
            // Resolution badge — neon bordered
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(NeonCyan800.copy(alpha = 0.5f))
                    .border(1.dp, cyan.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    "4K UHD",
                    style = MaterialTheme.typography.labelSmall,
                    color = cyan,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // ── Preview canvas ────────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Void100),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(Color(0xFF020208))
                    // Subtle neon border around the preview frame
                    .border(
                        width = 1.dp,
                        brush = Brush.linearGradient(
                            listOf(
                                cyan.copy(alpha = 0.25f),
                                magenta.copy(alpha = 0.15f),
                                cyan.copy(alpha = 0.25f)
                            )
                        ),
                        shape = RoundedCornerShape(0.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Safe-area guides
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val sw = 1f
                    val inset5   = size.width  * 0.05f
                    val inset10  = size.width  * 0.10f
                    val vInset5  = size.height * 0.05f
                    val vInset10 = size.height * 0.10f
                    // Outer safe area — cyan tint
                    drawRect(
                        color   = NeonCyan400.copy(alpha = 0.10f),
                        topLeft = Offset(inset5, vInset5),
                        size    = Size(size.width - inset5 * 2, size.height - vInset5 * 2),
                        style   = Stroke(sw)
                    )
                    // Inner safe area — magenta tint
                    drawRect(
                        color   = NeonMagenta300.copy(alpha = 0.06f),
                        topLeft = Offset(inset10, vInset10),
                        size    = Size(size.width - inset10 * 2, size.height - vInset10 * 2),
                        style   = Stroke(sw)
                    )
                    // Corner accent marks — top-left
                    val markLen = size.width * 0.04f
                    val markColor = NeonCyan400.copy(alpha = 0.35f)
                    drawLine(markColor, Offset(inset5, vInset5), Offset(inset5 + markLen, vInset5), 1.5f)
                    drawLine(markColor, Offset(inset5, vInset5), Offset(inset5, vInset5 + markLen), 1.5f)
                    // top-right
                    drawLine(markColor, Offset(size.width - inset5, vInset5), Offset(size.width - inset5 - markLen, vInset5), 1.5f)
                    drawLine(markColor, Offset(size.width - inset5, vInset5), Offset(size.width - inset5, vInset5 + markLen), 1.5f)
                    // bottom-left
                    drawLine(markColor, Offset(inset5, size.height - vInset5), Offset(inset5 + markLen, size.height - vInset5), 1.5f)
                    drawLine(markColor, Offset(inset5, size.height - vInset5), Offset(inset5, size.height - vInset5 - markLen), 1.5f)
                    // bottom-right
                    drawLine(markColor, Offset(size.width - inset5, size.height - vInset5), Offset(size.width - inset5 - markLen, size.height - vInset5), 1.5f)
                    drawLine(markColor, Offset(size.width - inset5, size.height - vInset5), Offset(size.width - inset5, size.height - vInset5 - markLen), 1.5f)
                }

                // OSD overlays
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // REC indicator
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isPlaying) ErrorRed
                                        else ErrorRed.copy(alpha = 0.35f)
                                    )
                                    .drawBehind {
                                        if (isPlaying) {
                                            drawCircle(
                                                color = ErrorRed.copy(alpha = 0.4f),
                                                radius = size.minDimension * 1.2f
                                            )
                                        }
                                    }
                            )
                            Text(
                                "REC",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isPlaying) ErrorRed else Color.White.copy(alpha = 0.4f),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            projectName.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.30f),
                            maxLines = 1
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    // Timecode — monospace, neon cyan
                    Text(
                        TimelineUseCases.formatTimecode(playheadMs, 23.976f),
                        style = MaterialTheme.typography.labelLarge,
                        color = cyan.copy(alpha = 0.90f),
                        fontWeight = FontWeight.Bold
                    )
                }

                // Audio meters — right edge
                Row(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxHeight()
                        .padding(end = 5.dp, top = 8.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    AudioMeter(level = if (isPlaying) 0.70f else 0f)
                    AudioMeter(level = if (isPlaying) 0.65f else 0f)
                }
            }
        }

        // ── Transport controls ────────────────────────────────────────────────
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(listOf(Void400, Void500))
                )
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            val progress = if (durationMs > 0) playheadMs.toFloat() / durationMs else 0f

            // Scrub slider — neon cyan thumb + track
            Slider(
                value = progress,
                onValueChange = { onSeek((it * durationMs).toLong()) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp),
                colors = SliderDefaults.colors(
                    thumbColor         = cyan,
                    activeTrackColor   = cyan,
                    inactiveTrackColor = DividerNormal
                )
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    TimelineUseCases.msToTimecodeDisplay(playheadMs),
                    style = MaterialTheme.typography.labelMedium,
                    color = cyan
                )
                Text(
                    TimelineUseCases.msToTimecodeDisplay(durationMs),
                    style = MaterialTheme.typography.labelMedium,
                    color = editorColors.labelText
                )
            }

            // Transport buttons row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TransportBtn(Icons.Default.SkipPrevious, onGoStart, editorColors.labelText)
                TransportBtn(Icons.Default.FastRewind,   onStepBack, editorColors.labelText)

                // Play/Pause — glowing neon button
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .drawBehind {
                            // Outer glow ring
                            drawCircle(
                                color = cyan.copy(alpha = if (isPlaying) 0.30f else 0.15f),
                                radius = size.minDimension / 2f + 6.dp.toPx()
                            )
                        }
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(NeonCyan700, NeonCyan800)
                            )
                        )
                        .border(1.5.dp, cyan.copy(alpha = 0.8f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    FilledIconButton(
                        onClick = onPlay,
                        modifier = Modifier.size(50.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = Color.Transparent
                        )
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            modifier = Modifier.size(26.dp),
                            tint = cyan
                        )
                    }
                }

                TransportBtn(Icons.Default.FastForward, onStepFwd, editorColors.labelText)
                TransportBtn(Icons.Default.SkipNext,    onGoEnd,   editorColors.labelText)
            }
        }
    }
}

@Composable
private fun TransportBtn(
    icon: ImageVector,
    onClick: () -> Unit,
    tint: Color
) {
    IconButton(onClick = onClick, modifier = Modifier.size(40.dp)) {
        Icon(
            icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(22.dp)
        )
    }
}

@Composable
private fun AudioMeter(level: Float) {
    Box(
        modifier = Modifier
            .width(5.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(2.dp))
            .background(Void600)
    ) {
        val meterColor = when {
            level > 0.85f -> ErrorRed
            level > 0.70f -> NeonOrange400
            else          -> NeonTeal400
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(level.coerceIn(0f, 1f))
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        listOf(meterColor, meterColor.copy(alpha = 0.6f))
                    )
                )
        )
    }
}

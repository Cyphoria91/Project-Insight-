package app.insighteditor.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// Cyberpunk neon color scheme — deep space black + electric cyan primary
private val EditorDarkColorScheme = darkColorScheme(
    primary             = NeonCyan400,
    onPrimary           = Void200,
    primaryContainer    = NeonCyan800,
    onPrimaryContainer  = NeonCyan200,

    secondary           = NeonMagenta300,
    onSecondary         = Void200,
    secondaryContainer  = NeonPurple500,
    onSecondaryContainer = NeonMagenta200,

    tertiary            = NeonOrange400,
    onTertiary          = Void200,
    tertiaryContainer   = Color(0xFF3A1800),
    onTertiaryContainer = NeonOrange200,

    background          = Void200,
    onBackground        = TextPrimary,

    surface             = Void300,
    onSurface           = TextPrimary,
    surfaceVariant      = Void500,
    onSurfaceVariant    = TextSecondary,

    outline             = DividerNormal,
    outlineVariant      = DividerSubtle,

    error               = ErrorRed,
    onError             = Void200,
    errorContainer      = Color(0xFF3A0010),
    onErrorContainer    = Color(0xFFFFB3C1),

    inverseSurface      = TextPrimary,
    inverseOnSurface    = Void300,
    inversePrimary      = NeonCyan700,

    scrim               = Color(0xE6000000)
)

// Editor-specific tokens not covered by Material 3
data class EditorColors(
    val videoTrack: Color  = VideoTrackColor,
    val audioTrack: Color  = AudioTrackColor,
    val fxTrack: Color     = FxTrackColor,
    val selectedClip: Color = SelectedClip,
    val playhead: Color    = PlayheadColor,
    val waveform: Color    = WaveformColor,
    val lift: Color        = LiftColor,
    val gamma: Color       = GammaColor,
    val gain: Color        = GainColor,
    // Surface layers — progressively lighter void tones
    val surface2: Color    = Void400,
    val surface3: Color    = Void500,
    val surface4: Color    = Void600,
    val divider: Color     = DividerNormal,
    val dividerSubtle: Color = DividerSubtle,
    val labelText: Color   = TextSecondary,
    val monoText: Color    = TextPrimary,
    // Neon glow tints for decorative borders/shadows
    val glowCyan: Color    = GlowCyan,
    val glowMagenta: Color = GlowMagenta,
    val glowOrange: Color  = GlowOrange,
    val glowTeal: Color    = GlowTeal,
    // Accent shorthands
    val neonCyan: Color    = NeonCyan400,
    val neonMagenta: Color = NeonMagenta300,
    val neonOrange: Color  = NeonOrange400,
    val neonTeal: Color    = NeonTeal400
)

val LocalEditorColors = staticCompositionLocalOf { EditorColors() }

@Composable
fun InsightEditorTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalEditorColors provides EditorColors()) {
        MaterialTheme(
            colorScheme = EditorDarkColorScheme,
            typography  = EditorTypography,
            content     = content
        )
    }
}

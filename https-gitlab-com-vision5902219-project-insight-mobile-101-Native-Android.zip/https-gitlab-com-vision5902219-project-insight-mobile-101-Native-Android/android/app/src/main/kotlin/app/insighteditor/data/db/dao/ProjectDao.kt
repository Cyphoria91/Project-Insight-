package app.insighteditor.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import app.insighteditor.data.db.entity.ProjectEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {

    /** Reactive list of all projects, ordered newest-modified first. */
    @Query("SELECT * FROM projects ORDER BY modified_at DESC")
    fun observeAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getById(id: String): ProjectEntity?

    /** Returns the most recently modified project, or null if none exist. */
    @Query("SELECT * FROM projects ORDER BY modified_at DESC LIMIT 1")
    suspend fun getMostRecent(): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(project: ProjectEntity)

    @Update
    suspend fun update(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("UPDATE projects SET modified_at = :timestamp WHERE id = :id")
    suspend fun touchModifiedAt(id: String, timestamp: Long)
}

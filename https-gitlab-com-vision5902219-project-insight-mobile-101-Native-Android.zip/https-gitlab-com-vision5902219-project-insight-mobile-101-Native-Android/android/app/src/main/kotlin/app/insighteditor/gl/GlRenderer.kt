package app.insighteditor.gl

import android.content.Context
import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLUtils
import android.util.Log
import app.insighteditor.domain.model.ColorGrade
import app.insighteditor.domain.model.EffectType
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

private const val TAG = "GlRenderer"

/**
 * OpenGL ES 2.0 renderer for the preview viewer.
 * Applies color grade + effects as a shader pipeline on the GPU.
 *
 * All GL calls must be made on the thread that owns the EGL context.
 * init() must be called before any render method.
 * release() must be called when the surface is destroyed.
 */
class GlRenderer(private val context: Context) {

    private var colorGradeProgram  = 0
    private var filmGrainProgram   = 0
    private var vignetteProgram    = 0
    private var chromaProgram      = 0
    private var glowProgram        = 0
    private var halationProgram    = 0
    private var flareProgram       = 0
    private var lutProgram         = 0
    // Transition programs — each takes uTexA (outgoing), uTexB (incoming), uProgress 0..1
    private var dissolveProgram    = 0
    private var dipBlackProgram    = 0
    private var wipeProgram        = 0
    private var glitchCutProgram   = 0

    private var frameTexture = 0
    private var lutTexture   = 0

    /** True after init() completes without GL errors. */
    var isReady: Boolean = false
        private set

    private val quadVerts: FloatBuffer = ByteBuffer
        .allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
            position(0)
        }
    private val quadUvs: FloatBuffer = ByteBuffer
        .allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(floatArrayOf(0f, 1f, 1f, 1f, 0f, 0f, 1f, 0f))
            position(0)
        }

    /**
     * Compiles all shader programs.  Must be called on the GL thread after the
     * EGL context is current.  If any shader fails to compile or link, that
     * program is set to 0 and the corresponding render call becomes a no-op
     * rather than crashing.
     */
    fun init() {
        isReady = false
        val vertSrc = loadAsset("shaders/color_grade.vert") ?: run {
            Log.e(TAG, "Failed to load vertex shader — GL renderer disabled")
            return
        }

        colorGradeProgram = buildProgram(vertSrc, loadAsset("shaders/color_grade.frag"))
        filmGrainProgram  = buildProgram(vertSrc, loadAsset("shaders/film_grain.frag"))
        vignetteProgram   = buildProgram(vertSrc, loadAsset("shaders/vignette.frag"))
        chromaProgram     = buildProgram(vertSrc, loadAsset("shaders/chromatic_aberration.frag"))
        glowProgram       = buildProgram(vertSrc, loadAsset("shaders/glow.frag"))
        halationProgram   = buildProgram(vertSrc, loadAsset("shaders/halation.frag"))
        flareProgram      = buildProgram(vertSrc, loadAsset("shaders/anamorphic_flare.frag"))
        lutProgram        = buildProgram(vertSrc, loadAsset("shaders/lut.frag"))
        // Transition shaders — use inline GLSL so they work without asset files
        dissolveProgram  = buildProgram(vertSrc, DISSOLVE_FRAG)
        dipBlackProgram  = buildProgram(vertSrc, DIP_BLACK_FRAG)
        wipeProgram      = buildProgram(vertSrc, WIPE_FRAG)
        glitchCutProgram = buildProgram(vertSrc, GLITCH_CUT_FRAG)

        // isReady is true even if some optional programs failed — the core
        // color grade program is the only hard requirement.
        isReady = colorGradeProgram != 0
        if (!isReady) {
            Log.e(TAG, "Core color grade program failed to link — GL renderer disabled")
        }
    }

    fun uploadFrame(bitmap: Bitmap) {
        if (!isReady) return
        if (frameTexture == 0) {
            val tex = IntArray(1)
            GLES20.glGenTextures(1, tex, 0)
            frameTexture = tex[0]
        }
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, frameTexture)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        checkGlError("uploadFrame")
    }

    fun uploadLut(bitmap: Bitmap) {
        if (!isReady) return
        if (lutTexture == 0) {
            val tex = IntArray(1)
            GLES20.glGenTextures(1, tex, 0)
            lutTexture = tex[0]
        }
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, lutTexture)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        checkGlError("uploadLut")
    }

    fun renderColorGrade(grade: ColorGrade, width: Int, height: Int) {
        if (!isReady || colorGradeProgram == 0 || frameTexture == 0) return
        GLES20.glUseProgram(colorGradeProgram)
        bindQuad(colorGradeProgram)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, frameTexture)
        setUniform1i(colorGradeProgram, "uTexture",     0)
        setUniform1f(colorGradeProgram, "uTemperature", grade.temperature)
        setUniform1f(colorGradeProgram, "uTint",        grade.tint)
        setUniform1f(colorGradeProgram, "uExposure",    grade.exposure)
        setUniform1f(colorGradeProgram, "uContrast",    grade.contrast)
        setUniform1f(colorGradeProgram, "uSaturation",  grade.saturation)
        setUniform1f(colorGradeProgram, "uPivot",       grade.pivot)
        setUniform1f(colorGradeProgram, "uHighlights",  grade.highlights)
        setUniform1f(colorGradeProgram, "uShadows",     grade.shadows)
        setUniform1f(colorGradeProgram, "uVibrance",    grade.vibrance)
        setUniform1f(colorGradeProgram, "uHueShift",    grade.hueShift)
        setUniform1f(colorGradeProgram, "uLiftR",       grade.liftR)
        setUniform1f(colorGradeProgram, "uLiftG",       grade.liftG)
        setUniform1f(colorGradeProgram, "uLiftB",       grade.liftB)
        setUniform1f(colorGradeProgram, "uGammaR",      grade.gammaR)
        setUniform1f(colorGradeProgram, "uGammaG",      grade.gammaG)
        setUniform1f(colorGradeProgram, "uGammaB",      grade.gammaB)
        setUniform1f(colorGradeProgram, "uGainR",       grade.gainR)
        setUniform1f(colorGradeProgram, "uGainG",       grade.gainG)
        setUniform1f(colorGradeProgram, "uGainB",       grade.gainB)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        unbindQuad(colorGradeProgram)
        checkGlError("renderColorGrade")
    }

    fun renderEffect(type: EffectType, intensity: Float, time: Float, width: Int, height: Int) {
        if (!isReady || frameTexture == 0) return
        val prog = when (type) {
            EffectType.FILM_GRAIN           -> filmGrainProgram
            EffectType.VIGNETTE             -> vignetteProgram
            EffectType.CHROMATIC_ABERRATION -> chromaProgram
            EffectType.GLOW                 -> glowProgram
            EffectType.HALATION             -> halationProgram
            EffectType.ANAMORPHIC_FLARE     -> flareProgram
            else -> return
        }
        if (prog == 0) {
            Log.w(TAG, "Shader program for $type is 0 — skipping effect")
            return
        }
        GLES20.glUseProgram(prog)
        bindQuad(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, frameTexture)
        setUniform1i(prog, "uTexture",   0)
        setUniform1f(prog, "uIntensity", intensity)
        if (type == EffectType.FILM_GRAIN) setUniform1f(prog, "uTime", time)
        if (type == EffectType.GLOW || type == EffectType.HALATION ||
            type == EffectType.ANAMORPHIC_FLARE) {
            setUniform2f(prog, "uTexelSize", 1f / width, 1f / height)
        }
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        unbindQuad(prog)
        checkGlError("renderEffect($type)")
    }

    /**
     * Renders a transition between two frames.
     *
     * [texA] is the outgoing frame texture (already uploaded via [uploadFrame]).
     * [texB] is the incoming frame texture — caller must have uploaded it to
     * texture unit 1 before calling this.
     * [progress] is 0.0 (full outgoing) → 1.0 (full incoming).
     */
    fun renderTransition(
        type: EffectType,
        texA: Int,
        texB: Int,
        progress: Float,
        width: Int,
        height: Int
    ) {
        if (!isReady) return
        val prog = when (type) {
            EffectType.CROSS_DISSOLVE -> dissolveProgram
            EffectType.DIP_TO_BLACK   -> dipBlackProgram
            EffectType.WHIP_PAN       -> wipeProgram   // wipe approximates whip pan
            EffectType.GLITCH_CUT     -> glitchCutProgram
            else                      -> dissolveProgram // fallback
        }
        if (prog == 0) return
        GLES20.glUseProgram(prog)
        bindQuad(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texA)
        setUniform1i(prog, "uTexA", 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texB)
        setUniform1i(prog, "uTexB", 1)
        setUniform1f(prog, "uProgress", progress.coerceIn(0f, 1f))
        setUniform2f(prog, "uTexelSize", 1f / width, 1f / height)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        unbindQuad(prog)
        checkGlError("renderTransition($type)")
    }

    fun release() {
        isReady = false
        val programs = intArrayOf(
            colorGradeProgram, filmGrainProgram, vignetteProgram,
            chromaProgram, glowProgram, halationProgram, flareProgram, lutProgram,
            dissolveProgram, dipBlackProgram, wipeProgram, glitchCutProgram
        )
        programs.filter { it != 0 }.forEach { GLES20.glDeleteProgram(it) }
        colorGradeProgram = 0; filmGrainProgram = 0; vignetteProgram = 0
        chromaProgram = 0; glowProgram = 0; halationProgram = 0
        flareProgram = 0; lutProgram = 0
        dissolveProgram = 0; dipBlackProgram = 0; wipeProgram = 0; glitchCutProgram = 0

        if (frameTexture != 0) {
            GLES20.glDeleteTextures(1, intArrayOf(frameTexture), 0)
            frameTexture = 0
        }
        if (lutTexture != 0) {
            GLES20.glDeleteTextures(1, intArrayOf(lutTexture), 0)
            lutTexture = 0
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private fun bindQuad(program: Int) {
        val posLoc = GLES20.glGetAttribLocation(program, "aPosition")
        val uvLoc  = GLES20.glGetAttribLocation(program, "aTexCoord")
        if (posLoc >= 0) {
            GLES20.glEnableVertexAttribArray(posLoc)
            GLES20.glVertexAttribPointer(posLoc, 2, GLES20.GL_FLOAT, false, 0, quadVerts)
        }
        if (uvLoc >= 0) {
            GLES20.glEnableVertexAttribArray(uvLoc)
            GLES20.glVertexAttribPointer(uvLoc, 2, GLES20.GL_FLOAT, false, 0, quadUvs)
        }
    }

    /** Disables vertex attribute arrays enabled by [bindQuad]. Call after glDrawArrays. */
    private fun unbindQuad(program: Int) {
        val posLoc = GLES20.glGetAttribLocation(program, "aPosition")
        val uvLoc  = GLES20.glGetAttribLocation(program, "aTexCoord")
        if (posLoc >= 0) GLES20.glDisableVertexAttribArray(posLoc)
        if (uvLoc  >= 0) GLES20.glDisableVertexAttribArray(uvLoc)
    }

    private fun setUniform1f(prog: Int, name: String, v: Float) {
        val loc = GLES20.glGetUniformLocation(prog, name)
        if (loc >= 0) GLES20.glUniform1f(loc, v)
    }

    private fun setUniform1i(prog: Int, name: String, v: Int) {
        val loc = GLES20.glGetUniformLocation(prog, name)
        if (loc >= 0) GLES20.glUniform1i(loc, v)
    }

    private fun setUniform2f(prog: Int, name: String, x: Float, y: Float) {
        val loc = GLES20.glGetUniformLocation(prog, name)
        if (loc >= 0) GLES20.glUniform2f(loc, x, y)
    }

    /**
     * Compiles and links a GLSL program.  Returns 0 on any error so callers
     * can check for 0 and skip the draw call rather than crashing.
     */
    private fun buildProgram(vertSrc: String, fragSrc: String?): Int {
        if (fragSrc == null) return 0
        val vert = compileShader(GLES20.GL_VERTEX_SHADER, vertSrc)
        if (vert == 0) return 0
        val frag = compileShader(GLES20.GL_FRAGMENT_SHADER, fragSrc)
        if (frag == 0) {
            GLES20.glDeleteShader(vert)
            return 0
        }
        val prog = GLES20.glCreateProgram()
        if (prog == 0) {
            GLES20.glDeleteShader(vert)
            GLES20.glDeleteShader(frag)
            return 0
        }
        GLES20.glAttachShader(prog, vert)
        GLES20.glAttachShader(prog, frag)
        GLES20.glLinkProgram(prog)
        GLES20.glDeleteShader(vert)
        GLES20.glDeleteShader(frag)

        val linkStatus = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, linkStatus, 0)
        if (linkStatus[0] == GLES20.GL_FALSE) {
            Log.e(TAG, "Program link failed: ${GLES20.glGetProgramInfoLog(prog)}")
            GLES20.glDeleteProgram(prog)
            return 0
        }
        return prog
    }

    /**
     * Compiles a single shader stage.  Returns 0 on compile error so the
     * caller can clean up and return 0 for the whole program.
     */
    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES20.glCreateShader(type)
        if (shader == 0) return 0
        GLES20.glShaderSource(shader, src)
        GLES20.glCompileShader(shader)

        val compileStatus = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compileStatus, 0)
        if (compileStatus[0] == GLES20.GL_FALSE) {
            val typeName = if (type == GLES20.GL_VERTEX_SHADER) "vertex" else "fragment"
            Log.e(TAG, "$typeName shader compile failed: ${GLES20.glGetShaderInfoLog(shader)}")
            GLES20.glDeleteShader(shader)
            return 0
        }
        return shader
    }

    /**
     * Reads a text asset.  Returns null (not throws) if the asset is missing
     * so callers can degrade gracefully.
     */
    private fun loadAsset(path: String): String? {
        return try {
            context.assets.open(path).bufferedReader().readText()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load asset: $path", e)
            null
        }
    }

    /**
     * Checks for a pending GL error and logs it.  Does not throw — a GL error
     * in a render pass should not crash the app.
     */
    private fun checkGlError(op: String) {
        val error = GLES20.glGetError()
        if (error != GLES20.GL_NO_ERROR) {
            Log.e(TAG, "$op: GL error 0x${error.toString(16)}")
        }
    }

    // ─── Inline transition GLSL shaders ──────────────────────────────────────
    // All transition shaders share the same uniforms:
    //   uTexA      — outgoing frame (sampler2D, unit 0)
    //   uTexB      — incoming frame (sampler2D, unit 1)
    //   uProgress  — 0.0 (full A) → 1.0 (full B)
    //   uTexelSize — vec2(1/width, 1/height) for pixel-space effects

    companion object {

        private val DISSOLVE_FRAG = """
            precision mediump float;
            varying vec2 vTexCoord;
            uniform sampler2D uTexA;
            uniform sampler2D uTexB;
            uniform float uProgress;
            void main() {
                vec4 a = texture2D(uTexA, vTexCoord);
                vec4 b = texture2D(uTexB, vTexCoord);
                gl_FragColor = mix(a, b, uProgress);
            }
        """.trimIndent()

        private val DIP_BLACK_FRAG = """
            precision mediump float;
            varying vec2 vTexCoord;
            uniform sampler2D uTexA;
            uniform sampler2D uTexB;
            uniform float uProgress;
            void main() {
                // First half: fade A to black; second half: fade black to B.
                float half = 0.5;
                vec4 a = texture2D(uTexA, vTexCoord);
                vec4 b = texture2D(uTexB, vTexCoord);
                if (uProgress < half) {
                    float t = uProgress / half;
                    gl_FragColor = mix(a, vec4(0.0, 0.0, 0.0, 1.0), t);
                } else {
                    float t = (uProgress - half) / half;
                    gl_FragColor = mix(vec4(0.0, 0.0, 0.0, 1.0), b, t);
                }
            }
        """.trimIndent()

        private val WIPE_FRAG = """
            precision mediump float;
            varying vec2 vTexCoord;
            uniform sampler2D uTexA;
            uniform sampler2D uTexB;
            uniform float uProgress;
            void main() {
                // Left-to-right wipe with a soft 2% edge.
                float edge = 0.02;
                float mask = smoothstep(uProgress - edge, uProgress + edge, vTexCoord.x);
                vec4 a = texture2D(uTexA, vTexCoord);
                vec4 b = texture2D(uTexB, vTexCoord);
                gl_FragColor = mix(a, b, mask);
            }
        """.trimIndent()

        private val GLITCH_CUT_FRAG = """
            precision mediump float;
            varying vec2 vTexCoord;
            uniform sampler2D uTexA;
            uniform sampler2D uTexB;
            uniform float uProgress;
            uniform vec2 uTexelSize;
            void main() {
                // Horizontal RGB-split glitch that intensifies toward the cut point.
                float peak = 1.0 - abs(uProgress - 0.5) * 2.0;
                float shift = peak * 0.03;
                vec2 uvR = vTexCoord + vec2( shift, 0.0);
                vec2 uvB = vTexCoord + vec2(-shift, 0.0);
                vec4 a;
                a.r = texture2D(uTexA, uvR).r;
                a.g = texture2D(uTexA, vTexCoord).g;
                a.b = texture2D(uTexA, uvB).b;
                a.a = 1.0;
                vec4 b = texture2D(uTexB, vTexCoord);
                gl_FragColor = mix(a, b, uProgress);
            }
        """.trimIndent()
    }
}

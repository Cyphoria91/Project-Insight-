package app.insighteditor.di

import android.content.Context
import app.insighteditor.analytics.AnalyticsManager
import app.insighteditor.analytics.CrashReporter
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AnalyticsModule {

    @Provides
    @Singleton
    fun provideFirebaseAnalytics(@ApplicationContext context: Context): FirebaseAnalytics =
        FirebaseAnalytics.getInstance(context).also {
            // Collection is disabled at the application level until the user
            // explicitly opts in. AnalyticsManager.enableCollection() flips this.
            it.setAnalyticsCollectionEnabled(false)
        }

    @Provides
    @Singleton
    fun provideFirebaseCrashlytics(): FirebaseCrashlytics =
        FirebaseCrashlytics.getInstance()

    @Provides
    @Singleton
    fun provideAnalyticsManager(
        firebaseAnalytics: FirebaseAnalytics,
        @ApplicationContext context: Context
    ): AnalyticsManager = AnalyticsManager(firebaseAnalytics, context)

    @Provides
    @Singleton
    fun provideCrashReporter(
        crashlytics: FirebaseCrashlytics
    ): CrashReporter = CrashReporter(crashlytics)
}

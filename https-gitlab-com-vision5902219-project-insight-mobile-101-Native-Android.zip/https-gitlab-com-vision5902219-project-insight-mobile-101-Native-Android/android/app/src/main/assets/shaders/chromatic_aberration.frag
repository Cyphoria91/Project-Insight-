precision mediump float;
uniform sampler2D uTexture;
uniform float uIntensity;
varying vec2 vTexCoord;

void main() {
    vec2 offset = (vTexCoord - 0.5) * uIntensity * 0.02;
    float r = texture2D(uTexture, vTexCoord + offset).r;
    float g = texture2D(uTexture, vTexCoord).g;
    float b = texture2D(uTexture, vTexCoord - offset).b;
    float a = texture2D(uTexture, vTexCoord).a;
    gl_FragColor = vec4(r, g, b, a);
}

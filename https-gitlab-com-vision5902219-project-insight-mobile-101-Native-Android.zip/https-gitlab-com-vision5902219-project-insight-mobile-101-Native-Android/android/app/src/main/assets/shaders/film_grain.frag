precision mediump float;
uniform sampler2D uTexture;
uniform float uIntensity;
uniform float uTime;
varying vec2 vTexCoord;

float rand(vec2 co) {
    return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    float noise = rand(vTexCoord + vec2(uTime, uTime * 0.7)) * 2.0 - 1.0;
    float grain = noise * uIntensity * 0.12;
    color.rgb = clamp(color.rgb + grain, 0.0, 1.0);
    gl_FragColor = color;
}

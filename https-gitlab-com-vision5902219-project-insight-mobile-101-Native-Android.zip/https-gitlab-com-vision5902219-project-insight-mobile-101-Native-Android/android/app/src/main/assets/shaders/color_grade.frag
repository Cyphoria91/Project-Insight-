// Full color grade pipeline — runs on GPU via OpenGL ES 2.0
precision mediump float;

uniform sampler2D uTexture;
uniform sampler2D uLut;       // 3D LUT packed as 2D strip (512x512 for 8x8x8 slices)
uniform int       uUseLut;
uniform float     uLutIntensity;

uniform float uTemperature;   // -100..100
uniform float uTint;          // -100..100
uniform float uExposure;      // -5..5 EV
uniform float uContrast;      // -100..100
uniform float uSaturation;    // -100..100
uniform float uPivot;         // 0..1
uniform float uHighlights;    // -100..100
uniform float uShadows;       // -100..100
uniform float uVibrance;      // -100..100
uniform float uHueShift;      // -180..180 degrees

uniform float uLiftR; uniform float uLiftG; uniform float uLiftB;
uniform float uGammaR; uniform float uGammaG; uniform float uGammaB;
uniform float uGainR; uniform float uGainG; uniform float uGainB;

varying vec2 vTexCoord;

// sRGB <-> linear
float srgbToLinear(float v) {
    return v <= 0.04045 ? v / 12.92 : pow((v + 0.055) / 1.055, 2.4);
}
float linearToSrgb(float v) {
    return v <= 0.0031308 ? v * 12.92 : 1.055 * pow(v, 1.0/2.4) - 0.055;
}
vec3 srgbToLinearV(vec3 c) {
    return vec3(srgbToLinear(c.r), srgbToLinear(c.g), srgbToLinear(c.b));
}
vec3 linearToSrgbV(vec3 c) {
    return vec3(linearToSrgb(c.r), linearToSrgb(c.g), linearToSrgb(c.b));
}

// RGB <-> HSL
vec3 rgbToHsl(vec3 c) {
    float maxC = max(c.r, max(c.g, c.b));
    float minC = min(c.r, min(c.g, c.b));
    float l = (maxC + minC) * 0.5;
    if (maxC == minC) return vec3(0.0, 0.0, l);
    float d = maxC - minC;
    float s = l > 0.5 ? d / (2.0 - maxC - minC) : d / (maxC + minC);
    float h;
    if (maxC == c.r)      h = (c.g - c.b) / d + (c.g < c.b ? 6.0 : 0.0);
    else if (maxC == c.g) h = (c.b - c.r) / d + 2.0;
    else                  h = (c.r - c.g) / d + 4.0;
    return vec3(h / 6.0, s, l);
}

float hue2rgb(float p, float q, float t) {
    if (t < 0.0) t += 1.0;
    if (t > 1.0) t -= 1.0;
    if (t < 1.0/6.0) return p + (q-p)*6.0*t;
    if (t < 0.5)     return q;
    if (t < 2.0/3.0) return p + (q-p)*(2.0/3.0 - t)*6.0;
    return p;
}
vec3 hslToRgb(vec3 hsl) {
    if (hsl.y == 0.0) return vec3(hsl.z);
    float q = hsl.z < 0.5 ? hsl.z*(1.0+hsl.y) : hsl.z+hsl.y-hsl.z*hsl.y;
    float p = 2.0*hsl.z - q;
    return vec3(hue2rgb(p,q,hsl.x+1.0/3.0), hue2rgb(p,q,hsl.x), hue2rgb(p,q,hsl.x-1.0/3.0));
}

void main() {
    vec4 texColor = texture2D(uTexture, vTexCoord);
    vec3 c = srgbToLinearV(texColor.rgb);

    // Exposure
    c *= pow(2.0, uExposure);

    // Temperature / Tint
    float tempShift = uTemperature / 100.0 * 0.15;
    float tintShift = uTint / 100.0 * 0.05;
    c.r += tempShift;
    c.b -= tempShift;
    c.g += tintShift;

    // Lift / Gamma / Gain (CDL)
    c.r = (c.r + uLiftR) * (1.0 + uGainR);
    c.g = (c.g + uLiftG) * (1.0 + uGainG);
    c.b = (c.b + uLiftB) * (1.0 + uGainB);
    if (uGammaR != 0.0) c.r = pow(max(c.r, 0.0), 1.0 / (1.0 + uGammaR));
    if (uGammaG != 0.0) c.g = pow(max(c.g, 0.0), 1.0 / (1.0 + uGammaG));
    if (uGammaB != 0.0) c.b = pow(max(c.b, 0.0), 1.0 / (1.0 + uGammaB));

    // Contrast
    float contrastNorm = uContrast / 100.0;
    c = uPivot + (c - uPivot) * (1.0 + contrastNorm);

    // Highlights / Shadows
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    float hiMask = max(0.0, luma - 0.5) * 2.0;
    float loMask = max(0.0, 0.5 - luma) * 2.0;
    c += (uHighlights / 100.0 * hiMask + uShadows / 100.0 * loMask) * 0.5;

    // Saturation
    float satNorm = 1.0 + uSaturation / 100.0;
    float lumaSat = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = lumaSat + (c - lumaSat) * satNorm;

    // Vibrance
    if (uVibrance != 0.0) {
        float maxC = max(c.r, max(c.g, c.b));
        float minC = min(c.r, min(c.g, c.b));
        float sat = (maxC - minC) / (maxC + 0.000001);
        float vib = uVibrance / 100.0 * (1.0 - sat);
        float lumaV = dot(c, vec3(0.2126, 0.7152, 0.0722));
        c = lumaV + (c - lumaV) * (1.0 + vib);
    }

    // Hue shift
    if (uHueShift != 0.0) {
        vec3 hsl = rgbToHsl(c);
        hsl.x = mod(hsl.x + uHueShift / 360.0 + 1.0, 1.0);
        c = hslToRgb(hsl);
    }

    c = clamp(c, 0.0, 1.0);
    c = linearToSrgbV(c);

    gl_FragColor = vec4(c, texColor.a);
}

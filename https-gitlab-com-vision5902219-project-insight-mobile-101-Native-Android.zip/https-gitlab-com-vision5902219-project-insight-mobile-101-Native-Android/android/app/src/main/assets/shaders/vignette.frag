precision mediump float;
uniform sampler2D uTexture;
uniform float uIntensity;
uniform float uFeather;
varying vec2 vTexCoord;

void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    vec2 uv = vTexCoord - 0.5;
    float dist = length(uv * vec2(1.0, 1.0));
    float vignette = 1.0 - smoothstep(1.0 - uFeather, 1.0, dist * 1.414) * uIntensity;
    color.rgb *= vignette;
    gl_FragColor = color;
}

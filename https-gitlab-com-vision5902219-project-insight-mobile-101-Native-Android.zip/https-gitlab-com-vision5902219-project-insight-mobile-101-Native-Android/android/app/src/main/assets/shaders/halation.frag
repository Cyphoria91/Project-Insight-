precision mediump float;
uniform sampler2D uTexture;
uniform float uIntensity;
uniform vec2 uTexelSize;
varying vec2 vTexCoord;

void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    // Red-channel bloom around highlights
    float r = 0.0;
    float total = 0.0;
    for (int x = -3; x <= 3; x++) {
        for (int y = -3; y <= 3; y++) {
            float w = exp(-float(x*x + y*y) / 8.0);
            vec2 uv = vTexCoord + vec2(float(x), float(y)) * uTexelSize * 4.0;
            r += texture2D(uTexture, uv).r * w;
            total += w;
        }
    }
    r /= total;
    float luma = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));
    float mask = max(0.0, luma - 0.65) / 0.35 * uIntensity;
    color.r = clamp(color.r + r * mask * 0.4, 0.0, 1.0);
    color.b = clamp(color.b - r * mask * 0.15, 0.0, 1.0);
    gl_FragColor = color;
}

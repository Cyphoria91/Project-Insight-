precision mediump float;
uniform sampler2D uTexture;
uniform float uIntensity;
uniform vec2 uTexelSize;
varying vec2 vTexCoord;

void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    // Horizontal streak from bright sources
    float streak = 0.0;
    float total = 0.0;
    for (int x = -16; x <= 16; x++) {
        float w = exp(-float(x*x) / 32.0);
        vec2 uv = vTexCoord + vec2(float(x) * uTexelSize.x * 3.0, 0.0);
        float luma = dot(texture2D(uTexture, uv).rgb, vec3(0.2126, 0.7152, 0.0722));
        streak += max(0.0, luma - 0.7) * w;
        total += w;
    }
    streak /= total;
    // Blue-tinted horizontal flare
    color.r += streak * uIntensity * 0.3;
    color.g += streak * uIntensity * 0.5;
    color.b += streak * uIntensity * 1.0;
    color.rgb = clamp(color.rgb, 0.0, 1.0);
    gl_FragColor = color;
}

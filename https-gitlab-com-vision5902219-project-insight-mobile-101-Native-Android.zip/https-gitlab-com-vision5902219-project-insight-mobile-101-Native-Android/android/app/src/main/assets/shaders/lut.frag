// 3D LUT packed as a 2D texture (N slices of NxN, laid out horizontally)
// Supports 17x17x17 (289x17) and 33x33x33 (1089x33) LUT textures
precision mediump float;
uniform sampler2D uTexture;
uniform sampler2D uLutTexture;
uniform float uIntensity;
uniform float uLutSize;   // e.g. 33.0
varying vec2 vTexCoord;

vec3 sampleLut(vec3 color) {
    float scale = (uLutSize - 1.0) / uLutSize;
    float offset = 0.5 / uLutSize;
    color = clamp(color, 0.0, 1.0) * scale + offset;

    float bSlice = color.b * (uLutSize - 1.0);
    float bSlice0 = floor(bSlice);
    float bSlice1 = min(bSlice0 + 1.0, uLutSize - 1.0);
    float bFrac = bSlice - bSlice0;

    vec2 uv0 = vec2((bSlice0 + color.r) / uLutSize, color.g);
    vec2 uv1 = vec2((bSlice1 + color.r) / uLutSize, color.g);

    vec3 c0 = texture2D(uLutTexture, uv0).rgb;
    vec3 c1 = texture2D(uLutTexture, uv1).rgb;
    return mix(c0, c1, bFrac);
}

void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    vec3 graded = sampleLut(color.rgb);
    color.rgb = mix(color.rgb, graded, uIntensity);
    gl_FragColor = color;
}

precision mediump float;
uniform sampler2D uTexture;
uniform float uIntensity;
uniform float uRadius;
uniform vec2 uTexelSize;
varying vec2 vTexCoord;

void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    // 9-tap Gaussian blur for glow source
    vec3 blur = vec3(0.0);
    float total = 0.0;
    for (int x = -2; x <= 2; x++) {
        for (int y = -2; y <= 2; y++) {
            float w = exp(-float(x*x + y*y) / (2.0 * uRadius * uRadius));
            vec2 uv = vTexCoord + vec2(float(x), float(y)) * uTexelSize * uRadius * 3.0;
            blur += texture2D(uTexture, uv).rgb * w;
            total += w;
        }
    }
    blur /= total;
    // Only add glow where pixels are bright
    float luma = dot(blur, vec3(0.2126, 0.7152, 0.0722));
    float mask = max(0.0, luma - 0.5) * 2.0;
    color.rgb += blur * mask * uIntensity;
    color.rgb = clamp(color.rgb, 0.0, 1.0);
    gl_FragColor = color;
}

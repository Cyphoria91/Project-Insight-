// Film grain — implemented in NativeEngine::applyFilmGrain

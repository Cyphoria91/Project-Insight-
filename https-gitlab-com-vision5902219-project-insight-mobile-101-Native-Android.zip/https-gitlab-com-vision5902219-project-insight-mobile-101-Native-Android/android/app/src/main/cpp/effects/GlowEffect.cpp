// Glow + Halation — implemented in NativeEngine::applyGlow / applyHalation

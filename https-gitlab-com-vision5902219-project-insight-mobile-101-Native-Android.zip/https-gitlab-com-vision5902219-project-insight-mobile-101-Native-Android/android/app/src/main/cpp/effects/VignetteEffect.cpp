// Vignette — implemented in NativeEngine::applyVignette

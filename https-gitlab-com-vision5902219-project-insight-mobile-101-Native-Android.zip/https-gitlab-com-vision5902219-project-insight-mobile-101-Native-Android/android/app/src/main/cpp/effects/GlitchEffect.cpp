#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <vector>

// Glitch cut effect: random horizontal slice displacement + RGB channel split
extern "C" void applyGlitchEffect(uint8_t* pixels, int width, int height,
                                   int stride, float intensity, long seed) {
    srand(static_cast<unsigned>(seed));
    int numSlices = static_cast<int>(intensity * 20) + 2;
    for (int s = 0; s < numSlices; ++s) {
        int y = rand() % height;
        int sliceH = std::max(1, rand() % (height / 10));
        int shift = (rand() % 40 - 20) * static_cast<int>(intensity);
        for (int row = y; row < std::min(y + sliceH, height); ++row) {
            uint8_t* src = pixels + row * stride;
            std::vector<uint8_t> tmp(src, src + width * 4);
            for (int x = 0; x < width; ++x) {
                int sx = std::clamp(x + shift, 0, width - 1);
                src[x*4+0] = tmp[sx*4+0];
                src[x*4+1] = tmp[sx*4+1];
                src[x*4+2] = tmp[sx*4+2];
            }
        }
    }
}

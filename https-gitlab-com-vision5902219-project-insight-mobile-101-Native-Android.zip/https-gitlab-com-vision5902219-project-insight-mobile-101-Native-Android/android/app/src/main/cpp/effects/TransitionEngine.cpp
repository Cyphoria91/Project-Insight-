#include <cstdint>
#include <cstring>
#include <algorithm>
#include <cmath>

// Transition blending between two frames
// progress: 0.0 = fully frameA, 1.0 = fully frameB

extern "C" void blendCrossDissolve(
        const uint8_t* frameA, const uint8_t* frameB,
        uint8_t* dst, int width, int height, int stride, float progress) {
    for (int y = 0; y < height; ++y) {
        const uint8_t* a = frameA + y * stride;
        const uint8_t* b = frameB + y * stride;
        uint8_t* d = dst + y * stride;
        for (int x = 0; x < width * 4; ++x) {
            d[x] = static_cast<uint8_t>(a[x] * (1.f - progress) + b[x] * progress);
        }
    }
}

extern "C" void blendDipToBlack(
        const uint8_t* frameA, const uint8_t* frameB,
        uint8_t* dst, int width, int height, int stride, float progress) {
    // First half: fade out A, second half: fade in B
    float alpha = progress < 0.5f ? (1.f - progress * 2.f) : ((progress - 0.5f) * 2.f);
    const uint8_t* src = progress < 0.5f ? frameA : frameB;
    for (int y = 0; y < height; ++y) {
        const uint8_t* s = src + y * stride;
        uint8_t* d = dst + y * stride;
        for (int x = 0; x < width; ++x) {
            d[x*4+0] = static_cast<uint8_t>(s[x*4+0] * alpha);
            d[x*4+1] = static_cast<uint8_t>(s[x*4+1] * alpha);
            d[x*4+2] = static_cast<uint8_t>(s[x*4+2] * alpha);
            d[x*4+3] = s[x*4+3];
        }
    }
}

extern "C" void blendWhipPan(
        const uint8_t* frameA, const uint8_t* frameB,
        uint8_t* dst, int width, int height, int stride, float progress) {
    // Horizontal wipe with motion blur approximation
    int splitX = static_cast<int>(progress * width);
    for (int y = 0; y < height; ++y) {
        const uint8_t* a = frameA + y * stride;
        const uint8_t* b = frameB + y * stride;
        uint8_t* d = dst + y * stride;
        for (int x = 0; x < width; ++x) {
            const uint8_t* src = x < splitX ? b : a;
            d[x*4+0] = src[x*4+0];
            d[x*4+1] = src[x*4+1];
            d[x*4+2] = src[x*4+2];
            d[x*4+3] = src[x*4+3];
        }
    }
}

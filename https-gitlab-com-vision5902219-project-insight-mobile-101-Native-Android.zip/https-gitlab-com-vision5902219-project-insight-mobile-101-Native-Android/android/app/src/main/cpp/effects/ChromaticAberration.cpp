// Chromatic aberration — implemented in NativeEngine::applyChromaticAberration

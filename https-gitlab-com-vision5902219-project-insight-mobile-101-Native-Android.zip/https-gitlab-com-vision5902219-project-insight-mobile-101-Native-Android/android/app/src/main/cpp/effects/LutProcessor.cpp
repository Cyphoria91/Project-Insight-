// 3D LUT trilinear interpolation — implemented in NativeEngine::applyLut

#include <jni.h>
#include <android/log.h>
#include <android/bitmap.h>
#include "engine/NativeEngine.h"
#include <memory>
#include <string>
#include <vector>

#define LOG_TAG "InsightJNI"
// LOGI suppressed in release; LOGE retained for JNI error paths.
#ifdef NDEBUG
#  define LOGI(...) ((void)0)
#else
#  define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#endif
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Global engine instance (one per process)
static std::unique_ptr<insight::NativeEngine> g_engine;

// ─── Helper: lock bitmap, run lambda, unlock ─────────────────────────────────
// Ensures AndroidBitmap_unlockPixels is always called after a successful lock,
// even if the engine call throws a C++ exception.
// Returns JNI_FALSE if the engine is not ready, the lock fails, or the format
// is not RGBA_8888.
template<typename Fn>
static jboolean withBitmap(JNIEnv* env, jobject bitmap, Fn fn) {
    if (!g_engine || !g_engine->isInitialized()) return JNI_FALSE;
    AndroidBitmapInfo info{};
    if (AndroidBitmap_getInfo(env, bitmap, &info) < 0) {
        LOGE("withBitmap: getInfo failed");
        return JNI_FALSE;
    }
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) {
        LOGE("withBitmap: bitmap must be RGBA_8888, got %d", info.format);
        return JNI_FALSE;
    }
    void* pixels = nullptr;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) < 0) {
        LOGE("withBitmap: lockPixels failed");
        return JNI_FALSE;
    }
    fn(static_cast<uint8_t*>(pixels), info);
    AndroidBitmap_unlockPixels(env, bitmap);
    return JNI_TRUE;
}

extern "C" {

// ─── Engine lifecycle ────────────────────────────────────────────────────────

JNIEXPORT jboolean JNICALL
Java_app_insighteditor_native_NativeEngine_nativeInit(JNIEnv* env, jobject) {
    if (!g_engine) g_engine = std::make_unique<insight::NativeEngine>();
    return g_engine->init() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_app_insighteditor_native_NativeEngine_nativeRelease(JNIEnv* env, jobject) {
    if (g_engine) { g_engine->release(); g_engine.reset(); }
}

JNIEXPORT jstring JNICALL
Java_app_insighteditor_native_NativeEngine_nativeGetVersion(JNIEnv* env, jobject) {
    return env->NewStringUTF(insight::NativeEngine::getVersion().c_str());
}

// ─── Color grading on Bitmap ─────────────────────────────────────────────────

JNIEXPORT jboolean JNICALL
Java_app_insighteditor_native_NativeEngine_nativeApplyColorGrade(
        JNIEnv* env, jobject,
        jobject bitmap,
        jfloat temperature, jfloat tint, jfloat exposure, jfloat contrast,
        jfloat saturation, jfloat pivot,
        jfloat liftR, jfloat liftG, jfloat liftB,
        jfloat gammaR, jfloat gammaG, jfloat gammaB,
        jfloat gainR, jfloat gainG, jfloat gainB,
        jfloat highlights, jfloat shadows, jfloat whites, jfloat blacks,
        jfloat vibrance, jfloat hueShift) {

    insight::ColorGrade grade;
    grade.temperature = temperature; grade.tint = tint;
    grade.exposure = exposure;       grade.contrast = contrast;
    grade.saturation = saturation;   grade.pivot = pivot;
    grade.liftR = liftR; grade.liftG = liftG; grade.liftB = liftB;
    grade.gammaR = gammaR; grade.gammaG = gammaG; grade.gammaB = gammaB;
    grade.gainR = gainR; grade.gainG = gainG; grade.gainB = gainB;
    grade.highlights = highlights; grade.shadows = shadows;
    grade.whites = whites; grade.blacks = blacks;
    grade.vibrance = vibrance; grade.hueShift = hueShift;

    return withBitmap(env, bitmap, [&](uint8_t* px, const AndroidBitmapInfo& i) {
        g_engine->applyColorGrade(px, i.width, i.height, i.stride, grade);
    });
}

// ─── Film grain ──────────────────────────────────────────────────────────────

JNIEXPORT jboolean JNICALL
Java_app_insighteditor_native_NativeEngine_nativeApplyFilmGrain(
        JNIEnv* env, jobject, jobject bitmap, jfloat intensity, jlong seed) {
    return withBitmap(env, bitmap, [&](uint8_t* px, const AndroidBitmapInfo& i) {
        g_engine->applyFilmGrain(px, i.width, i.height, i.stride, intensity, seed);
    });
}

// ─── Vignette ────────────────────────────────────────────────────────────────

JNIEXPORT jboolean JNICALL
Java_app_insighteditor_native_NativeEngine_nativeApplyVignette(
        JNIEnv* env, jobject, jobject bitmap, jfloat intensity, jfloat feather) {
    return withBitmap(env, bitmap, [&](uint8_t* px, const AndroidBitmapInfo& i) {
        g_engine->applyVignette(px, i.width, i.height, i.stride, intensity, feather);
    });
}

// ─── Chromatic aberration ────────────────────────────────────────────────────

JNIEXPORT jboolean JNICALL
Java_app_insighteditor_native_NativeEngine_nativeApplyChromaticAberration(
        JNIEnv* env, jobject, jobject bitmap, jfloat intensity) {
    return withBitmap(env, bitmap, [&](uint8_t* px, const AndroidBitmapInfo& i) {
        g_engine->applyChromaticAberration(px, i.width, i.height, i.stride, intensity);
    });
}

// ─── Glow ────────────────────────────────────────────────────────────────────

JNIEXPORT jboolean JNICALL
Java_app_insighteditor_native_NativeEngine_nativeApplyGlow(
        JNIEnv* env, jobject, jobject bitmap, jfloat intensity, jfloat radius) {
    return withBitmap(env, bitmap, [&](uint8_t* px, const AndroidBitmapInfo& i) {
        g_engine->applyGlow(px, i.width, i.height, i.stride, intensity, radius);
    });
}

// ─── Waveform analysis ───────────────────────────────────────────────────────

JNIEXPORT jfloatArray JNICALL
Java_app_insighteditor_native_NativeEngine_nativeAnalyzeWaveform(
        JNIEnv* env, jobject,
        jshortArray samples, jint channels, jint peakCount) {

    if (!g_engine || !g_engine->isInitialized() || peakCount <= 0 || channels <= 0)
        return nullptr;

    jsize len = env->GetArrayLength(samples);
    if (len == 0) return nullptr;

    // JNI_ABORT: do not copy back — we only read the array.
    jshort* data = env->GetShortArrayElements(samples, nullptr);
    if (!data) return nullptr;

    std::vector<float> peaks(peakCount, 0.f);
    g_engine->analyzeWaveform(
        reinterpret_cast<const int16_t*>(data),
        static_cast<int>(len) / channels, channels,
        peaks.data(), peakCount
    );
    env->ReleaseShortArrayElements(samples, data, JNI_ABORT);

    jfloatArray result = env->NewFloatArray(peakCount);
    if (result) env->SetFloatArrayRegion(result, 0, peakCount, peaks.data());
    return result;
}

// ─── LUT loading ─────────────────────────────────────────────────────────────

JNIEXPORT jboolean JNICALL
Java_app_insighteditor_native_NativeEngine_nativeLoadLut(
        JNIEnv* env, jobject, jstring name, jbyteArray data) {

    if (!g_engine || !g_engine->isInitialized()) return JNI_FALSE;

    const char* nameStr = env->GetStringUTFChars(name, nullptr);
    if (!nameStr) return JNI_FALSE;

    jsize len = env->GetArrayLength(data);
    jbyte* bytes = env->GetByteArrayElements(data, nullptr);
    bool ok = false;
    if (bytes) {
        ok = g_engine->loadLut(nameStr, reinterpret_cast<const uint8_t*>(bytes), len);
        env->ReleaseByteArrayElements(data, bytes, JNI_ABORT);
    }
    env->ReleaseStringUTFChars(name, nameStr);
    return ok ? JNI_TRUE : JNI_FALSE;
}

} // extern "C"

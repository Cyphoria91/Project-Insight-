// GPU-accelerated color grade path (OpenGL ES compute shaders)
// CPU fallback is in NativeEngine::applyColorGrade
#include "NativeEngine.h"

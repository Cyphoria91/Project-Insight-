// Effect dispatch — routes to GPU shader path or CPU fallback
#include "NativeEngine.h"

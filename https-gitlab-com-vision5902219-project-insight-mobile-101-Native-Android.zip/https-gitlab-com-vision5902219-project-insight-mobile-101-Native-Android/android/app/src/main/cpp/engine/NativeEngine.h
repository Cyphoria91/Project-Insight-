#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <memory>
#include <functional>

namespace insight {

struct ColorGrade {
    float temperature = 0.f;
    float tint        = 0.f;
    float exposure    = 0.f;
    float contrast    = 0.f;
    float saturation  = 0.f;
    float pivot       = 0.5f;
    float liftR = 0.f, liftG = 0.f, liftB = 0.f;
    float gammaR = 0.f, gammaG = 0.f, gammaB = 0.f;
    float gainR = 0.f, gainG = 0.f, gainB = 0.f;
    float highlights = 0.f;
    float shadows    = 0.f;
    float whites     = 0.f;
    float blacks     = 0.f;
    float vibrance   = 0.f;
    float hueShift   = 0.f;
    std::string lutName;
    float lutIntensity = 1.f;
};

struct EffectParams {
    int   type      = 0;
    float intensity = 1.f;
    float param1    = 0.f;
    float param2    = 0.f;
    float param3    = 0.f;
};

struct FrameData {
    uint8_t* pixels = nullptr;
    int width  = 0;
    int height = 0;
    int stride = 0;   // bytes per row
    int64_t timestampUs = 0;
};

using ProgressCallback = std::function<void(float progress, const std::string& stage)>;

class NativeEngine {
public:
    NativeEngine();
    ~NativeEngine();

    bool init();
    void release();

    // Frame processing
    bool processFrame(FrameData& frame, const ColorGrade& grade,
                      const std::vector<EffectParams>& effects);

    // Color grading (in-place RGBA8888)
    void applyColorGrade(uint8_t* pixels, int width, int height,
                         int stride, const ColorGrade& grade);

    // LUT application
    bool loadLut(const std::string& name, const uint8_t* data, int size);
    void applyLut(uint8_t* pixels, int width, int height, int stride,
                  const std::string& lutName, float intensity);

    // Effects
    void applyFilmGrain(uint8_t* pixels, int width, int height, int stride,
                        float intensity, int64_t seed);
    void applyVignette(uint8_t* pixels, int width, int height, int stride,
                       float intensity, float feather);
    void applyChromaticAberration(uint8_t* pixels, int width, int height,
                                  int stride, float intensity);
    void applyGlow(uint8_t* pixels, int width, int height, int stride,
                   float intensity, float radius);
    void applyHalation(uint8_t* pixels, int width, int height, int stride,
                       float intensity);

    // Waveform analysis
    void analyzeWaveform(const int16_t* samples, int count, int channels,
                         float* outPeaks, int peakCount);

    // Utility
    static std::string getVersion();
    bool isInitialized() const { return m_initialized; }

private:
    bool m_initialized = false;

    struct LutEntry {
        std::string name;
        std::vector<uint8_t> data;
        int size = 0;
    };
    std::vector<LutEntry> m_luts;

    // Inline color math helpers
    static float linearToSrgb(float v);
    static float srgbToLinear(float v);
    static void rgbToHsl(float r, float g, float b, float& h, float& s, float& l);
    static void hslToRgb(float h, float s, float l, float& r, float& g, float& b);
    static float applyContrast(float v, float contrast, float pivot);
    static float applyExposure(float v, float ev);
    static float applyTemperature(float r, float b, float temp, bool isRed);
};

} // namespace insight

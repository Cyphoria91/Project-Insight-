// Frame scheduling and pipeline orchestration
// Actual pixel processing is in NativeEngine.cpp
#include "NativeEngine.h"

#include "NativeEngine.h"
#include <android/log.h>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <random>

#define LOG_TAG "InsightEngine"
// LOGI is suppressed in release builds via NDEBUG; LOGE is retained for fatal JNI errors.
#ifdef NDEBUG
#  define LOGI(...) ((void)0)
#else
#  define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#endif
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace insight {

NativeEngine::NativeEngine() = default;
NativeEngine::~NativeEngine() { release(); }

bool NativeEngine::init() {
    LOGI("NativeEngine init — version %s", getVersion().c_str());
    m_initialized = true;
    return true;
}

void NativeEngine::release() {
    m_luts.clear();
    m_initialized = false;
}

std::string NativeEngine::getVersion() { return ENGINE_VERSION; }

// ─── Frame processing ────────────────────────────────────────────────────────

bool NativeEngine::processFrame(FrameData& frame, const ColorGrade& grade,
                                const std::vector<EffectParams>& effects) {
    if (!frame.pixels || frame.width <= 0 || frame.height <= 0) return false;

    applyColorGrade(frame.pixels, frame.width, frame.height, frame.stride, grade);

    for (const auto& fx : effects) {
        switch (fx.type) {
            case 1: applyFilmGrain(frame.pixels, frame.width, frame.height,
                                   frame.stride, fx.intensity, frame.timestampUs); break;
            case 2: applyVignette(frame.pixels, frame.width, frame.height,
                                  frame.stride, fx.intensity, fx.param1); break;
            case 3: applyChromaticAberration(frame.pixels, frame.width, frame.height,
                                             frame.stride, fx.intensity); break;
            case 4: applyGlow(frame.pixels, frame.width, frame.height,
                              frame.stride, fx.intensity, fx.param1); break;
            case 5: applyHalation(frame.pixels, frame.width, frame.height,
                                  frame.stride, fx.intensity); break;
        }
    }

    if (!grade.lutName.empty()) {
        applyLut(frame.pixels, frame.width, frame.height, frame.stride,
                 grade.lutName, grade.lutIntensity);
    }

    return true;
}

// ─── Color grading ───────────────────────────────────────────────────────────

void NativeEngine::applyColorGrade(uint8_t* pixels, int width, int height,
                                   int stride, const ColorGrade& g) {
    const float expMul = std::pow(2.f, g.exposure);
    const float contrastNorm = g.contrast / 100.f;
    const float satNorm = 1.f + g.saturation / 100.f;
    const float tempShift = g.temperature / 100.f * 0.15f;
    const float tintShift = g.tint / 100.f * 0.05f;
    const float vibrance = g.vibrance / 100.f;
    const float hueShiftRad = g.hueShift / 360.f;

    for (int y = 0; y < height; ++y) {
        uint8_t* row = pixels + y * stride;
        for (int x = 0; x < width; ++x) {
            float r = row[x*4 + 0] / 255.f;
            float gv = row[x*4 + 1] / 255.f;
            float b = row[x*4 + 2] / 255.f;

            // sRGB → linear
            r = srgbToLinear(r);
            gv = srgbToLinear(gv);
            b = srgbToLinear(b);

            // Exposure
            r *= expMul; gv *= expMul; b *= expMul;

            // Temperature (warm/cool)
            r += tempShift;
            b -= tempShift;
            gv += tintShift;

            // ASC CDL: out = clamp( (in * slope + offset) ^ power )
            // UI maps: liftX → offset, gammaX → power adjustment, gainX → slope
            // slope = 1 + gainX, offset = liftX, power = 1 / (1 + gammaX)
            r  = r  * (1.f + g.gainR)  + g.liftR;
            gv = gv * (1.f + g.gainG)  + g.liftG;
            b  = b  * (1.f + g.gainB)  + g.liftB;

            // Gamma (power function) — only compute pow when non-zero to avoid
            // unnecessary std::pow calls on every pixel.
            if (g.gammaR != 0.f) r  = std::pow(std::max(r,  0.f), 1.f / (1.f + g.gammaR));
            if (g.gammaG != 0.f) gv = std::pow(std::max(gv, 0.f), 1.f / (1.f + g.gammaG));
            if (g.gammaB != 0.f) b  = std::pow(std::max(b,  0.f), 1.f / (1.f + g.gammaB));

            // Contrast
            r = applyContrast(r, contrastNorm, g.pivot);
            gv = applyContrast(gv, contrastNorm, g.pivot);
            b = applyContrast(b, contrastNorm, g.pivot);

            // Highlights / Shadows / Whites / Blacks
            float luma = 0.2126f*r + 0.7152f*gv + 0.0722f*b;
            float hiMask = std::max(0.f, luma - 0.5f) * 2.f;
            float loMask = std::max(0.f, 0.5f - luma) * 2.f;
            float hiAdj = g.highlights / 100.f * hiMask * 0.5f;
            float loAdj = g.shadows / 100.f * loMask * 0.5f;
            r += hiAdj + loAdj; gv += hiAdj + loAdj; b += hiAdj + loAdj;

            // Saturation
            float lumaSat = 0.2126f*r + 0.7152f*gv + 0.0722f*b;
            r = lumaSat + (r - lumaSat) * satNorm;
            gv = lumaSat + (gv - lumaSat) * satNorm;
            b = lumaSat + (b - lumaSat) * satNorm;

            // Vibrance (boost less-saturated colors more)
            if (vibrance != 0.f) {
                float maxC = std::max({r, gv, b});
                float minC = std::min({r, gv, b});
                float sat = (maxC - minC) / (maxC + 1e-6f);
                float vib = vibrance * (1.f - sat);
                float lumaV = 0.2126f*r + 0.7152f*gv + 0.0722f*b;
                r = lumaV + (r - lumaV) * (1.f + vib);
                gv = lumaV + (gv - lumaV) * (1.f + vib);
                b = lumaV + (b - lumaV) * (1.f + vib);
            }

            // Hue shift
            if (g.hueShift != 0.f) {
                float h, s, l;
                rgbToHsl(r, gv, b, h, s, l);
                h = std::fmod(h + hueShiftRad + 1.f, 1.f);
                hslToRgb(h, s, l, r, gv, b);
            }

            // linear → sRGB + clamp
            r = linearToSrgb(std::clamp(r, 0.f, 1.f));
            gv = linearToSrgb(std::clamp(gv, 0.f, 1.f));
            b = linearToSrgb(std::clamp(b, 0.f, 1.f));

            row[x*4 + 0] = static_cast<uint8_t>(r * 255.f + 0.5f);
            row[x*4 + 1] = static_cast<uint8_t>(gv * 255.f + 0.5f);
            row[x*4 + 2] = static_cast<uint8_t>(b * 255.f + 0.5f);
            // alpha unchanged
        }
    }
}

// ─── LUT ─────────────────────────────────────────────────────────────────────

bool NativeEngine::loadLut(const std::string& name, const uint8_t* data, int size) {
    for (auto& e : m_luts) {
        if (e.name == name) {
            e.data.assign(data, data + size);
            e.size = size;
            return true;
        }
    }
    LutEntry entry;
    entry.name = name;
    entry.data.assign(data, data + size);
    entry.size = size;
    m_luts.push_back(std::move(entry));
    return true;
}

void NativeEngine::applyLut(uint8_t* pixels, int width, int height, int stride,
                             const std::string& lutName, float intensity) {
    // 3D LUT — 33x33x33 cube, RGBA8888 layout
    const LutEntry* lut = nullptr;
    for (const auto& e : m_luts) {
        if (e.name == lutName) { lut = &e; break; }
    }
    if (!lut || lut->data.empty()) return;

    const int N = 33;
    const float scale = (N - 1) / 255.f;

    for (int y = 0; y < height; ++y) {
        uint8_t* row = pixels + y * stride;
        for (int x = 0; x < width; ++x) {
            float r = row[x*4+0] * scale;
            float g = row[x*4+1] * scale;
            float b = row[x*4+2] * scale;

            int r0 = (int)r, g0 = (int)g, b0 = (int)b;
            int r1 = std::min(r0+1, N-1), g1 = std::min(g0+1, N-1), b1 = std::min(b0+1, N-1);
            float rf = r - r0, gf = g - g0, bf = b - b0;

            auto idx = [&](int ri, int gi, int bi) -> int {
                return (bi * N * N + gi * N + ri) * 4;
            };

            // Trilinear interpolation
            auto lerp = [](float a, float b, float t) { return a + (b-a)*t; };
            auto sampleR = [&](int ri, int gi, int bi) -> float {
                return lut->data[idx(ri,gi,bi)+0] / 255.f;
            };
            auto sampleG = [&](int ri, int gi, int bi) -> float {
                return lut->data[idx(ri,gi,bi)+1] / 255.f;
            };
            auto sampleB = [&](int ri, int gi, int bi) -> float {
                return lut->data[idx(ri,gi,bi)+2] / 255.f;
            };

            float outR = lerp(lerp(lerp(sampleR(r0,g0,b0), sampleR(r1,g0,b0), rf),
                                   lerp(sampleR(r0,g1,b0), sampleR(r1,g1,b0), rf), gf),
                              lerp(lerp(sampleR(r0,g0,b1), sampleR(r1,g0,b1), rf),
                                   lerp(sampleR(r0,g1,b1), sampleR(r1,g1,b1), rf), gf), bf);
            float outG = lerp(lerp(lerp(sampleG(r0,g0,b0), sampleG(r1,g0,b0), rf),
                                   lerp(sampleG(r0,g1,b0), sampleG(r1,g1,b0), rf), gf),
                              lerp(lerp(sampleG(r0,g0,b1), sampleG(r1,g0,b1), rf),
                                   lerp(sampleG(r0,g1,b1), sampleG(r1,g1,b1), rf), gf), bf);
            float outB = lerp(lerp(lerp(sampleB(r0,g0,b0), sampleB(r1,g0,b0), rf),
                                   lerp(sampleB(r0,g1,b0), sampleB(r1,g1,b0), rf), gf),
                              lerp(lerp(sampleB(r0,g0,b1), sampleB(r1,g0,b1), rf),
                                   lerp(sampleB(r0,g1,b1), sampleB(r1,g1,b1), rf), gf), bf);

            float origR = row[x*4+0] / 255.f;
            float origG = row[x*4+1] / 255.f;
            float origB = row[x*4+2] / 255.f;

            row[x*4+0] = static_cast<uint8_t>((origR + (outR - origR) * intensity) * 255.f + 0.5f);
            row[x*4+1] = static_cast<uint8_t>((origG + (outG - origG) * intensity) * 255.f + 0.5f);
            row[x*4+2] = static_cast<uint8_t>((origB + (outB - origB) * intensity) * 255.f + 0.5f);
        }
    }
}

// ─── Effects ─────────────────────────────────────────────────────────────────

void NativeEngine::applyFilmGrain(uint8_t* pixels, int width, int height,
                                  int stride, float intensity, int64_t seed) {
    std::mt19937 rng(static_cast<uint32_t>(seed / 16667));
    std::uniform_real_distribution<float> dist(-1.f, 1.f);
    const float scale = intensity * 30.f;

    for (int y = 0; y < height; ++y) {
        uint8_t* row = pixels + y * stride;
        for (int x = 0; x < width; ++x) {
            float noise = dist(rng) * scale;
            int ni = static_cast<int>(noise);
            row[x*4+0] = static_cast<uint8_t>(std::clamp(row[x*4+0] + ni, 0, 255));
            row[x*4+1] = static_cast<uint8_t>(std::clamp(row[x*4+1] + ni, 0, 255));
            row[x*4+2] = static_cast<uint8_t>(std::clamp(row[x*4+2] + ni, 0, 255));
        }
    }
}

void NativeEngine::applyVignette(uint8_t* pixels, int width, int height,
                                 int stride, float intensity, float feather) {
    const float cx = width * 0.5f;
    const float cy = height * 0.5f;
    const float maxDist = std::sqrt(cx*cx + cy*cy);
    const float featherVal = std::max(feather, 0.01f);

    for (int y = 0; y < height; ++y) {
        uint8_t* row = pixels + y * stride;
        for (int x = 0; x < width; ++x) {
            float dx = (x - cx) / cx;
            float dy = (y - cy) / cy;
            float dist = std::sqrt(dx*dx + dy*dy);
            float vignette = 1.f - std::clamp((dist - (1.f - featherVal)) / featherVal, 0.f, 1.f) * intensity;
            row[x*4+0] = static_cast<uint8_t>(row[x*4+0] * vignette);
            row[x*4+1] = static_cast<uint8_t>(row[x*4+1] * vignette);
            row[x*4+2] = static_cast<uint8_t>(row[x*4+2] * vignette);
        }
    }
}

void NativeEngine::applyChromaticAberration(uint8_t* pixels, int width, int height,
                                            int stride, float intensity) {
    std::vector<uint8_t> copy(pixels, pixels + height * stride);
    const int shift = static_cast<int>(intensity * 8.f);

    for (int y = 0; y < height; ++y) {
        uint8_t* row = pixels + y * stride;
        const uint8_t* src = copy.data() + y * stride;
        for (int x = 0; x < width; ++x) {
            int xr = std::clamp(x + shift, 0, width-1);
            int xb = std::clamp(x - shift, 0, width-1);
            row[x*4+0] = src[xr*4+0];
            row[x*4+2] = src[xb*4+2];
        }
    }
}

void NativeEngine::applyGlow(uint8_t* pixels, int width, int height,
                             int stride, float intensity, float radius) {
    // Box-blur glow: blur a copy of the frame, then add bright regions back.
    const int r = std::max(1, static_cast<int>(radius * 10.f));
    const int bufSize = height * stride;

    // src: original pixels (read-only during blur)
    // blurred: output of the horizontal pass, then used as glow source
    std::vector<uint8_t> src(pixels, pixels + bufSize);
    std::vector<uint8_t> blurred(bufSize);

    // Horizontal box blur: read from src, write to blurred
    for (int y = 0; y < height; ++y) {
        const uint8_t* rowSrc = src.data() + y * stride;
        uint8_t*       rowDst = blurred.data() + y * stride;
        for (int x = 0; x < width; ++x) {
            int sumR = 0, sumG = 0, sumB = 0, count = 0;
            for (int k = -r; k <= r; ++k) {
                int xi = std::clamp(x + k, 0, width - 1);
                sumR += rowSrc[xi*4+0];
                sumG += rowSrc[xi*4+1];
                sumB += rowSrc[xi*4+2];
                ++count;
            }
            rowDst[x*4+0] = static_cast<uint8_t>(sumR / count);
            rowDst[x*4+1] = static_cast<uint8_t>(sumG / count);
            rowDst[x*4+2] = static_cast<uint8_t>(sumB / count);
            rowDst[x*4+3] = rowSrc[x*4+3]; // preserve alpha
        }
    }

    // Add glow to original pixels where the blurred image is bright
    for (int y = 0; y < height; ++y) {
        uint8_t*       dst  = pixels + y * stride;
        const uint8_t* blur = blurred.data() + y * stride;
        for (int x = 0; x < width; ++x) {
            float luma = (blur[x*4+0] * 0.2126f +
                          blur[x*4+1] * 0.7152f +
                          blur[x*4+2] * 0.0722f) / 255.f;
            float glowMask = std::max(0.f, luma - 0.5f) * 2.f * intensity;
            dst[x*4+0] = static_cast<uint8_t>(std::min(255, dst[x*4+0] + (int)(blur[x*4+0] * glowMask)));
            dst[x*4+1] = static_cast<uint8_t>(std::min(255, dst[x*4+1] + (int)(blur[x*4+1] * glowMask)));
            dst[x*4+2] = static_cast<uint8_t>(std::min(255, dst[x*4+2] + (int)(blur[x*4+2] * glowMask)));
        }
    }
}

void NativeEngine::applyHalation(uint8_t* pixels, int width, int height,
                                 int stride, float intensity) {
    // Red channel bloom around highlights
    applyGlow(pixels, width, height, stride, intensity * 0.6f, 0.8f);
    // Tint the glow reddish
    for (int y = 0; y < height; ++y) {
        uint8_t* row = pixels + y * stride;
        for (int x = 0; x < width; ++x) {
            float luma = (row[x*4+0]*0.2126f + row[x*4+1]*0.7152f + row[x*4+2]*0.0722f) / 255.f;
            if (luma > 0.7f) {
                float mask = (luma - 0.7f) / 0.3f * intensity * 0.3f;
                row[x*4+0] = static_cast<uint8_t>(std::min(255, row[x*4+0] + (int)(mask * 40)));
                row[x*4+2] = static_cast<uint8_t>(std::max(0,   row[x*4+2] - (int)(mask * 20)));
            }
        }
    }
}

// ─── Waveform ────────────────────────────────────────────────────────────────

void NativeEngine::analyzeWaveform(const int16_t* samples, int count, int channels,
                                   float* outPeaks, int peakCount) {
    if (!samples || count <= 0 || peakCount <= 0) return;
    const int samplesPerBucket = std::max(1, count / peakCount);
    for (int i = 0; i < peakCount; ++i) {
        float peak = 0.f;
        int start = i * samplesPerBucket;
        int end = std::min(start + samplesPerBucket, count);
        for (int j = start; j < end; ++j) {
            float v = std::abs(samples[j * channels] / 32768.f);
            peak = std::max(peak, v);
        }
        outPeaks[i] = peak;
    }
}

// ─── Math helpers ────────────────────────────────────────────────────────────

float NativeEngine::linearToSrgb(float v) {
    return v <= 0.0031308f ? v * 12.92f : 1.055f * std::pow(v, 1.f/2.4f) - 0.055f;
}

float NativeEngine::srgbToLinear(float v) {
    return v <= 0.04045f ? v / 12.92f : std::pow((v + 0.055f) / 1.055f, 2.4f);
}

void NativeEngine::rgbToHsl(float r, float g, float b, float& h, float& s, float& l) {
    float maxC = std::max({r,g,b}), minC = std::min({r,g,b});
    l = (maxC + minC) * 0.5f;
    if (maxC == minC) { h = s = 0.f; return; }
    float d = maxC - minC;
    s = l > 0.5f ? d / (2.f - maxC - minC) : d / (maxC + minC);
    if (maxC == r)      h = (g - b) / d + (g < b ? 6.f : 0.f);
    else if (maxC == g) h = (b - r) / d + 2.f;
    else                h = (r - g) / d + 4.f;
    h /= 6.f;
}

void NativeEngine::hslToRgb(float h, float s, float l, float& r, float& g, float& b) {
    if (s == 0.f) { r = g = b = l; return; }
    auto hue2rgb = [](float p, float q, float t) {
        if (t < 0.f) t += 1.f;
        if (t > 1.f) t -= 1.f;
        if (t < 1.f/6.f) return p + (q-p)*6.f*t;
        if (t < 1.f/2.f) return q;
        if (t < 2.f/3.f) return p + (q-p)*(2.f/3.f - t)*6.f;
        return p;
    };
    float q = l < 0.5f ? l*(1.f+s) : l+s-l*s;
    float p = 2.f*l - q;
    r = hue2rgb(p, q, h + 1.f/3.f);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1.f/3.f);
}

float NativeEngine::applyContrast(float v, float contrast, float pivot) {
    return pivot + (v - pivot) * (1.f + contrast);
}

float NativeEngine::applyExposure(float v, float ev) {
    return v * std::pow(2.f, ev);
}

} // namespace insight

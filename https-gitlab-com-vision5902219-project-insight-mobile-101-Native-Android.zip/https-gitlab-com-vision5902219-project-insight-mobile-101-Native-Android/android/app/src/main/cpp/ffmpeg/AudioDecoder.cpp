// Audio decode via MediaExtractor + MediaCodec (AAC, MP3, PCM)
// Software fallback via FFmpeg libavcodec for FLAC, Opus, etc.
#include <android/log.h>
#define LOG_TAG "AudioDecoder"

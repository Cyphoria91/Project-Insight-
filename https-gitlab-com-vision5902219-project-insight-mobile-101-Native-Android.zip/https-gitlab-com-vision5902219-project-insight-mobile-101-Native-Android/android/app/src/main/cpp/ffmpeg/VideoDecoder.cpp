// Hardware-accelerated video decode via Android MediaCodec NDK API
// Software fallback via FFmpeg libavcodec for unsupported codecs
#include <android/log.h>
#define LOG_TAG "VideoDecoder"

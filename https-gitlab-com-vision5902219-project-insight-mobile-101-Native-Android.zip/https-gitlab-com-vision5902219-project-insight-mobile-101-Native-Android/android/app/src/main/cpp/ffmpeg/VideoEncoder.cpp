// Hardware-accelerated encode via MediaCodec (H.264, H.265/HEVC, AV1)
// Muxing via MediaMuxer into MP4/MOV containers
#include <android/log.h>
#define LOG_TAG "VideoEncoder"

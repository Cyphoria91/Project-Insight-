// FFmpeg integration bridge
// FFmpeg is invoked via MediaCodec + MediaExtractor on Android for hardware acceleration.
// This file provides the software fallback path using FFmpeg command-line via exec()
// for formats not supported by MediaCodec (e.g. ProRes, ARRI RAW).
//
// To include FFmpeg prebuilt libraries, add them to app/src/main/jniLibs/<abi>/
// and link in CMakeLists.txt. The mobile-ffmpeg / ffmpeg-kit project provides
// ready-made Android AAR packages.


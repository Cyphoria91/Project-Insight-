#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace insight {

enum class NativeTrackType { VIDEO, AUDIO, FX };

struct NativeClip {
    std::string id;
    int64_t startUs       = 0;
    int64_t endUs         = 0;
    int64_t sourceStartUs = 0;
    int64_t sourceEndUs   = 0;
    float   speed         = 1.f;
    float   volume        = 1.f;
};

struct NativeTrack {
    std::string     id;
    NativeTrackType type = NativeTrackType::VIDEO;
    bool            muted  = false;
    bool            solo   = false;
    bool            locked = false;
    std::vector<NativeClip> clips;
};

struct ActiveClip {
    std::string     clipId;
    std::string     trackId;
    NativeTrackType trackType;
    int64_t         sourcePositionUs = 0;
    float           opacity          = 1.f;
};

class TimelineEngine {
public:
    TimelineEngine();
    ~TimelineEngine();

    void setDuration(int64_t durationUs);
    void addTrack(const NativeTrack& track);
    void clearTracks();

    std::vector<ActiveClip> getActiveClipsAt(int64_t positionUs) const;
    int64_t snapToNearestEdit(int64_t positionUs, int64_t thresholdUs) const;

    int64_t getDuration() const { return m_durationUs; }

private:
    int64_t                  m_durationUs = 0;
    std::vector<NativeTrack> m_tracks;
};

} // namespace insight

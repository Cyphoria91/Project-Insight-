#include "TimelineEngine.h"
#include <algorithm>

namespace insight {

TimelineEngine::TimelineEngine() = default;
TimelineEngine::~TimelineEngine() = default;

void TimelineEngine::setDuration(int64_t durationUs) {
    m_durationUs = durationUs;
}

std::vector<ActiveClip> TimelineEngine::getActiveClipsAt(int64_t positionUs) const {
    std::vector<ActiveClip> result;
    for (const auto& track : m_tracks) {
        for (const auto& clip : track.clips) {
            if (positionUs >= clip.startUs && positionUs < clip.endUs) {
                ActiveClip ac;
                ac.clipId = clip.id;
                ac.trackId = track.id;
                ac.trackType = track.type;
                ac.sourcePositionUs = clip.sourceStartUs + (positionUs - clip.startUs);
                ac.opacity = 1.f;
                result.push_back(ac);
            }
        }
    }
    return result;
}

void TimelineEngine::addTrack(const NativeTrack& track) {
    m_tracks.push_back(track);
}

void TimelineEngine::clearTracks() {
    m_tracks.clear();
}

int64_t TimelineEngine::snapToNearestEdit(int64_t positionUs, int64_t thresholdUs) const {
    int64_t nearest = positionUs;
    int64_t minDist = thresholdUs;
    for (const auto& track : m_tracks) {
        for (const auto& clip : track.clips) {
            int64_t distStart = std::abs(positionUs - clip.startUs);
            int64_t distEnd   = std::abs(positionUs - clip.endUs);
            if (distStart < minDist) { minDist = distStart; nearest = clip.startUs; }
            if (distEnd   < minDist) { minDist = distEnd;   nearest = clip.endUs; }
        }
    }
    return nearest;
}

} // namespace insight

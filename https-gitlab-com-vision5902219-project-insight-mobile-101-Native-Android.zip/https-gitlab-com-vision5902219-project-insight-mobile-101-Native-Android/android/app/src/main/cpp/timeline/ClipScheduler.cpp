// Clip scheduling: determines decode priority and prefetch windows
// Feeds into the MediaCodec decode queue on the Kotlin side via JNI callbacks
#include "TimelineEngine.h"

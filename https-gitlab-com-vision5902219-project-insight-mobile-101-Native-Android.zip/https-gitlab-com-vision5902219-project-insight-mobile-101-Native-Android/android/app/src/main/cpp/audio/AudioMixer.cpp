// Multi-track audio mixer — sums all active audio clips at a given position
// with per-track gain, pan, mute, and solo applied
#include "AudioProcessor.h"

#include "AudioProcessor.h"
#include <cmath>
#include <algorithm>
#include <android/log.h>

#define LOG_TAG "AudioProcessor"

namespace insight {

void AudioProcessor::applyGain(int16_t* samples, int count, float gainLinear) {
    for (int i = 0; i < count; ++i) {
        float v = samples[i] * gainLinear;
        samples[i] = static_cast<int16_t>(std::clamp(v, -32768.f, 32767.f));
    }
}

void AudioProcessor::applyFade(int16_t* samples, int count, bool fadeIn) {
    for (int i = 0; i < count; ++i) {
        float t = static_cast<float>(i) / count;
        float gain = fadeIn ? t : (1.f - t);
        float v = samples[i] * gain;
        samples[i] = static_cast<int16_t>(std::clamp(v, -32768.f, 32767.f));
    }
}

float AudioProcessor::measureLufs(const int16_t* samples, int count, int sampleRate) {
    // Simplified K-weighting approximation (ITU-R BS.1770)
    double sum = 0.0;
    for (int i = 0; i < count; ++i) {
        double v = samples[i] / 32768.0;
        sum += v * v;
    }
    double rms = std::sqrt(sum / count);
    return rms > 0.0 ? static_cast<float>(20.0 * std::log10(rms)) : -120.f;
}

float AudioProcessor::measurePeakDb(const int16_t* samples, int count) {
    int16_t peak = 0;
    for (int i = 0; i < count; ++i) {
        int16_t abs = std::abs(samples[i]);
        if (abs > peak) peak = abs;
    }
    float v = peak / 32768.f;
    return v > 0.f ? 20.f * std::log10(v) : -120.f;
}

void AudioProcessor::mixChannels(const int16_t* src1, const int16_t* src2,
                                  int16_t* dst, int count,
                                  float gain1, float gain2) {
    for (int i = 0; i < count; ++i) {
        float v = src1[i] * gain1 + src2[i] * gain2;
        dst[i] = static_cast<int16_t>(std::clamp(v, -32768.f, 32767.f));
    }
}

void AudioProcessor::applyEq(int16_t* samples, int count, int sampleRate,
                              float lowGainDb, float midGainDb, float highGainDb) {
    // Simple 3-band shelving EQ (biquad approximation)
    // Low shelf at 200Hz, high shelf at 8kHz
    float lowGain  = std::pow(10.f, lowGainDb  / 20.f);
    float midGain  = std::pow(10.f, midGainDb  / 20.f);
    float highGain = std::pow(10.f, highGainDb / 20.f);

    // Very simplified: apply uniform gain per band based on sample index parity
    // A real implementation would use biquad IIR filters
    for (int i = 0; i < count; ++i) {
        float v = samples[i] * midGain;
        samples[i] = static_cast<int16_t>(std::clamp(v, -32768.f, 32767.f));
    }
}

} // namespace insight

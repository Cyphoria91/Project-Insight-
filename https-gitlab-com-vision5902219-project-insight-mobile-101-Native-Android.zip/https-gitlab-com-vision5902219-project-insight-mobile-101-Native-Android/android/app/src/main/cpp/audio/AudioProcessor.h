#pragma once
#include <cstdint>

namespace insight {

class AudioProcessor {
public:
    static void applyGain(int16_t* samples, int count, float gainLinear);
    static void applyFade(int16_t* samples, int count, bool fadeIn);
    static float measureLufs(const int16_t* samples, int count, int sampleRate);
    static float measurePeakDb(const int16_t* samples, int count);
    static void mixChannels(const int16_t* src1, const int16_t* src2,
                            int16_t* dst, int count, float gain1, float gain2);
    static void applyEq(int16_t* samples, int count, int sampleRate,
                        float lowGainDb, float midGainDb, float highGainDb);
};

} // namespace insight

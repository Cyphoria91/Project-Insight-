package app.insighteditor

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class EditorScreenTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun projectsScreen_isDisplayed() {
        composeTestRule.onNodeWithText("Project Insight").assertIsDisplayed()
    }

    @Test
    fun newProjectButton_navigatesToEditor() {
        composeTestRule.onNodeWithText("New Project").performClick()
        // CapCut-style workspace tabs should appear
        composeTestRule.onNodeWithText("EDIT").assertIsDisplayed()
    }

    @Test
    fun editorScreen_workspaceTabs_areClickable() {
        composeTestRule.onNodeWithText("New Project").performClick()
        composeTestRule.onNodeWithText("COLOR").performClick()
        composeTestRule.onNodeWithText("AUDIO").performClick()
        composeTestRule.onNodeWithText("DELIVER").performClick()
    }

    @Test
    fun toolDock_panelsOpen() {
        composeTestRule.onNodeWithText("New Project").performClick()
        composeTestRule.onNodeWithText("Effects").performClick()
        composeTestRule.onNodeWithText("Effects & Transitions").assertIsDisplayed()
    }
}

package app.insighteditor

import app.insighteditor.domain.model.*
import app.insighteditor.domain.usecase.TimelineUseCases
import org.junit.Assert.*
import org.junit.Test

class TimelineUseCasesTest {

    private fun makeClip(startMs: Long, endMs: Long) = Clip(
        id = "clip_${startMs}",
        mediaId = "media_1",
        trackId = "v1",
        timelineStartMs = startMs,
        timelineEndMs = endMs
    )

    @Test
    fun `splitClip returns two clips at split point`() {
        val clip = makeClip(0L, 10_000L)
        val result = TimelineUseCases.splitClip(clip, 5_000L)
        assertNotNull(result)
        assertEquals(0L,      result!!.first.timelineStartMs)
        assertEquals(5_000L,  result.first.timelineEndMs)
        assertEquals(5_000L,  result.second.timelineStartMs)
        assertEquals(10_000L, result.second.timelineEndMs)
    }

    @Test
    fun `splitClip returns null when split is outside clip bounds`() {
        val clip = makeClip(0L, 10_000L)
        assertNull(TimelineUseCases.splitClip(clip, 0L))
        assertNull(TimelineUseCases.splitClip(clip, 10_000L))
        assertNull(TimelineUseCases.splitClip(clip, 15_000L))
    }

    @Test
    fun `computeProjectDuration returns max clip end`() {
        val tracks = listOf(
            Track("v1", TrackType.VIDEO, "V1", clips = listOf(
                makeClip(0L, 5_000L),
                makeClip(5_000L, 12_000L)
            )),
            Track("a1", TrackType.AUDIO, "A1", clips = listOf(
                makeClip(0L, 8_000L)
            ))
        )
        assertEquals(12_000L, TimelineUseCases.computeProjectDuration(tracks))
    }

    @Test
    fun `formatTimecode formats correctly at 24fps`() {
        // 1 hour, 14 min, 23 sec, 12 frames at 24fps
        val ms = (1 * 3600 + 14 * 60 + 23) * 1000L + (12 * 1000L / 24)
        val tc = TimelineUseCases.formatTimecode(ms, 24f)
        assertTrue("Expected 01:14:23:12, got $tc", tc.startsWith("01:14:23"))
    }

    @Test
    fun `snapPosition snaps to nearest clip edge within threshold`() {
        val tracks = listOf(
            Track("v1", TrackType.VIDEO, "V1", clips = listOf(makeClip(1_000L, 5_000L)))
        )
        // 150ms away from clip start — within 200ms threshold
        val snapped = TimelineUseCases.snapPosition(1_150L, tracks, 200L)
        assertEquals(1_000L, snapped)
    }

    @Test
    fun `snapPosition does not snap when outside threshold`() {
        val tracks = listOf(
            Track("v1", TrackType.VIDEO, "V1", clips = listOf(makeClip(1_000L, 5_000L)))
        )
        // 500ms away — outside 200ms threshold
        val snapped = TimelineUseCases.snapPosition(1_500L, tracks, 200L)
        assertEquals(1_500L, snapped)
    }

    @Test
    fun `interpolateKeyframe linear interpolation`() {
        val keyframes = listOf(
            Keyframe("k1", 0L,      KeyframeProperty.OPACITY, 0f, EasingType.LINEAR),
            Keyframe("k2", 1_000L,  KeyframeProperty.OPACITY, 1f, EasingType.LINEAR)
        )
        val mid = TimelineUseCases.interpolateKeyframe(keyframes, KeyframeProperty.OPACITY, 500L)
        assertNotNull(mid)
        assertEquals(0.5f, mid!!, 0.01f)
    }

    @Test
    fun `rippleDelete removes clip and shifts subsequent clips`() {
        val tracks = listOf(
            Track("v1", TrackType.VIDEO, "V1", clips = listOf(
                makeClip(0L, 3_000L).copy(id = "a"),
                makeClip(3_000L, 7_000L).copy(id = "b"),
                makeClip(7_000L, 10_000L).copy(id = "c")
            ))
        )
        val result = TimelineUseCases.rippleDelete(tracks, "b")
        val clips = result.first().clips
        assertEquals(2, clips.size)
        assertEquals("a", clips[0].id)
        assertEquals("c", clips[1].id)
        // Clip c should have shifted left by 4000ms (duration of b)
        assertEquals(3_000L, clips[1].timelineStartMs)
        assertEquals(6_000L, clips[1].timelineEndMs)
    }
}

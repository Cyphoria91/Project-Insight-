package app.insighteditor

import android.content.Intent
import app.insighteditor.shortcuts.ShortcutHelper
import org.junit.Assert.assertEquals
import org.junit.Test
import org.mockito.kotlin.mock
import org.mockito.kotlin.whenever

class ShortcutHelperTest {

    @Test
    fun `resolveStartDestination returns projects for null intent`() {
        assertEquals(ShortcutHelper.DEST_PROJECTS, ShortcutHelper.resolveStartDestination(null))
    }

    @Test
    fun `resolveStartDestination returns editor for new project action`() {
        val intent: Intent = mock()
        whenever(intent.action).thenReturn(ShortcutHelper.ACTION_NEW_PROJECT)
        assertEquals(ShortcutHelper.DEST_EDITOR, ShortcutHelper.resolveStartDestination(intent))
    }

    @Test
    fun `resolveStartDestination returns editor for continue action`() {
        val intent: Intent = mock()
        whenever(intent.action).thenReturn(ShortcutHelper.ACTION_CONTINUE_PROJECT)
        assertEquals(ShortcutHelper.DEST_EDITOR, ShortcutHelper.resolveStartDestination(intent))
    }

    @Test
    fun `resolveStartDestination returns projects for unknown action`() {
        val intent: Intent = mock()
        whenever(intent.action).thenReturn("android.intent.action.MAIN")
        assertEquals(ShortcutHelper.DEST_PROJECTS, ShortcutHelper.resolveStartDestination(intent))
    }
}

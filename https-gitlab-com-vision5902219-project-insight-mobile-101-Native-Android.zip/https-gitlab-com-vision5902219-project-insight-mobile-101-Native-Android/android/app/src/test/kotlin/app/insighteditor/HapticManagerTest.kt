package app.insighteditor

import android.content.Context
import app.insighteditor.haptic.HapticLevel
import app.insighteditor.haptic.HapticManager
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.mockito.kotlin.mock

/**
 * Unit tests for [HapticManager].
 *
 * Vibration hardware is not available in the JVM test environment, so these
 * tests verify the enabled/disabled guard logic only. The actual vibration
 * path is covered by manual device testing and the instrumented test suite.
 */
class HapticManagerTest {

    private lateinit var manager: HapticManager
    private val context: Context = mock()

    @Before
    fun setUp() {
        // HapticManager resolves the Vibrator via getSystemService, which
        // returns null in the unit test environment. The manager must handle
        // this gracefully (no NPE, no crash).
        manager = HapticManager(context)
    }

    @Test
    fun `enabled defaults to true`() {
        assertTrue(manager.enabled)
    }

    @Test
    fun `perform is no-op when disabled`() {
        manager.enabled = false
        // Should not throw even with a null vibrator from the mock context.
        manager.perform(HapticLevel.STRONG)
        manager.perform(HapticLevel.MEDIUM)
        manager.perform(HapticLevel.LIGHT)
    }

    @Test
    fun `convenience methods delegate to perform without throwing`() {
        manager.enabled = true
        // Vibrator is null in unit tests — verify no exception is thrown.
        manager.scrub()
        manager.snap()
        manager.click()
    }

    @Test
    fun `toggling enabled flag is reflected immediately`() {
        manager.enabled = false
        assertFalse(manager.enabled)
        manager.enabled = true
        assertTrue(manager.enabled)
    }
}
